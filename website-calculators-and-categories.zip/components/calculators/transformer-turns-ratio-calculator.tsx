"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, ArrowUpDown } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type CalcMode = "ratio" | "secondary-voltage" | "secondary-current"

interface TransformerResult {
  turnsRatio: number
  turnsRatioInverse: number
  primaryVoltage: number
  secondaryVoltage: number
  primaryCurrent?: number
  secondaryCurrent?: number
  transformerType: "step-up" | "step-down" | "isolation"
  steps: string[]
}

export function TransformerTurnsRatioCalculator() {
  const [calcMode, setCalcMode] = useState<CalcMode>("ratio")
  const [primaryVoltage, setPrimaryVoltage] = useState("")
  const [secondaryVoltage, setSecondaryVoltage] = useState("")
  const [primaryCurrent, setPrimaryCurrent] = useState("")
  const [secondaryCurrent, setSecondaryCurrent] = useState("")
  const [primaryTurns, setPrimaryTurns] = useState("")
  const [secondaryTurns, setSecondaryTurns] = useState("")
  const [voltageUnit, setVoltageUnit] = useState("V")
  const [currentUnit, setCurrentUnit] = useState("A")
  const [result, setResult] = useState<TransformerResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const voltageMultipliers: Record<string, number> = {
    mV: 0.001,
    V: 1,
    kV: 1000,
  }

  const currentMultipliers: Record<string, number> = {
    mA: 0.001,
    A: 1,
    kA: 1000,
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const V1 = Number.parseFloat(primaryVoltage) * voltageMultipliers[voltageUnit]
    const V2Str = secondaryVoltage
    const I1Str = primaryCurrent
    const I2Str = secondaryCurrent
    const N1Str = primaryTurns
    const N2Str = secondaryTurns

    const steps: string[] = []

    if (calcMode === "ratio") {
      // Calculate turns ratio from voltages
      const V2 = Number.parseFloat(V2Str) * voltageMultipliers[voltageUnit]

      if (isNaN(V1) || V1 <= 0) {
        setError("Please enter a valid primary voltage greater than 0")
        return
      }
      if (isNaN(V2) || V2 <= 0) {
        setError("Please enter a valid secondary voltage greater than 0")
        return
      }

      const turnsRatio = V1 / V2
      const turnsRatioInverse = V2 / V1

      steps.push(`Step 1: Identify the given values`)
      steps.push(`   Primary Voltage (V₁) = ${V1} V`)
      steps.push(`   Secondary Voltage (V₂) = ${V2} V`)
      steps.push(`Step 2: Apply the turns ratio formula`)
      steps.push(`   N₁/N₂ = V₁/V₂`)
      steps.push(`Step 3: Calculate the turns ratio`)
      steps.push(`   N₁/N₂ = ${V1}/${V2} = ${turnsRatio.toFixed(4)}`)

      let transformerType: "step-up" | "step-down" | "isolation" = "isolation"
      if (V2 > V1) {
        transformerType = "step-up"
        steps.push(`Step 4: Determine transformer type`)
        steps.push(`   Since V₂ > V₁, this is a Step-Up transformer`)
      } else if (V2 < V1) {
        transformerType = "step-down"
        steps.push(`Step 4: Determine transformer type`)
        steps.push(`   Since V₂ < V₁, this is a Step-Down transformer`)
      } else {
        steps.push(`Step 4: Determine transformer type`)
        steps.push(`   Since V₂ = V₁, this is an Isolation transformer (1:1)`)
      }

      // Calculate currents if provided
      let calculatedI1: number | undefined
      let calculatedI2: number | undefined

      if (I1Str) {
        const I1 = Number.parseFloat(I1Str) * currentMultipliers[currentUnit]
        if (!isNaN(I1) && I1 > 0) {
          calculatedI1 = I1
          calculatedI2 = I1 * turnsRatio
          steps.push(`Step 5: Calculate secondary current (optional)`)
          steps.push(`   I₁/I₂ = N₂/N₁ = V₂/V₁`)
          steps.push(`   I₂ = I₁ × (N₁/N₂) = ${I1} × ${turnsRatio.toFixed(4)} = ${calculatedI2.toFixed(4)} A`)
        }
      } else if (I2Str) {
        const I2 = Number.parseFloat(I2Str) * currentMultipliers[currentUnit]
        if (!isNaN(I2) && I2 > 0) {
          calculatedI2 = I2
          calculatedI1 = I2 / turnsRatio
          steps.push(`Step 5: Calculate primary current (optional)`)
          steps.push(`   I₁ = I₂ / (N₁/N₂) = ${I2} / ${turnsRatio.toFixed(4)} = ${calculatedI1.toFixed(4)} A`)
        }
      }

      setResult({
        turnsRatio,
        turnsRatioInverse,
        primaryVoltage: V1,
        secondaryVoltage: V2,
        primaryCurrent: calculatedI1,
        secondaryCurrent: calculatedI2,
        transformerType,
        steps,
      })
    } else if (calcMode === "secondary-voltage") {
      // Calculate secondary voltage from turns ratio
      const N1 = Number.parseFloat(N1Str)
      const N2 = Number.parseFloat(N2Str)

      if (isNaN(V1) || V1 <= 0) {
        setError("Please enter a valid primary voltage greater than 0")
        return
      }
      if (isNaN(N1) || N1 <= 0) {
        setError("Please enter a valid number of primary turns greater than 0")
        return
      }
      if (isNaN(N2) || N2 <= 0) {
        setError("Please enter a valid number of secondary turns greater than 0")
        return
      }

      const turnsRatio = N1 / N2
      const turnsRatioInverse = N2 / N1
      const V2 = V1 / turnsRatio

      steps.push(`Step 1: Identify the given values`)
      steps.push(`   Primary Voltage (V₁) = ${V1} V`)
      steps.push(`   Primary Turns (N₁) = ${N1}`)
      steps.push(`   Secondary Turns (N₂) = ${N2}`)
      steps.push(`Step 2: Calculate turns ratio`)
      steps.push(`   N₁/N₂ = ${N1}/${N2} = ${turnsRatio.toFixed(4)}`)
      steps.push(`Step 3: Apply the voltage relationship`)
      steps.push(`   V₁/V₂ = N₁/N₂`)
      steps.push(`   V₂ = V₁ × (N₂/N₁)`)
      steps.push(`Step 4: Calculate secondary voltage`)
      steps.push(`   V₂ = ${V1} × (${N2}/${N1}) = ${V2.toFixed(4)} V`)

      let transformerType: "step-up" | "step-down" | "isolation" = "isolation"
      if (N2 > N1) {
        transformerType = "step-up"
        steps.push(`Step 5: Determine transformer type`)
        steps.push(`   Since N₂ > N₁, this is a Step-Up transformer`)
      } else if (N2 < N1) {
        transformerType = "step-down"
        steps.push(`Step 5: Determine transformer type`)
        steps.push(`   Since N₂ < N₁, this is a Step-Down transformer`)
      }

      setResult({
        turnsRatio,
        turnsRatioInverse,
        primaryVoltage: V1,
        secondaryVoltage: V2,
        transformerType,
        steps,
      })
    } else if (calcMode === "secondary-current") {
      // Calculate secondary current
      const V2 = Number.parseFloat(V2Str) * voltageMultipliers[voltageUnit]
      const I1 = Number.parseFloat(I1Str) * currentMultipliers[currentUnit]

      if (isNaN(V1) || V1 <= 0) {
        setError("Please enter a valid primary voltage greater than 0")
        return
      }
      if (isNaN(V2) || V2 <= 0) {
        setError("Please enter a valid secondary voltage greater than 0")
        return
      }
      if (isNaN(I1) || I1 <= 0) {
        setError("Please enter a valid primary current greater than 0")
        return
      }

      const turnsRatio = V1 / V2
      const turnsRatioInverse = V2 / V1
      const I2 = I1 * turnsRatio

      steps.push(`Step 1: Identify the given values`)
      steps.push(`   Primary Voltage (V₁) = ${V1} V`)
      steps.push(`   Secondary Voltage (V₂) = ${V2} V`)
      steps.push(`   Primary Current (I₁) = ${I1} A`)
      steps.push(`Step 2: Calculate turns ratio from voltages`)
      steps.push(`   N₁/N₂ = V₁/V₂ = ${V1}/${V2} = ${turnsRatio.toFixed(4)}`)
      steps.push(`Step 3: Apply the current relationship (ideal transformer)`)
      steps.push(`   I₁/I₂ = N₂/N₁ = V₂/V₁`)
      steps.push(`   I₂ = I₁ × (V₁/V₂) = I₁ × (N₁/N₂)`)
      steps.push(`Step 4: Calculate secondary current`)
      steps.push(`   I₂ = ${I1} × ${turnsRatio.toFixed(4)} = ${I2.toFixed(4)} A`)
      steps.push(`Step 5: Verify power conservation (ideal transformer)`)
      steps.push(`   P₁ = V₁ × I₁ = ${V1} × ${I1} = ${(V1 * I1).toFixed(4)} W`)
      steps.push(`   P₂ = V₂ × I₂ = ${V2} × ${I2.toFixed(4)} = ${(V2 * I2).toFixed(4)} W`)

      let transformerType: "step-up" | "step-down" | "isolation" = "isolation"
      if (V2 > V1) {
        transformerType = "step-up"
      } else if (V2 < V1) {
        transformerType = "step-down"
      }

      setResult({
        turnsRatio,
        turnsRatioInverse,
        primaryVoltage: V1,
        secondaryVoltage: V2,
        primaryCurrent: I1,
        secondaryCurrent: I2,
        transformerType,
        steps,
      })
    }
  }

  const handleReset = () => {
    setPrimaryVoltage("")
    setSecondaryVoltage("")
    setPrimaryCurrent("")
    setSecondaryCurrent("")
    setPrimaryTurns("")
    setSecondaryTurns("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Transformer Turns Ratio: ${result.turnsRatio.toFixed(4)} (${result.turnsRatio.toFixed(2)}:1)\nType: ${result.transformerType}\nV₁: ${result.primaryVoltage} V, V₂: ${result.secondaryVoltage.toFixed(4)} V${result.primaryCurrent ? `\nI₁: ${result.primaryCurrent.toFixed(4)} A` : ""}${result.secondaryCurrent ? `, I₂: ${result.secondaryCurrent.toFixed(4)} A` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Transformer Turns Ratio Result",
          text: `I calculated transformer turns ratio using CalcHub! Ratio: ${result.turnsRatio.toFixed(2)}:1 (${result.transformerType})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <ArrowUpDown className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Transformer Turns Ratio</CardTitle>
                    <CardDescription>Calculate transformer ratios and voltages</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Calculation Mode */}
                <div className="space-y-2">
                  <Label>Calculation Mode</Label>
                  <Select
                    value={calcMode}
                    onValueChange={(v) => {
                      setCalcMode(v as CalcMode)
                      handleReset()
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ratio">Calculate Turns Ratio (from V₁, V₂)</SelectItem>
                      <SelectItem value="secondary-voltage">Calculate Secondary Voltage (from N₁, N₂)</SelectItem>
                      <SelectItem value="secondary-current">Calculate Secondary Current</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Unit Selectors */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Voltage Unit</Label>
                    <Select value={voltageUnit} onValueChange={setVoltageUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mV">Millivolts (mV)</SelectItem>
                        <SelectItem value="V">Volts (V)</SelectItem>
                        <SelectItem value="kV">Kilovolts (kV)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Current Unit</Label>
                    <Select value={currentUnit} onValueChange={setCurrentUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mA">Milliamps (mA)</SelectItem>
                        <SelectItem value="A">Amps (A)</SelectItem>
                        <SelectItem value="kA">Kiloamps (kA)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Primary Voltage */}
                <div className="space-y-2">
                  <Label htmlFor="primary-voltage">Primary Voltage (V₁)</Label>
                  <Input
                    id="primary-voltage"
                    type="number"
                    placeholder={`Enter primary voltage in ${voltageUnit}`}
                    value={primaryVoltage}
                    onChange={(e) => setPrimaryVoltage(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Secondary Voltage - for ratio and current modes */}
                {(calcMode === "ratio" || calcMode === "secondary-current") && (
                  <div className="space-y-2">
                    <Label htmlFor="secondary-voltage">Secondary Voltage (V₂)</Label>
                    <Input
                      id="secondary-voltage"
                      type="number"
                      placeholder={`Enter secondary voltage in ${voltageUnit}`}
                      value={secondaryVoltage}
                      onChange={(e) => setSecondaryVoltage(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Turns inputs - for secondary voltage mode */}
                {calcMode === "secondary-voltage" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="primary-turns">Primary Turns (N₁)</Label>
                      <Input
                        id="primary-turns"
                        type="number"
                        placeholder="Enter number of primary turns"
                        value={primaryTurns}
                        onChange={(e) => setPrimaryTurns(e.target.value)}
                        min="1"
                        step="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="secondary-turns">Secondary Turns (N₂)</Label>
                      <Input
                        id="secondary-turns"
                        type="number"
                        placeholder="Enter number of secondary turns"
                        value={secondaryTurns}
                        onChange={(e) => setSecondaryTurns(e.target.value)}
                        min="1"
                        step="1"
                      />
                    </div>
                  </>
                )}

                {/* Current inputs */}
                {calcMode === "ratio" && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="primary-current">
                        Primary Current (I₁) <span className="text-muted-foreground text-xs">(optional)</span>
                      </Label>
                      <Input
                        id="primary-current"
                        type="number"
                        placeholder={currentUnit}
                        value={primaryCurrent}
                        onChange={(e) => {
                          setPrimaryCurrent(e.target.value)
                          setSecondaryCurrent("")
                        }}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="secondary-current">
                        Secondary Current (I₂) <span className="text-muted-foreground text-xs">(optional)</span>
                      </Label>
                      <Input
                        id="secondary-current"
                        type="number"
                        placeholder={currentUnit}
                        value={secondaryCurrent}
                        onChange={(e) => {
                          setSecondaryCurrent(e.target.value)
                          setPrimaryCurrent("")
                        }}
                        min="0"
                        step="any"
                      />
                    </div>
                  </div>
                )}

                {calcMode === "secondary-current" && (
                  <div className="space-y-2">
                    <Label htmlFor="primary-current-req">Primary Current (I₁)</Label>
                    <Input
                      id="primary-current-req"
                      type="number"
                      placeholder={`Enter primary current in ${currentUnit}`}
                      value={primaryCurrent}
                      onChange={(e) => setPrimaryCurrent(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  <Zap className="mr-2 h-4 w-4" />
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <p className="text-sm text-muted-foreground">Turns Ratio (N₁:N₂)</p>
                      <p className="text-4xl font-bold text-amber-700">{result.turnsRatio.toFixed(2)}:1</p>
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium bg-amber-100 text-amber-800">
                        {result.transformerType === "step-up" && "⬆️ Step-Up Transformer"}
                        {result.transformerType === "step-down" && "⬇️ Step-Down Transformer"}
                        {result.transformerType === "isolation" && "↔️ Isolation Transformer (1:1)"}
                      </div>

                      <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                        <div className="p-2 bg-white rounded-lg">
                          <p className="text-muted-foreground">Primary Voltage</p>
                          <p className="font-semibold">{result.primaryVoltage.toFixed(4)} V</p>
                        </div>
                        <div className="p-2 bg-white rounded-lg">
                          <p className="text-muted-foreground">Secondary Voltage</p>
                          <p className="font-semibold">{result.secondaryVoltage.toFixed(4)} V</p>
                        </div>
                        {result.primaryCurrent !== undefined && (
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Primary Current</p>
                            <p className="font-semibold">{result.primaryCurrent.toFixed(4)} A</p>
                          </div>
                        )}
                        {result.secondaryCurrent !== undefined && (
                          <div className="p-2 bg-white rounded-lg">
                            <p className="text-muted-foreground">Secondary Current</p>
                            <p className="font-semibold">{result.secondaryCurrent.toFixed(4)} A</p>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Step-by-step toggle */}
                    <Collapsible open={showSteps} onOpenChange={setShowSteps} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full">
                          {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="p-3 bg-white rounded-lg text-sm font-mono space-y-1">
                          {result.steps.map((step, i) => (
                            <p key={i} className="text-muted-foreground whitespace-pre-wrap">
                              {step}
                            </p>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Transformer Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold">N₁/N₂ = V₁/V₂</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold">I₁/I₂ = N₂/N₁ = V₂/V₁</p>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <p>
                      <strong>N₁</strong> = Primary turns
                    </p>
                    <p>
                      <strong>N₂</strong> = Secondary turns
                    </p>
                    <p>
                      <strong>V₁</strong> = Primary voltage
                    </p>
                    <p>
                      <strong>V₂</strong> = Secondary voltage
                    </p>
                    <p>
                      <strong>I₁</strong> = Primary current
                    </p>
                    <p>
                      <strong>I₂</strong> = Secondary current
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Transformer Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Step-Up</span>
                      <span className="text-sm text-green-600">
                        V₂ {">"} V₁ (N₂ {">"} N₁)
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Step-Down</span>
                      <span className="text-sm text-blue-600">
                        V₂ {"<"} V₁ (N₂ {"<"} N₁)
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">Isolation</span>
                      <span className="text-sm text-gray-600">V₂ = V₁ (N₂ = N₁)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Applications</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Step-Up:</strong> Power transmission (11kV → 400kV), CRT displays
                  </p>
                  <p>
                    <strong>Step-Down:</strong> Phone chargers (230V → 5V), laptop adapters
                  </p>
                  <p>
                    <strong>Isolation:</strong> Medical equipment, safety barriers
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Transformer Turns Ratio?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The transformer turns ratio is the relationship between the number of turns in the primary winding
                  (N₁) and the secondary winding (N₂) of a transformer. This ratio directly determines how the voltage
                  and current are transformed between the primary and secondary sides. In an ideal transformer, the
                  voltage ratio equals the turns ratio: V₁/V₂ = N₁/N₂.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The turns ratio is fundamental to transformer design and is used to step up or step down voltages for
                  various applications, from power transmission lines that use high voltages for efficient long-distance
                  transmission, to household devices that require low voltages for safe operation.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Power Conservation in Transformers</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  In an ideal transformer, power is conserved between the primary and secondary windings: P₁ = P₂, which
                  means V₁ × I₁ = V₂ × I₂. This leads to an important relationship: as voltage increases (step-up),
                  current decreases proportionally, and vice versa (step-down).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This principle is why high-voltage transmission is used for power distribution. By stepping up the
                  voltage, the current is reduced, which minimizes power losses in the transmission lines (since losses
                  are proportional to I²R). At the destination, step-down transformers reduce the voltage to safe levels
                  for consumer use.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm">
                  Transformer turns ratio calculations are based on ideal assumptions. Actual transformer performance
                  may vary due to winding resistance, leakage inductance, core losses, and load conditions. Real
                  transformers have efficiencies typically between 95-99%. Consult datasheets or an electrical engineer
                  for precise design and safety-critical applications.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
