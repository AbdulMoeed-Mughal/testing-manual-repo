"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Info, ChevronDown, ChevronUp, Layers } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

interface AsphaltResult {
  area: number
  volume: number
  volumeWithWaste: number
  weight: number
  areaUnit: string
  volumeUnit: string
  weightUnit: string
}

export function AsphaltCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [thickness, setThickness] = useState("")
  const [thicknessUnit, setThicknessUnit] = useState("cm")
  const [density, setDensity] = useState("")
  const [wastePercentage, setWastePercentage] = useState("5")
  const [result, setResult] = useState<AsphaltResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  // Set default density based on unit system
  const getDefaultDensity = () => {
    return unitSystem === "metric" ? "2400" : "150"
  }

  const calculateAsphalt = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const thicknessNum = Number.parseFloat(thickness)
    const densityNum = Number.parseFloat(density) || Number.parseFloat(getDefaultDensity())
    const wasteNum = Number.parseFloat(wastePercentage) || 0

    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }
    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }
    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid thickness greater than 0")
      return
    }
    if (wasteNum < 0) {
      setError("Waste percentage cannot be negative")
      return
    }

    // Calculate area
    const area = lengthNum * widthNum

    // Convert thickness to meters or feet based on unit system
    let thicknessInBaseUnit: number
    if (unitSystem === "metric") {
      if (thicknessUnit === "cm") {
        thicknessInBaseUnit = thicknessNum / 100
      } else if (thicknessUnit === "mm") {
        thicknessInBaseUnit = thicknessNum / 1000
      } else {
        thicknessInBaseUnit = thicknessNum
      }
    } else {
      if (thicknessUnit === "inches") {
        thicknessInBaseUnit = thicknessNum / 12
      } else {
        thicknessInBaseUnit = thicknessNum
      }
    }

    // Calculate volume
    const volume = area * thicknessInBaseUnit

    // Calculate volume with waste
    const volumeWithWaste = volume * (1 + wasteNum / 100)

    // Calculate weight
    const weight = volumeWithWaste * densityNum

    setResult({
      area,
      volume,
      volumeWithWaste,
      weight,
      areaUnit: unitSystem === "metric" ? "m²" : "ft²",
      volumeUnit: unitSystem === "metric" ? "m³" : "ft³",
      weightUnit: unitSystem === "metric" ? "kg" : "lb",
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setThickness("")
    setDensity("")
    setWastePercentage("5")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Asphalt Calculator Results:
Area: ${result.area.toFixed(2)} ${result.areaUnit}
Volume: ${result.volume.toFixed(4)} ${result.volumeUnit}
Volume with waste: ${result.volumeWithWaste.toFixed(4)} ${result.volumeUnit}
Weight: ${result.weight.toFixed(2)} ${result.weightUnit} (${(result.weight / (unitSystem === "metric" ? 1000 : 2000)).toFixed(2)} ${unitSystem === "metric" ? "tonnes" : "tons"})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Asphalt Calculator Results",
          text: `I calculated asphalt requirements using CalcHub! Area: ${result.area.toFixed(2)} ${result.areaUnit}, Weight: ${result.weight.toFixed(2)} ${result.weightUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    const newSystem = unitSystem === "metric" ? "imperial" : "metric"
    setUnitSystem(newSystem)
    setThicknessUnit(newSystem === "metric" ? "cm" : "inches")
    setDensity("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Asphalt Calculator</CardTitle>
                    <CardDescription>Calculate asphalt requirements for paving</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Width Input */}
                <div className="space-y-2">
                  <Label htmlFor="width">Width ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="width"
                    type="number"
                    placeholder={`Enter width in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={width}
                    onChange={(e) => setWidth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Thickness Input */}
                <div className="space-y-2">
                  <Label htmlFor="thickness">Thickness</Label>
                  <div className="flex gap-2">
                    <Input
                      id="thickness"
                      type="number"
                      placeholder="Enter thickness"
                      value={thickness}
                      onChange={(e) => setThickness(e.target.value)}
                      min="0"
                      step="0.1"
                      className="flex-1"
                    />
                    <Select value={thicknessUnit} onValueChange={setThicknessUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {unitSystem === "metric" ? (
                          <>
                            <SelectItem value="cm">cm</SelectItem>
                            <SelectItem value="mm">mm</SelectItem>
                          </>
                        ) : (
                          <SelectItem value="inches">inches</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Density Input */}
                <div className="space-y-2">
                  <Label htmlFor="density">Density ({unitSystem === "metric" ? "kg/m³" : "lb/ft³"})</Label>
                  <Input
                    id="density"
                    type="number"
                    placeholder={getDefaultDensity()}
                    value={density}
                    onChange={(e) => setDensity(e.target.value)}
                    min="0"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">
                    Default: {getDefaultDensity()} {unitSystem === "metric" ? "kg/m³" : "lb/ft³"} (hot mix asphalt)
                  </p>
                </div>

                {/* Waste Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="waste">Waste Percentage (%)</Label>
                  <Input
                    id="waste"
                    type="number"
                    placeholder="5"
                    value={wastePercentage}
                    onChange={(e) => setWastePercentage(e.target.value)}
                    min="0"
                    max="50"
                    step="1"
                  />
                  <p className="text-xs text-muted-foreground">Recommended: 5-10% for material loss and compaction</p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateAsphalt} className="w-full" size="lg">
                  Calculate Asphalt
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Asphalt Required</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">
                        {result.weight.toFixed(2)} {result.weightUnit}
                      </p>
                      <p className="text-lg text-amber-700">
                        ({(result.weight / (unitSystem === "metric" ? 1000 : 2000)).toFixed(2)}{" "}
                        {unitSystem === "metric" ? "tonnes" : "tons"})
                      </p>
                    </div>

                    {/* Results Summary */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border border-amber-100">
                        <p className="text-xs text-muted-foreground">Area</p>
                        <p className="font-semibold text-foreground">
                          {result.area.toFixed(2)} {result.areaUnit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-amber-100">
                        <p className="text-xs text-muted-foreground">Volume</p>
                        <p className="font-semibold text-foreground">
                          {result.volume.toFixed(4)} {result.volumeUnit}
                        </p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-amber-100 col-span-2">
                        <p className="text-xs text-muted-foreground">Volume with {wastePercentage}% Waste</p>
                        <p className="font-semibold text-foreground">
                          {result.volumeWithWaste.toFixed(4)} {result.volumeUnit}
                        </p>
                      </div>
                    </div>

                    {/* Step-by-step breakdown */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="flex items-center justify-between w-full p-2 text-sm font-medium text-amber-700 hover:bg-amber-100 rounded-lg transition-colors"
                    >
                      <span>Step-by-step calculation</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg border border-amber-100 text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">1. Area:</span>
                          <span className="font-mono">
                            {length} × {width} = {result.area.toFixed(2)} {result.areaUnit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">2. Volume:</span>
                          <span className="font-mono">
                            {result.area.toFixed(2)} × {thickness} {thicknessUnit} = {result.volume.toFixed(4)}{" "}
                            {result.volumeUnit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">3. With waste:</span>
                          <span className="font-mono">
                            {result.volume.toFixed(4)} × {(1 + Number.parseFloat(wastePercentage) / 100).toFixed(2)} ={" "}
                            {result.volumeWithWaste.toFixed(4)} {result.volumeUnit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">4. Weight:</span>
                          <span className="font-mono">
                            {result.volumeWithWaste.toFixed(4)} × {density || getDefaultDensity()} ={" "}
                            {result.weight.toFixed(2)} {result.weightUnit}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Asphalt Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Area = Length × Width</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Volume = Area × Thickness</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center text-sm">
                    <p className="font-semibold text-foreground">Weight = Volume × Density</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Asphalt Thickness</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Driveways</span>
                      <span className="text-sm text-amber-600">5-7.5 cm (2-3 in)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Parking Lots</span>
                      <span className="text-sm text-amber-600">7.5-10 cm (3-4 in)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Light Traffic Roads</span>
                      <span className="text-sm text-amber-600">5-7.5 cm (2-3 in)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">Heavy Traffic Roads</span>
                      <span className="text-sm text-amber-600">10-15 cm (4-6 in)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual asphalt requirements may vary due to compaction, site conditions,
                        and material properties. Always consult with a paving professional for accurate quantities.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Asphalt?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Asphalt, also known as bitumen or blacktop, is a sticky, black, highly viscous liquid or semi-solid
                  form of petroleum. It is commonly used in road construction, where it serves as the binding agent
                  mixed with aggregate particles to create asphalt concrete. Hot mix asphalt (HMA) is the most common
                  type used for paving roads, driveways, and parking lots due to its durability and weather resistance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The density of asphalt varies depending on the mix design and aggregate used, but hot mix asphalt
                  typically has a density of around 2,400 kg/m³ (150 lb/ft³). This calculator uses this standard density
                  as a default, but you can adjust it based on your specific asphalt mix specifications provided by your
                  supplier.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Asphalt Requirements</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence how much asphalt you'll need for your paving project:
                </p>
                <div className="mt-4 space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Surface Preparation</h4>
                    <p className="text-sm text-muted-foreground">
                      Uneven or damaged sub-base may require additional asphalt to achieve a level surface. Proper
                      grading and compaction of the base layer is essential for accurate calculations.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Compaction</h4>
                    <p className="text-sm text-muted-foreground">
                      Asphalt compacts during installation, typically reducing in volume by 20-25%. This calculator
                      accounts for this through the waste percentage, but actual compaction rates may vary based on
                      equipment and technique.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Traffic Load</h4>
                    <p className="text-sm text-muted-foreground">
                      Heavier traffic requires thicker asphalt layers. Residential driveways typically need 2-3 inches,
                      while commercial parking lots may require 3-4 inches or more for durability.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Climate Considerations</h4>
                    <p className="text-sm text-muted-foreground">
                      In areas with extreme temperature variations, thicker asphalt layers may be recommended to prevent
                      cracking. Cold climates may also require specific asphalt mix formulations.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Estimation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Measure carefully:</strong> Take multiple measurements of the area and use the average for
                    more accurate results.
                  </li>
                  <li>
                    <strong>Account for irregular shapes:</strong> Break complex areas into smaller rectangles and
                    calculate each separately.
                  </li>
                  <li>
                    <strong>Include waste factor:</strong> Always add 5-10% extra for material loss during transport,
                    installation, and compaction.
                  </li>
                  <li>
                    <strong>Verify density:</strong> Confirm the specific density of your asphalt mix with your supplier
                    for precise weight calculations.
                  </li>
                  <li>
                    <strong>Consider delivery:</strong> Asphalt is typically sold and delivered by the ton, so round up
                    to ensure adequate supply.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
