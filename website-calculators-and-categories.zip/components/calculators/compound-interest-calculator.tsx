"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  PiggyBank,
  Calendar,
  Percent,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CompoundingFrequency = "annually" | "semi-annually" | "quarterly" | "monthly" | "daily"
type ContributionFrequency = "monthly" | "quarterly" | "annually"

interface CompoundResult {
  futureValue: number
  totalContributions: number
  totalInterest: number
  principalPercentage: number
  contributionsPercentage: number
  interestPercentage: number
  growthTable: GrowthEntry[]
}

interface GrowthEntry {
  year: number
  startBalance: number
  contributions: number
  interest: number
  endBalance: number
}

const compoundingOptions: { value: CompoundingFrequency; label: string; periods: number }[] = [
  { value: "annually", label: "Annually", periods: 1 },
  { value: "semi-annually", label: "Semi-annually", periods: 2 },
  { value: "quarterly", label: "Quarterly", periods: 4 },
  { value: "monthly", label: "Monthly", periods: 12 },
  { value: "daily", label: "Daily", periods: 365 },
]

const contributionOptions: { value: ContributionFrequency; label: string; periods: number }[] = [
  { value: "monthly", label: "Monthly", periods: 12 },
  { value: "quarterly", label: "Quarterly", periods: 4 },
  { value: "annually", label: "Annually", periods: 1 },
]

export function CompoundInterestCalculator() {
  const [principal, setPrincipal] = useState("")
  const [interestRate, setInterestRate] = useState("")
  const [years, setYears] = useState("")
  const [months, setMonths] = useState("")
  const [compoundingFrequency, setCompoundingFrequency] = useState<CompoundingFrequency>("monthly")
  const [contribution, setContribution] = useState("")
  const [contributionFrequency, setContributionFrequency] = useState<ContributionFrequency>("monthly")
  const [result, setResult] = useState<CompoundResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showGrowthTable, setShowGrowthTable] = useState(false)

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value)
  }

  const calculateCompoundInterest = () => {
    setError("")
    setResult(null)

    const principalNum = Number.parseFloat(principal)
    if (isNaN(principalNum) || principalNum < 0) {
      setError("Please enter a valid principal amount")
      return
    }

    const rateNum = Number.parseFloat(interestRate)
    if (isNaN(rateNum) || rateNum < 0) {
      setError("Please enter a valid interest rate")
      return
    }

    const yearsNum = Number.parseFloat(years) || 0
    const monthsNum = Number.parseFloat(months) || 0
    const totalYears = yearsNum + monthsNum / 12

    if (totalYears <= 0) {
      setError("Please enter a valid time period")
      return
    }

    const contributionNum = Number.parseFloat(contribution) || 0
    const r = rateNum / 100
    const n = compoundingOptions.find((opt) => opt.value === compoundingFrequency)?.periods || 12
    const contributionPeriodsPerYear =
      contributionOptions.find((opt) => opt.value === contributionFrequency)?.periods || 12

    // Calculate compound interest on principal
    // A = P × (1 + r/n)^(n×t)
    let futureValue: number
    let totalContributions = 0

    if (r === 0) {
      // Zero interest scenario
      futureValue = principalNum
      totalContributions = contributionNum * contributionPeriodsPerYear * totalYears
      futureValue += totalContributions
    } else {
      // Compound interest on principal
      const compoundedPrincipal = principalNum * Math.pow(1 + r / n, n * totalYears)

      // Future value of contributions (annuity)
      // FV = PMT × [((1 + r/n)^(n×t) − 1) / (r/n)]
      // Adjusted for contribution frequency
      const effectiveRate = r / contributionPeriodsPerYear
      const totalContributionPeriods = contributionPeriodsPerYear * totalYears
      totalContributions = contributionNum * totalContributionPeriods

      let contributionsFV = 0
      if (contributionNum > 0) {
        // For contributions, we use the effective rate based on contribution frequency
        const contributionGrowth =
          contributionNum * ((Math.pow(1 + effectiveRate, totalContributionPeriods) - 1) / effectiveRate)
        contributionsFV = contributionGrowth
      }

      futureValue = compoundedPrincipal + contributionsFV
    }

    const totalInterest = futureValue - principalNum - totalContributions
    const totalInvested = principalNum + totalContributions

    // Calculate percentages
    const principalPercentage = (principalNum / futureValue) * 100
    const contributionsPercentage = (totalContributions / futureValue) * 100
    const interestPercentage = (totalInterest / futureValue) * 100

    // Generate growth table
    const growthTable: GrowthEntry[] = []
    let runningBalance = principalNum
    const yearlyContribution = contributionNum * contributionPeriodsPerYear

    for (let year = 1; year <= Math.ceil(totalYears); year++) {
      const startBalance = runningBalance
      const yearFraction = year <= totalYears ? 1 : totalYears - Math.floor(totalYears)
      const yearContributions = yearlyContribution * yearFraction

      let endBalance: number
      if (r === 0) {
        endBalance = startBalance + yearContributions
      } else {
        // Simplified yearly calculation for display
        const interestOnPrincipal = startBalance * (Math.pow(1 + r / n, n * yearFraction) - 1)
        endBalance = startBalance + yearContributions + interestOnPrincipal
      }

      const yearInterest = endBalance - startBalance - yearContributions

      growthTable.push({
        year,
        startBalance,
        contributions: yearContributions,
        interest: yearInterest,
        endBalance,
      })

      runningBalance = endBalance
    }

    setResult({
      futureValue,
      totalContributions,
      totalInterest,
      principalPercentage,
      contributionsPercentage,
      interestPercentage,
      growthTable,
    })
  }

  const handleReset = () => {
    setPrincipal("")
    setInterestRate("")
    setYears("")
    setMonths("")
    setCompoundingFrequency("monthly")
    setContribution("")
    setContributionFrequency("monthly")
    setResult(null)
    setError("")
    setCopied(false)
    setShowGrowthTable(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Compound Interest Calculation:
Future Value: ${formatCurrency(result.futureValue)}
Total Contributions: ${formatCurrency(result.totalContributions)}
Total Interest Earned: ${formatCurrency(result.totalInterest)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Compound Interest Calculation",
          text: `I calculated my investment growth using CalcHub! Future Value: ${formatCurrency(result.futureValue)}, Interest Earned: ${formatCurrency(result.totalInterest)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Compound Interest Calculator</CardTitle>
                    <CardDescription>Calculate your investment growth over time</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Principal Amount */}
                <div className="space-y-2">
                  <Label htmlFor="principal">Initial Principal ($)</Label>
                  <Input
                    id="principal"
                    type="number"
                    placeholder="Enter initial investment amount"
                    value={principal}
                    onChange={(e) => setPrincipal(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Interest Rate */}
                <div className="space-y-2">
                  <Label htmlFor="interestRate">Annual Interest Rate (%)</Label>
                  <Input
                    id="interestRate"
                    type="number"
                    placeholder="Enter annual interest rate"
                    value={interestRate}
                    onChange={(e) => setInterestRate(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Time Period */}
                <div className="space-y-2">
                  <Label>Time Period</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder="Years"
                        value={years}
                        onChange={(e) => setYears(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Months"
                        value={months}
                        onChange={(e) => setMonths(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                </div>

                {/* Compounding Frequency */}
                <div className="space-y-2">
                  <Label>Compounding Frequency</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {compoundingOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setCompoundingFrequency(option.value)}
                        className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                          compoundingFrequency === option.value
                            ? "bg-green-600 text-white"
                            : "bg-muted hover:bg-muted/80 text-foreground"
                        }`}
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Regular Contribution */}
                <div className="space-y-2">
                  <Label htmlFor="contribution">Regular Contribution (optional)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <Input
                      id="contribution"
                      type="number"
                      placeholder="Amount ($)"
                      value={contribution}
                      onChange={(e) => setContribution(e.target.value)}
                      min="0"
                      step="10"
                    />
                    <select
                      value={contributionFrequency}
                      onChange={(e) => setContributionFrequency(e.target.value as ContributionFrequency)}
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      {contributionOptions.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button
                  onClick={calculateCompoundInterest}
                  className="w-full bg-green-600 hover:bg-green-700"
                  size="lg"
                >
                  Calculate Growth
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Future Value</p>
                      <p className="text-4xl font-bold text-green-600 mb-2">{formatCurrency(result.futureValue)}</p>
                    </div>

                    {/* Breakdown */}
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Principal</p>
                        <p className="text-sm font-semibold text-foreground">
                          {formatCurrency(Number.parseFloat(principal) || 0)}
                        </p>
                        <p className="text-xs text-muted-foreground">{result.principalPercentage.toFixed(1)}%</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Contributions</p>
                        <p className="text-sm font-semibold text-blue-600">
                          {formatCurrency(result.totalContributions)}
                        </p>
                        <p className="text-xs text-muted-foreground">{result.contributionsPercentage.toFixed(1)}%</p>
                      </div>
                      <div className="text-center p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Interest</p>
                        <p className="text-sm font-semibold text-green-600">{formatCurrency(result.totalInterest)}</p>
                        <p className="text-xs text-muted-foreground">{result.interestPercentage.toFixed(1)}%</p>
                      </div>
                    </div>

                    {/* Visual Progress Bar */}
                    <div className="h-4 rounded-full overflow-hidden flex mb-4">
                      <div
                        className="bg-gray-400 transition-all"
                        style={{ width: `${result.principalPercentage}%` }}
                        title="Principal"
                      />
                      <div
                        className="bg-blue-500 transition-all"
                        style={{ width: `${result.contributionsPercentage}%` }}
                        title="Contributions"
                      />
                      <div
                        className="bg-green-500 transition-all"
                        style={{ width: `${result.interestPercentage}%` }}
                        title="Interest"
                      />
                    </div>

                    <div className="flex items-center justify-center gap-4 text-xs mb-4">
                      <div className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-gray-400" />
                        <span>Principal</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-blue-500" />
                        <span>Contributions</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-3 h-3 rounded bg-green-500" />
                        <span>Interest</span>
                      </div>
                    </div>

                    {/* Growth Table Toggle */}
                    {result.growthTable.length > 0 && (
                      <button
                        onClick={() => setShowGrowthTable(!showGrowthTable)}
                        className="w-full flex items-center justify-center gap-2 py-2 text-sm text-green-700 hover:text-green-800 transition-colors"
                      >
                        {showGrowthTable ? (
                          <>
                            <ChevronUp className="h-4 w-4" />
                            Hide Growth Table
                          </>
                        ) : (
                          <>
                            <ChevronDown className="h-4 w-4" />
                            View Growth Table
                          </>
                        )}
                      </button>
                    )}

                    {/* Growth Table */}
                    {showGrowthTable && result.growthTable.length > 0 && (
                      <div className="mt-4 max-h-64 overflow-y-auto">
                        <table className="w-full text-xs">
                          <thead className="bg-green-100 sticky top-0">
                            <tr>
                              <th className="p-2 text-left">Year</th>
                              <th className="p-2 text-right">Start</th>
                              <th className="p-2 text-right">Interest</th>
                              <th className="p-2 text-right">End</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.growthTable.map((row) => (
                              <tr key={row.year} className="border-b border-green-100">
                                <td className="p-2">{row.year}</td>
                                <td className="p-2 text-right">{formatCurrency(row.startBalance)}</td>
                                <td className="p-2 text-right text-green-600">+{formatCurrency(row.interest)}</td>
                                <td className="p-2 text-right font-medium">{formatCurrency(row.endBalance)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Compounding Frequency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Annually</span>
                      <span className="text-sm text-muted-foreground">1x per year</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Semi-annually</span>
                      <span className="text-sm text-muted-foreground">2x per year</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Quarterly</span>
                      <span className="text-sm text-muted-foreground">4x per year</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Monthly</span>
                      <span className="text-sm text-green-600">12x per year (most common)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <span className="font-medium">Daily</span>
                      <span className="text-sm text-muted-foreground">365x per year</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Compound Interest Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">A = P(1 + r/n)^(nt)</p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>A</strong> = Final amount
                    </p>
                    <p>
                      <strong>P</strong> = Principal (initial investment)
                    </p>
                    <p>
                      <strong>r</strong> = Annual interest rate (decimal)
                    </p>
                    <p>
                      <strong>n</strong> = Compounding frequency per year
                    </p>
                    <p>
                      <strong>t</strong> = Time in years
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only. Actual investment returns may vary based on market
                        conditions, fees, taxes, and other factors. Consult a financial advisor for personalized advice.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Compound Interest?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Compound interest is often called the "eighth wonder of the world" and for good reason. Unlike simple
                  interest, which is calculated only on the principal amount, compound interest is calculated on both
                  the initial principal and the accumulated interest from previous periods. This means your money earns
                  interest on interest, creating an exponential growth effect over time that can significantly
                  accelerate wealth building.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept was reportedly described by Albert Einstein as the most powerful force in the universe.
                  Whether or not he actually said this, the mathematical reality is undeniable: compound interest can
                  turn modest savings into substantial wealth given enough time. A person who starts investing $200 per
                  month at age 25 will typically accumulate far more wealth by retirement than someone who invests $400
                  per month starting at age 45, purely due to the extra years of compounding.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Percent className="h-5 w-5 text-primary" />
                  <CardTitle>How Compounding Frequency Affects Growth</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The frequency at which interest compounds can have a meaningful impact on your final returns. When
                  interest compounds more frequently, your money has more opportunities to earn interest on previously
                  earned interest. For example, with monthly compounding, interest is added to your account 12 times per
                  year, each time becoming part of the principal that earns interest the following month.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Consider a $10,000 investment at 6% annual interest over 10 years. With annual compounding, you would
                  end up with approximately $17,908. With monthly compounding, that figure rises to about $18,194—nearly
                  $300 more, simply from more frequent compounding. While the difference may seem modest over shorter
                  periods, it becomes increasingly significant over longer investment horizons and with larger principal
                  amounts.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PiggyBank className="h-5 w-5 text-primary" />
                  <CardTitle>The Power of Regular Contributions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the initial principal is important, regular contributions can dramatically accelerate your
                  wealth building through a strategy called dollar-cost averaging. By consistently adding to your
                  investment, you not only increase the total amount working for you but also benefit from purchasing
                  investments at various price points over time, potentially reducing the impact of market volatility.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, starting with $5,000 and contributing $500 monthly at 7% annual interest, you would
                  accumulate over $180,000 in 15 years. Of that amount, only $95,000 would be from your
                  contributions—the remaining $85,000+ would be growth from compound interest. This illustrates why
                  financial advisors often emphasize the importance of consistent saving habits over trying to time the
                  market.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Time: Your Greatest Investment Ally</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Time is the most crucial factor in compound interest calculations. The longer your money remains
                  invested, the more dramatic the compounding effect becomes. This is why starting early, even with
                  smaller amounts, often outperforms starting later with larger contributions. The rule of 72 provides a
                  quick way to estimate how long it takes to double your money: divide 72 by your annual interest rate.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  At 8% annual return, your money doubles approximately every 9 years. This means a $10,000 investment
                  could become $20,000 in 9 years, $40,000 in 18 years, and $80,000 in 27 years—all without any
                  additional contributions. Understanding this exponential growth helps explain why retirement accounts
                  and long-term investment strategies are so effective at building wealth.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Tips for Maximizing Compound Interest</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To make the most of compound interest, start investing as early as possible—even small amounts add up
                  significantly over decades. Choose investments with competitive returns appropriate for your risk
                  tolerance and time horizon. Reinvest all dividends and interest rather than withdrawing them, as this
                  keeps your full balance working for you.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Minimize fees and expenses, as even small percentage differences compound over time and can
                  significantly impact your final balance. Consider tax-advantaged accounts like 401(k)s and IRAs, which
                  allow your investments to compound without annual tax drag. Finally, automate your contributions to
                  ensure consistent investing regardless of market conditions or competing financial priorities.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
