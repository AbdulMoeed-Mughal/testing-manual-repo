"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Wind, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

interface WindPowerResult {
  powerInWind: number
  turbineOutput: number
  dailyEnergy: number
  monthlyEnergy: number
  yearlyEnergy: number
  sweptArea: number
  capacityFactor: number
}

export function WindPowerCalculator() {
  const [inputMode, setInputMode] = useState<"diameter" | "area">("diameter")
  const [rotorDiameter, setRotorDiameter] = useState("")
  const [sweptArea, setSweptArea] = useState("")
  const [windSpeed, setWindSpeed] = useState("")
  const [airDensity, setAirDensity] = useState("1.225")
  const [efficiency, setEfficiency] = useState("35")
  const [ratedPower, setRatedPower] = useState("")
  const [outputUnit, setOutputUnit] = useState<"W" | "kW">("kW")
  const [energyUnit, setEnergyUnit] = useState<"Wh" | "kWh">("kWh")
  const [operatingHours, setOperatingHours] = useState("24")
  const [result, setResult] = useState<WindPowerResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [useRatedPowerCap, setUseRatedPowerCap] = useState(true)

  const calculate = () => {
    setError("")
    setResult(null)

    const windSpeedNum = Number.parseFloat(windSpeed)
    const airDensityNum = Number.parseFloat(airDensity)
    const efficiencyNum = Number.parseFloat(efficiency) / 100
    const ratedPowerNum = Number.parseFloat(ratedPower) || Number.POSITIVE_INFINITY
    const hoursNum = Number.parseFloat(operatingHours)

    if (isNaN(windSpeedNum) || windSpeedNum <= 0) {
      setError("Please enter a valid wind speed greater than 0")
      return
    }

    if (isNaN(airDensityNum) || airDensityNum <= 0) {
      setError("Please enter a valid air density greater than 0")
      return
    }

    if (isNaN(efficiencyNum) || efficiencyNum <= 0 || efficiencyNum > 1) {
      setError("Please enter a valid efficiency between 0 and 100%")
      return
    }

    if (isNaN(hoursNum) || hoursNum <= 0 || hoursNum > 24) {
      setError("Please enter valid operating hours between 0 and 24")
      return
    }

    let area: number
    if (inputMode === "diameter") {
      const diameterNum = Number.parseFloat(rotorDiameter)
      if (isNaN(diameterNum) || diameterNum <= 0) {
        setError("Please enter a valid rotor diameter greater than 0")
        return
      }
      area = Math.PI * Math.pow(diameterNum / 2, 2)
    } else {
      const areaNum = Number.parseFloat(sweptArea)
      if (isNaN(areaNum) || areaNum <= 0) {
        setError("Please enter a valid swept area greater than 0")
        return
      }
      area = areaNum
    }

    // Power in wind: P = 0.5 × ρ × A × v³
    const powerInWind = 0.5 * airDensityNum * area * Math.pow(windSpeedNum, 3)

    // Turbine output with efficiency (Betz limit theoretical max is ~59.3%)
    let turbineOutput = powerInWind * efficiencyNum

    // Apply rated power cap if enabled
    const ratedPowerWatts = ratedPowerNum * (outputUnit === "kW" ? 1000 : 1)
    if (useRatedPowerCap && ratedPowerNum !== Number.POSITIVE_INFINITY && turbineOutput > ratedPowerWatts) {
      turbineOutput = ratedPowerWatts
    }

    // Calculate capacity factor (actual output / rated output)
    const capacityFactor = ratedPowerNum !== Number.POSITIVE_INFINITY ? (turbineOutput / ratedPowerWatts) * 100 : 0

    // Energy calculations
    const dailyEnergy = turbineOutput * hoursNum
    const monthlyEnergy = dailyEnergy * 30
    const yearlyEnergy = dailyEnergy * 365

    setResult({
      powerInWind,
      turbineOutput,
      dailyEnergy,
      monthlyEnergy,
      yearlyEnergy,
      sweptArea: area,
      capacityFactor,
    })
  }

  const handleReset = () => {
    setRotorDiameter("")
    setSweptArea("")
    setWindSpeed("")
    setAirDensity("1.225")
    setEfficiency("35")
    setRatedPower("")
    setOperatingHours("24")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const formatPower = (watts: number): string => {
    if (outputUnit === "kW") {
      return (watts / 1000).toFixed(2) + " kW"
    }
    return watts.toFixed(2) + " W"
  }

  const formatEnergy = (wattHours: number): string => {
    if (energyUnit === "kWh") {
      return (wattHours / 1000).toFixed(2) + " kWh"
    }
    return wattHours.toFixed(2) + " Wh"
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Wind Power Calculator Results:
Power Output: ${formatPower(result.turbineOutput)}
Daily Energy: ${formatEnergy(result.dailyEnergy)}
Monthly Energy: ${formatEnergy(result.monthlyEnergy)}
Yearly Energy: ${formatEnergy(result.yearlyEnergy)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Wind Power Calculator Results",
          text: `Wind Power Output: ${formatPower(result.turbineOutput)}, Yearly Energy: ${formatEnergy(result.yearlyEnergy)}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Wind className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Wind Power Calculator</CardTitle>
                    <CardDescription>Estimate wind turbine energy output</CardDescription>
                  </div>
                </div>

                {/* Input Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Input Mode</span>
                  <button
                    onClick={() => setInputMode(inputMode === "diameter" ? "area" : "diameter")}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        inputMode === "area" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "diameter" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Diameter
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        inputMode === "area" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Swept Area
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Rotor Input */}
                {inputMode === "diameter" ? (
                  <div className="space-y-2">
                    <Label htmlFor="diameter">Rotor Diameter (m)</Label>
                    <Input
                      id="diameter"
                      type="number"
                      placeholder="Enter rotor diameter in meters"
                      value={rotorDiameter}
                      onChange={(e) => setRotorDiameter(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="area">Swept Area (m²)</Label>
                    <Input
                      id="area"
                      type="number"
                      placeholder="Enter swept area in m²"
                      value={sweptArea}
                      onChange={(e) => setSweptArea(e.target.value)}
                      min="0"
                      step="0.1"
                    />
                  </div>
                )}

                {/* Wind Speed */}
                <div className="space-y-2">
                  <Label htmlFor="windSpeed">Average Wind Speed (m/s)</Label>
                  <Input
                    id="windSpeed"
                    type="number"
                    placeholder="Enter average wind speed"
                    value={windSpeed}
                    onChange={(e) => setWindSpeed(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Rated Power */}
                <div className="space-y-2">
                  <Label htmlFor="ratedPower">Turbine Rated Power (optional)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="ratedPower"
                      type="number"
                      placeholder="Enter rated power"
                      value={ratedPower}
                      onChange={(e) => setRatedPower(e.target.value)}
                      min="0"
                      step="0.1"
                      className="flex-1"
                    />
                    <Select value={outputUnit} onValueChange={(v) => setOutputUnit(v as "W" | "kW")}>
                      <SelectTrigger className="w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="W">W</SelectItem>
                        <SelectItem value="kW">kW</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Rated Power Cap Toggle */}
                {ratedPower && (
                  <div className="flex items-center justify-between">
                    <Label htmlFor="ratedCap" className="text-sm">
                      Apply Rated Power Cap
                    </Label>
                    <Switch id="ratedCap" checked={useRatedPowerCap} onCheckedChange={setUseRatedPowerCap} />
                  </div>
                )}

                {/* Air Density */}
                <div className="space-y-2">
                  <Label htmlFor="airDensity">Air Density (kg/m³)</Label>
                  <Input
                    id="airDensity"
                    type="number"
                    placeholder="Default: 1.225 kg/m³"
                    value={airDensity}
                    onChange={(e) => setAirDensity(e.target.value)}
                    min="0"
                    step="0.001"
                  />
                </div>

                {/* Efficiency */}
                <div className="space-y-2">
                  <Label htmlFor="efficiency">System Efficiency (%)</Label>
                  <Input
                    id="efficiency"
                    type="number"
                    placeholder="Enter efficiency (max ~59.3% Betz limit)"
                    value={efficiency}
                    onChange={(e) => setEfficiency(e.target.value)}
                    min="0"
                    max="100"
                    step="1"
                  />
                </div>

                {/* Operating Hours */}
                <div className="space-y-2">
                  <Label htmlFor="hours">Daily Operating Hours</Label>
                  <Input
                    id="hours"
                    type="number"
                    placeholder="Hours per day"
                    value={operatingHours}
                    onChange={(e) => setOperatingHours(e.target.value)}
                    min="0"
                    max="24"
                    step="0.5"
                  />
                </div>

                {/* Energy Unit Selection */}
                <div className="space-y-2">
                  <Label>Energy Output Unit</Label>
                  <Select value={energyUnit} onValueChange={(v) => setEnergyUnit(v as "Wh" | "kWh")}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Wh">Watt-hours (Wh)</SelectItem>
                      <SelectItem value="kWh">Kilowatt-hours (kWh)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Wind Power
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Power Output</p>
                      <p className="text-4xl font-bold text-cyan-600 mb-1">{formatPower(result.turbineOutput)}</p>
                      {ratedPower && (
                        <p className="text-sm text-cyan-700">Capacity Factor: {result.capacityFactor.toFixed(1)}%</p>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center mb-4">
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Daily</p>
                        <p className="font-semibold text-cyan-700">{formatEnergy(result.dailyEnergy)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Monthly</p>
                        <p className="font-semibold text-cyan-700">{formatEnergy(result.monthlyEnergy)}</p>
                      </div>
                      <div className="p-2 bg-white rounded-lg">
                        <p className="text-xs text-muted-foreground">Yearly</p>
                        <p className="font-semibold text-cyan-700">{formatEnergy(result.yearlyEnergy)}</p>
                      </div>
                    </div>

                    {/* Step-by-Step Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full flex items-center justify-between p-2 bg-white rounded-lg text-sm font-medium text-cyan-700 hover:bg-cyan-100 transition-colors"
                    >
                      <span>Step-by-Step Solution</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-3 p-3 bg-white rounded-lg text-sm space-y-2">
                        <p>
                          <strong>Step 1:</strong> Calculate swept area
                        </p>
                        <p className="text-muted-foreground pl-4">
                          {inputMode === "diameter"
                            ? `A = π × (d/2)² = π × (${rotorDiameter}/2)² = ${result.sweptArea.toFixed(2)} m²`
                            : `A = ${result.sweptArea.toFixed(2)} m² (given)`}
                        </p>
                        <p>
                          <strong>Step 2:</strong> Calculate power in wind
                        </p>
                        <p className="text-muted-foreground pl-4">P_wind = 0.5 × ρ × A × v³</p>
                        <p className="text-muted-foreground pl-4">
                          P_wind = 0.5 × {airDensity} × {result.sweptArea.toFixed(2)} × {windSpeed}³
                        </p>
                        <p className="text-muted-foreground pl-4">P_wind = {result.powerInWind.toFixed(2)} W</p>
                        <p>
                          <strong>Step 3:</strong> Apply efficiency
                        </p>
                        <p className="text-muted-foreground pl-4">
                          P_turbine = P_wind × η = {result.powerInWind.toFixed(2)} ×{" "}
                          {Number.parseFloat(efficiency) / 100}
                        </p>
                        <p className="text-muted-foreground pl-4">P_turbine = {formatPower(result.turbineOutput)}</p>
                        {ratedPower && useRatedPowerCap && (
                          <>
                            <p>
                              <strong>Step 4:</strong> Apply rated power cap
                            </p>
                            <p className="text-muted-foreground pl-4">
                              Rated Power = {ratedPower} {outputUnit} (cap applied if exceeded)
                            </p>
                          </>
                        )}
                        <p>
                          <strong>Step {ratedPower && useRatedPowerCap ? "5" : "4"}:</strong> Calculate energy output
                        </p>
                        <p className="text-muted-foreground pl-4">
                          Daily = {formatPower(result.turbineOutput)} × {operatingHours}h ={" "}
                          {formatEnergy(result.dailyEnergy)}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Wind Power Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center mb-4">
                    <p className="font-semibold text-foreground">P = 0.5 × ρ × A × v³</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>
                      <strong>P</strong> = Power in wind (W)
                    </p>
                    <p>
                      <strong>ρ</strong> = Air density (kg/m³)
                    </p>
                    <p>
                      <strong>A</strong> = Swept area (m²)
                    </p>
                    <p>
                      <strong>v</strong> = Wind speed (m/s)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Wind Speeds</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Light Breeze</span>
                      <span className="text-sm text-blue-600">1.6-3.3 m/s</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Moderate Wind</span>
                      <span className="text-sm text-green-600">5.5-7.9 m/s</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Fresh Wind</span>
                      <span className="text-sm text-yellow-600">8.0-10.7 m/s</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Strong Wind</span>
                      <span className="text-sm text-orange-600">10.8-13.8 m/s</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Betz Limit</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <p>
                    The <strong>Betz limit</strong> (59.3%) is the theoretical maximum efficiency of a wind turbine.
                    Real-world turbines typically achieve 35-45% efficiency.
                  </p>
                  <p>
                    Factors affecting efficiency include blade design, generator efficiency, gearbox losses, and wind
                    variability.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="mt-8">
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-amber-800">
                    <strong>Disclaimer:</strong> Wind power calculations are estimates. Actual energy generation may
                    vary due to wind fluctuations, turbine design, and environmental factors. Consult manufacturer
                    specifications for precise performance.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Wind Power</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Wind power is one of the fastest-growing renewable energy sources worldwide. Wind turbines convert the
                  kinetic energy of moving air into electrical energy through the rotation of blades connected to a
                  generator. The power available in the wind is proportional to the cube of the wind speed, meaning that
                  even small increases in wind speed can significantly increase power output.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The swept area of the turbine blades is another critical factor. Larger rotor diameters capture more
                  wind energy, which is why modern utility-scale turbines have blade spans exceeding 100 meters.
                  However, larger turbines also require stronger structural components and more sophisticated control
                  systems.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Wind className="h-5 w-5 text-primary" />
                  <CardTitle>Factors Affecting Wind Turbine Performance</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Several factors influence the actual power output of a wind turbine. Air density varies with altitude,
                  temperature, and humidity - denser air contains more energy. Wind speed is rarely constant, so
                  capacity factor (actual output vs. rated output) is typically 25-45% for most wind farms.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Turbine efficiency is limited by the Betz limit of approximately 59.3%, which represents the maximum
                  theoretical efficiency of any wind turbine. Modern turbines achieve efficiencies of 35-45%, accounting
                  for aerodynamic, mechanical, and electrical losses in the system.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
