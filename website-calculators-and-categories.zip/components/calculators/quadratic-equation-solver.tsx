"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  Lightbulb,
  BookOpen,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface QuadraticResult {
  discriminant: number
  rootType: "real-distinct" | "real-repeated" | "complex"
  x1: string
  x2: string
  x1Real?: number
  x2Real?: number
  steps: string[]
}

export function QuadraticEquationSolver() {
  const [a, setA] = useState("")
  const [b, setB] = useState("")
  const [c, setC] = useState("")
  const [result, setResult] = useState<QuadraticResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const solveEquation = () => {
    setError("")
    setResult(null)

    const aNum = Number.parseFloat(a)
    const bNum = Number.parseFloat(b)
    const cNum = Number.parseFloat(c)

    if (isNaN(aNum) || isNaN(bNum) || isNaN(cNum)) {
      setError("Please enter valid numeric coefficients")
      return
    }

    if (aNum === 0) {
      setError("Coefficient 'a' cannot be zero (this would not be a quadratic equation)")
      return
    }

    if (aNum === 0 && bNum === 0 && cNum === 0) {
      setError("All coefficients cannot be zero")
      return
    }

    const steps: string[] = []

    // Step 1: Show the equation
    const aSign = aNum >= 0 ? "" : ""
    const bSign = bNum >= 0 ? "+" : "-"
    const cSign = cNum >= 0 ? "+" : "-"
    steps.push(`Equation: ${aNum}x² ${bSign} ${Math.abs(bNum)}x ${cSign} ${Math.abs(cNum)} = 0`)

    // Step 2: Calculate discriminant
    const discriminant = bNum * bNum - 4 * aNum * cNum
    steps.push(`Discriminant (D) = b² - 4ac`)
    steps.push(`D = (${bNum})² - 4(${aNum})(${cNum})`)
    steps.push(`D = ${bNum * bNum} - ${4 * aNum * cNum}`)
    steps.push(`D = ${discriminant}`)

    let rootType: "real-distinct" | "real-repeated" | "complex"
    let x1: string
    let x2: string
    let x1Real: number | undefined
    let x2Real: number | undefined

    if (discriminant > 0) {
      // Two real distinct roots
      rootType = "real-distinct"
      steps.push(`Since D > 0, the equation has two real and distinct roots`)

      const sqrtD = Math.sqrt(discriminant)
      x1Real = (-bNum + sqrtD) / (2 * aNum)
      x2Real = (-bNum - sqrtD) / (2 * aNum)

      steps.push(`√D = √${discriminant} ≈ ${sqrtD.toFixed(6)}`)
      steps.push(`x₁ = (-b + √D) / (2a) = (${-bNum} + ${sqrtD.toFixed(4)}) / ${2 * aNum}`)
      steps.push(`x₁ ≈ ${x1Real.toFixed(6)}`)
      steps.push(`x₂ = (-b - √D) / (2a) = (${-bNum} - ${sqrtD.toFixed(4)}) / ${2 * aNum}`)
      steps.push(`x₂ ≈ ${x2Real.toFixed(6)}`)

      x1 = x1Real.toFixed(6).replace(/\.?0+$/, "")
      x2 = x2Real.toFixed(6).replace(/\.?0+$/, "")
    } else if (discriminant === 0) {
      // One real repeated root
      rootType = "real-repeated"
      steps.push(`Since D = 0, the equation has one real repeated root`)

      x1Real = -bNum / (2 * aNum)
      x2Real = x1Real

      steps.push(`x = -b / (2a) = ${-bNum} / ${2 * aNum}`)
      steps.push(`x = ${x1Real.toFixed(6)}`)

      x1 = x1Real.toFixed(6).replace(/\.?0+$/, "")
      x2 = x1
    } else {
      // Two complex roots
      rootType = "complex"
      steps.push(`Since D < 0, the equation has two complex conjugate roots`)

      const realPart = -bNum / (2 * aNum)
      const imagPart = Math.sqrt(Math.abs(discriminant)) / (2 * aNum)

      steps.push(`Real part = -b / (2a) = ${-bNum} / ${2 * aNum} = ${realPart.toFixed(6)}`)
      steps.push(`Imaginary part = √|D| / (2a) = √${Math.abs(discriminant)} / ${2 * aNum} ≈ ${imagPart.toFixed(6)}`)

      const realStr = realPart.toFixed(4).replace(/\.?0+$/, "")
      const imagStr = Math.abs(imagPart)
        .toFixed(4)
        .replace(/\.?0+$/, "")

      x1 = `${realStr} + ${imagStr}i`
      x2 = `${realStr} - ${imagStr}i`

      steps.push(`x₁ = ${x1}`)
      steps.push(`x₂ = ${x2}`)
    }

    setResult({
      discriminant,
      rootType,
      x1,
      x2,
      x1Real,
      x2Real,
      steps,
    })
  }

  const handleReset = () => {
    setA("")
    setB("")
    setC("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text =
        result.rootType === "real-repeated"
          ? `Quadratic Equation: ${a}x² + ${b}x + ${c} = 0\nRoot: x = ${result.x1}`
          : `Quadratic Equation: ${a}x² + ${b}x + ${c} = 0\nRoots: x₁ = ${result.x1}, x₂ = ${result.x2}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const text =
          result.rootType === "real-repeated"
            ? `Solved: ${a}x² + ${b}x + ${c} = 0. Root: x = ${result.x1}`
            : `Solved: ${a}x² + ${b}x + ${c} = 0. Roots: x₁ = ${result.x1}, x₂ = ${result.x2}`
        await navigator.share({
          title: "Quadratic Equation Solution",
          text: text,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getRootTypeLabel = () => {
    if (!result) return ""
    switch (result.rootType) {
      case "real-distinct":
        return "Two Real Distinct Roots"
      case "real-repeated":
        return "One Real Repeated Root"
      case "complex":
        return "Two Complex Conjugate Roots"
    }
  }

  const getRootTypeColor = () => {
    if (!result) return ""
    switch (result.rootType) {
      case "real-distinct":
        return "bg-green-50 border-green-200 text-green-700"
      case "real-repeated":
        return "bg-blue-50 border-blue-200 text-blue-700"
      case "complex":
        return "bg-purple-50 border-purple-200 text-purple-700"
    }
  }

  const getDiscriminantColor = () => {
    if (!result) return ""
    if (result.discriminant > 0) return "text-green-600"
    if (result.discriminant === 0) return "text-blue-600"
    return "text-purple-600"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Quadratic Equation Solver</CardTitle>
                    <CardDescription>Solve ax² + bx + c = 0</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Equation Display */}
                <div className="p-4 bg-muted rounded-lg text-center">
                  <p className="text-lg font-mono">
                    <span className="text-blue-600 font-bold">{a || "a"}</span>x² +{" "}
                    <span className="text-green-600 font-bold">{b || "b"}</span>x +{" "}
                    <span className="text-orange-600 font-bold">{c || "c"}</span> = 0
                  </p>
                </div>

                {/* Coefficient Inputs */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="a" className="text-blue-600 font-semibold">
                      a (x² coefficient)
                    </Label>
                    <Input
                      id="a"
                      type="number"
                      placeholder="e.g. 1"
                      value={a}
                      onChange={(e) => setA(e.target.value)}
                      step="any"
                      className="text-center"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="b" className="text-green-600 font-semibold">
                      b (x coefficient)
                    </Label>
                    <Input
                      id="b"
                      type="number"
                      placeholder="e.g. -5"
                      value={b}
                      onChange={(e) => setB(e.target.value)}
                      step="any"
                      className="text-center"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="c" className="text-orange-600 font-semibold">
                      c (constant)
                    </Label>
                    <Input
                      id="c"
                      type="number"
                      placeholder="e.g. 6"
                      value={c}
                      onChange={(e) => setC(e.target.value)}
                      step="any"
                      className="text-center"
                    />
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Solve Button */}
                <Button onClick={solveEquation} className="w-full" size="lg">
                  Solve Equation
                </Button>

                {/* Result */}
                {result && (
                  <div className="space-y-4 transition-all duration-300">
                    {/* Root Type Badge */}
                    <div className={`p-3 rounded-lg border text-center font-medium ${getRootTypeColor()}`}>
                      {getRootTypeLabel()}
                    </div>

                    {/* Discriminant */}
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="text-sm text-muted-foreground text-center">Discriminant (D)</p>
                      <p className={`text-2xl font-bold text-center ${getDiscriminantColor()}`}>
                        {result.discriminant.toFixed(4).replace(/\.?0+$/, "")}
                      </p>
                    </div>

                    {/* Roots */}
                    <div className="p-4 rounded-xl bg-blue-50 border-2 border-blue-200">
                      <p className="text-sm text-muted-foreground text-center mb-2">
                        {result.rootType === "real-repeated" ? "Root" : "Roots"}
                      </p>
                      {result.rootType === "real-repeated" ? (
                        <p className="text-3xl font-bold text-blue-600 text-center">x = {result.x1}</p>
                      ) : (
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center">
                            <p className="text-xs text-muted-foreground">x₁</p>
                            <p className="text-xl sm:text-2xl font-bold text-blue-600 break-all">{result.x1}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-xs text-muted-foreground">x₂</p>
                            <p className="text-xl sm:text-2xl font-bold text-blue-600 break-all">{result.x2}</p>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Step-by-Step Solution */}
                    <div>
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full flex items-center justify-between p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
                      >
                        <span className="font-medium flex items-center gap-2">
                          <Lightbulb className="h-4 w-4" />
                          Step-by-Step Solution
                        </span>
                        <span className="text-muted-foreground">{showSteps ? "▲" : "▼"}</span>
                      </button>
                      {showSteps && (
                        <div className="mt-2 p-4 rounded-lg border bg-card space-y-2">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-sm font-mono text-muted-foreground">
                              {step}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quadratic Formula</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="text-lg font-semibold text-foreground">x = (-b ± √(b² - 4ac)) / 2a</p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-3">
                    This formula gives the solutions (roots) of any quadratic equation in the form ax² + bx + c = 0.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Nature of Roots</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">D {">"} 0</span>
                      <span className="text-sm text-green-600">Two real distinct roots</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">D = 0</span>
                      <span className="text-sm text-blue-600">One real repeated root</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">D {"<"} 0</span>
                      <span className="text-sm text-purple-600">Two complex roots</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-600" />
                    Note
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    This calculator provides estimates only. Verify manually for critical calculations. Results are
                    rounded for display but calculations use full precision.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Quadratic Equation?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A quadratic equation is a second-degree polynomial equation in a single variable, typically written in
                  the standard form ax² + bx + c = 0, where x represents an unknown variable and a, b, and c are
                  constants with a ≠ 0. The term "quadratic" comes from "quadratus," the Latin word for square, because
                  the variable is squared (raised to the second power). Quadratic equations are fundamental in
                  mathematics and appear frequently in physics, engineering, economics, and many other fields.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The solutions to a quadratic equation, also called roots or zeros, are the values of x that make the
                  equation true. These roots represent the points where the parabola (the graph of a quadratic function)
                  crosses the x-axis. A quadratic equation can have two distinct real roots, one repeated real root, or
                  two complex conjugate roots, depending on the value of the discriminant.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>The Discriminant and Nature of Roots</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The discriminant, denoted as D or Δ, is the expression b² - 4ac found under the square root in the
                  quadratic formula. It plays a crucial role in determining the nature and number of roots without
                  actually solving the equation. The discriminant acts as a "discriminator" that tells us whether the
                  roots are real or complex, and whether they are distinct or equal.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">When D {">"} 0 (Positive Discriminant)</h4>
                    <p className="text-green-700 text-sm">
                      The equation has two distinct real roots. The parabola crosses the x-axis at two different points.
                      This is the most common case in practical applications. For example, x² - 5x + 6 = 0 has D = 1,
                      giving roots x = 2 and x = 3.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">When D = 0 (Zero Discriminant)</h4>
                    <p className="text-blue-700 text-sm">
                      The equation has exactly one real root (or two equal real roots). The parabola touches the x-axis
                      at exactly one point - the vertex. This root is called a "repeated" or "double" root. For example,
                      x² - 6x + 9 = 0 has D = 0, giving the repeated root x = 3.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">When D {"<"} 0 (Negative Discriminant)</h4>
                    <p className="text-purple-700 text-sm">
                      The equation has two complex conjugate roots. The parabola does not cross the x-axis at all. The
                      roots involve the imaginary unit i = √(-1). For example, x² + x + 1 = 0 has D = -3, giving roots x
                      = (-1 + i√3)/2 and x = (-1 - i√3)/2.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Methods for Solving Quadratic Equations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While the quadratic formula always works, there are several methods for solving quadratic equations,
                  each with its own advantages depending on the specific equation.
                </p>
                <div className="mt-4 space-y-3">
                  <p className="text-muted-foreground leading-relaxed">
                    <strong>Factoring:</strong> When the quadratic can be easily factored, this method is often the
                    quickest. For example, x² - 5x + 6 = (x - 2)(x - 3) = 0 immediately gives x = 2 or x = 3. However,
                    not all quadratics factor nicely with integer coefficients.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    <strong>Completing the Square:</strong> This method transforms the equation into a perfect square
                    trinomial. It's particularly useful for deriving the quadratic formula and for problems involving
                    circles and parabolas. The technique involves adding and subtracting (b/2a)² to create a perfect
                    square.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    <strong>Quadratic Formula:</strong> The most universal method, x = (-b ± √(b² - 4ac)) / 2a works for
                    any quadratic equation. It's especially useful when factoring is difficult or when dealing with
                    coefficients that aren't integers. This calculator uses this method for its reliability and
                    precision.
                  </p>
                  <p className="text-muted-foreground leading-relaxed">
                    <strong>Graphical Method:</strong> By plotting y = ax² + bx + c and finding where it crosses the
                    x-axis, you can visually identify the roots. While less precise than algebraic methods, it provides
                    valuable intuition about the nature and approximate values of the roots.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Quadratic equations appear in countless real-world situations. In physics, projectile motion follows a
                  parabolic path, and the height of an object thrown upward can be modeled by h(t) = -½gt² + v₀t + h₀,
                  where finding when h(t) = 0 tells us when the object hits the ground. Engineers use quadratic
                  equations to design parabolic antennas and bridges, calculate stress distributions, and optimize
                  electrical circuits.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In economics and business, quadratic equations model profit optimization, where the profit function
                  P(x) = -ax² + bx - c represents revenue minus costs. Finding the vertex gives the maximum profit
                  point. In finance, compound interest over time can create quadratic relationships. Even in everyday
                  situations like determining the dimensions of a garden with a fixed perimeter to maximize area, or
                  calculating braking distances, quadratic equations provide the mathematical framework for finding
                  solutions.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
