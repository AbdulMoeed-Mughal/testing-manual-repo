"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Heart,
  Info,
  Calendar,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Sparkles,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface FertilityResult {
  ovulationDate: Date
  fertileWindowStart: Date
  fertileWindowEnd: Date
  peakFertileDays: Date[]
  nextPeriodDate: Date
  cycleDay: number
  currentPhase: string
  phaseColor: string
  phaseBgColor: string
}

export function FertilityWindowCalculator() {
  const [lmpDate, setLmpDate] = useState("")
  const [cycleLength, setCycleLength] = useState("28")
  const [lutealPhaseLength, setLutealPhaseLength] = useState("14")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<FertilityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const formatDate = (date: Date): string => {
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const formatShortDate = (date: Date): string => {
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    })
  }

  const calculateFertilityWindow = () => {
    setError("")
    setResult(null)

    if (!lmpDate) {
      setError("Please enter the first day of your last menstrual period")
      return
    }

    const cycleLengthNum = Number.parseInt(cycleLength)
    const lutealLengthNum = Number.parseInt(lutealPhaseLength)

    if (isNaN(cycleLengthNum) || cycleLengthNum < 21 || cycleLengthNum > 45) {
      setError("Please enter a valid cycle length between 21 and 45 days")
      return
    }

    if (isNaN(lutealLengthNum) || lutealLengthNum < 10 || lutealLengthNum > 16) {
      setError("Please enter a valid luteal phase length between 10 and 16 days")
      return
    }

    const lmp = new Date(lmpDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (lmp > today) {
      setError("LMP date cannot be in the future")
      return
    }

    // Calculate ovulation day = LMP + (Cycle length − Luteal phase length)
    const ovulationDay = cycleLengthNum - lutealLengthNum
    const ovulationDate = new Date(lmp)
    ovulationDate.setDate(lmp.getDate() + ovulationDay)

    // Fertile window = Ovulation day − 5 days to Ovulation day
    const fertileWindowStart = new Date(ovulationDate)
    fertileWindowStart.setDate(ovulationDate.getDate() - 5)

    const fertileWindowEnd = new Date(ovulationDate)
    fertileWindowEnd.setDate(ovulationDate.getDate() + 1)

    // Peak fertile days (2 days before ovulation + ovulation day)
    const peakFertileDays: Date[] = []
    for (let i = 2; i >= 0; i--) {
      const peakDay = new Date(ovulationDate)
      peakDay.setDate(ovulationDate.getDate() - i)
      peakFertileDays.push(peakDay)
    }

    // Next menstrual period = LMP + Cycle length
    const nextPeriodDate = new Date(lmp)
    nextPeriodDate.setDate(lmp.getDate() + cycleLengthNum)

    // Calculate current cycle day
    const diffTime = today.getTime() - lmp.getTime()
    const cycleDay = Math.floor(diffTime / (1000 * 60 * 60 * 24)) + 1

    // Determine current phase
    let currentPhase: string
    let phaseColor: string
    let phaseBgColor: string

    if (cycleDay <= 5) {
      currentPhase = "Menstrual Phase"
      phaseColor = "text-red-600"
      phaseBgColor = "bg-red-50 border-red-200"
    } else if (cycleDay < ovulationDay - 5) {
      currentPhase = "Follicular Phase"
      phaseColor = "text-blue-600"
      phaseBgColor = "bg-blue-50 border-blue-200"
    } else if (cycleDay <= ovulationDay + 1) {
      currentPhase = "Fertile Window"
      phaseColor = "text-green-600"
      phaseBgColor = "bg-green-50 border-green-200"
    } else {
      currentPhase = "Luteal Phase"
      phaseColor = "text-purple-600"
      phaseBgColor = "bg-purple-50 border-purple-200"
    }

    setResult({
      ovulationDate,
      fertileWindowStart,
      fertileWindowEnd,
      peakFertileDays,
      nextPeriodDate,
      cycleDay,
      currentPhase,
      phaseColor,
      phaseBgColor,
    })
  }

  const handleReset = () => {
    setLmpDate("")
    setCycleLength("28")
    setLutealPhaseLength("14")
    setShowAdvanced(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Fertility Window: ${formatDate(result.fertileWindowStart)} to ${formatDate(result.fertileWindowEnd)}\nOvulation Date: ${formatDate(result.ovulationDate)}\nNext Period: ${formatDate(result.nextPeriodDate)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Fertility Window",
          text: `Fertility Window: ${formatDate(result.fertileWindowStart)} to ${formatDate(result.fertileWindowEnd)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600">
                    <Heart className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Fertility Window Calculator</CardTitle>
                    <CardDescription>Identify your fertile days for conception planning</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* LMP Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="lmp-date">First Day of Last Menstrual Period (LMP)</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="lmp-date"
                      type="date"
                      value={lmpDate}
                      onChange={(e) => setLmpDate(e.target.value)}
                      className="pl-10"
                      max={new Date().toISOString().split("T")[0]}
                    />
                  </div>
                </div>

                {/* Cycle Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="cycle-length">Average Cycle Length (days)</Label>
                  <Input
                    id="cycle-length"
                    type="number"
                    placeholder="28"
                    value={cycleLength}
                    onChange={(e) => setCycleLength(e.target.value)}
                    min="21"
                    max="45"
                  />
                  <p className="text-xs text-muted-foreground">Typical range: 21-35 days (average is 28)</p>
                </div>

                {/* Advanced Options Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="show-advanced" className="cursor-pointer">
                    Advanced Options
                  </Label>
                  <Switch id="show-advanced" checked={showAdvanced} onCheckedChange={setShowAdvanced} />
                </div>

                {/* Luteal Phase Length (Advanced) */}
                {showAdvanced && (
                  <div className="space-y-2 p-3 bg-muted/50 rounded-lg">
                    <Label htmlFor="luteal-length">Luteal Phase Length (days)</Label>
                    <Input
                      id="luteal-length"
                      type="number"
                      placeholder="14"
                      value={lutealPhaseLength}
                      onChange={(e) => setLutealPhaseLength(e.target.value)}
                      min="10"
                      max="16"
                    />
                    <p className="text-xs text-muted-foreground">
                      Typically 12-16 days, default is 14. Only adjust if you know your luteal phase.
                    </p>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateFertilityWindow} className="w-full" size="lg">
                  Calculate Fertility Window
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.phaseBgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Current Phase (Day {result.cycleDay})</p>
                      <p className={`text-2xl font-bold ${result.phaseColor}`}>{result.currentPhase}</p>
                    </div>

                    {/* Fertile Window */}
                    <div className="bg-white/80 rounded-lg p-3 mb-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="h-4 w-4 text-green-600" />
                        <span className="font-semibold text-green-700">Fertile Window</span>
                      </div>
                      <p className="text-lg font-medium text-center">
                        {formatShortDate(result.fertileWindowStart)} - {formatShortDate(result.fertileWindowEnd)}
                      </p>
                    </div>

                    {/* Ovulation Date */}
                    <div className="bg-white/80 rounded-lg p-3 mb-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="h-4 w-4 text-pink-600" />
                        <span className="font-semibold text-pink-700">Estimated Ovulation</span>
                      </div>
                      <p className="text-lg font-medium text-center">{formatDate(result.ovulationDate)}</p>
                    </div>

                    {/* Next Period */}
                    <div className="bg-white/80 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="h-4 w-4 text-red-600" />
                        <span className="font-semibold text-red-700">Next Period Expected</span>
                      </div>
                      <p className="text-lg font-medium text-center">{formatDate(result.nextPeriodDate)}</p>
                    </div>

                    {/* Details Toggle */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-3 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-3 pt-3 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Peak Fertility Days:</span>
                          <span className="font-medium text-green-600">
                            {result.peakFertileDays.map((d) => formatShortDate(d)).join(", ")}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Cycle Length:</span>
                          <span className="font-medium">{cycleLength} days</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Luteal Phase:</span>
                          <span className="font-medium">{lutealPhaseLength} days</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Ovulation Day:</span>
                          <span className="font-medium">Day {Number(cycleLength) - Number(lutealPhaseLength)}</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cycle Phases</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Menstrual Phase</span>
                      <span className="text-sm text-red-600">Days 1-5</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Follicular Phase</span>
                      <span className="text-sm text-blue-600">Days 6-13</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Fertile Window</span>
                      <span className="text-sm text-green-600">~6 days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Luteal Phase</span>
                      <span className="text-sm text-purple-600">~14 days</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Method</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">Ovulation = Cycle Length - Luteal Phase</p>
                  </div>
                  <p>
                    <strong>Fertile Window:</strong> 5 days before ovulation through 1 day after
                  </p>
                  <p>
                    <strong>Peak Fertility:</strong> 2 days before and day of ovulation
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Your Fertility Window</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The fertility window refers to the days during your menstrual cycle when pregnancy is possible. This
                  window typically spans about 6 days - the 5 days leading up to ovulation and the day of ovulation
                  itself. Understanding your fertility window is essential whether you're trying to conceive or
                  practicing fertility awareness for contraception.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Sperm can survive in the female reproductive tract for up to 5 days, while an egg remains viable for
                  only 12-24 hours after ovulation. This is why the days leading up to ovulation are actually more
                  fertile than the days after. The highest probability of conception occurs on the two days before
                  ovulation and the day of ovulation itself.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Signs of Ovulation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  While this calculator provides estimates based on average cycle patterns, your body may give you
                  physical signs of ovulation that can help confirm your fertile window:
                </p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="p-3 bg-pink-50 border border-pink-200 rounded-lg">
                    <h4 className="font-semibold text-pink-800 mb-1">Cervical Mucus Changes</h4>
                    <p className="text-pink-700 text-sm">
                      Becomes clear, stretchy, and egg-white like during fertile days
                    </p>
                  </div>
                  <div className="p-3 bg-pink-50 border border-pink-200 rounded-lg">
                    <h4 className="font-semibold text-pink-800 mb-1">Basal Body Temperature</h4>
                    <p className="text-pink-700 text-sm">
                      Slight rise (0.5-1°F) after ovulation confirms it has occurred
                    </p>
                  </div>
                  <div className="p-3 bg-pink-50 border border-pink-200 rounded-lg">
                    <h4 className="font-semibold text-pink-800 mb-1">Ovulation Pain (Mittelschmerz)</h4>
                    <p className="text-pink-700 text-sm">Mild one-sided abdominal discomfort during ovulation</p>
                  </div>
                  <div className="p-3 bg-pink-50 border border-pink-200 rounded-lg">
                    <h4 className="font-semibold text-pink-800 mb-1">LH Surge Detection</h4>
                    <p className="text-pink-700 text-sm">
                      Ovulation predictor kits detect the hormone surge 24-36 hours before ovulation
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Conception</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Timing Intercourse</h4>
                    <p className="text-green-700 text-sm">
                      For the best chances of conception, have intercourse every 1-2 days during your fertile window,
                      especially the 2-3 days before expected ovulation. This ensures sperm are present when the egg is
                      released.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Track Your Cycles</h4>
                    <p className="text-blue-700 text-sm">
                      Keep track of your cycle length for several months to better understand your pattern. Cycle length
                      can vary, and knowing your average helps improve prediction accuracy.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Healthy Lifestyle</h4>
                    <p className="text-purple-700 text-sm">
                      Maintain a healthy weight, eat a balanced diet, limit caffeine and alcohol, manage stress, and
                      take prenatal vitamins with folic acid to optimize fertility.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Fertility window predictions are estimates based on average cycle patterns and may vary due to
                  individual cycle variations, stress, illness, or hormonal changes. This calculator should not be used
                  as a sole method of contraception or as a substitute for professional medical advice. Consult a
                  healthcare professional or fertility specialist for personalized guidance on conception planning or
                  fertility concerns.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
