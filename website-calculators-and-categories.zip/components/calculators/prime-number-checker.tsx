"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Hash,
  Info,
  AlertTriangle,
  Calculator,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

type CheckMethod = "basic" | "optimized"

interface PrimeResult {
  number: number
  isPrime: boolean
  status: "prime" | "composite" | "neither"
  smallestDivisor?: number
  primeFactors?: { factor: number; power: number }[]
  steps: string[]
}

interface RangeResult {
  primes: number[]
  count: number
}

export function PrimeNumberChecker() {
  const [number, setNumber] = useState("")
  const [upperLimit, setUpperLimit] = useState("")
  const [method, setMethod] = useState<CheckMethod>("optimized")
  const [showSteps, setShowSteps] = useState(true)
  const [showRange, setShowRange] = useState(false)
  const [result, setResult] = useState<PrimeResult | null>(null)
  const [rangeResult, setRangeResult] = useState<RangeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [stepsOpen, setStepsOpen] = useState(true)
  const [rangeOpen, setRangeOpen] = useState(false)

  const getPrimeFactors = (n: number): { factor: number; power: number }[] => {
    const factors: { factor: number; power: number }[] = []
    let num = Math.abs(n)

    for (let i = 2; i * i <= num; i++) {
      if (num % i === 0) {
        let power = 0
        while (num % i === 0) {
          num /= i
          power++
        }
        factors.push({ factor: i, power })
      }
    }

    if (num > 1) {
      factors.push({ factor: num, power: 1 })
    }

    return factors
  }

  const checkPrime = (
    n: number,
    useBasic: boolean,
  ): { isPrime: boolean; smallestDivisor?: number; steps: string[] } => {
    const steps: string[] = []
    const absN = Math.abs(n)

    steps.push(`Checking if ${n} is prime...`)

    if (n <= 1) {
      steps.push(`${n} ≤ 1, so it is neither prime nor composite by definition.`)
      return { isPrime: false, steps }
    }

    if (n === 2) {
      steps.push(`2 is the smallest and only even prime number.`)
      return { isPrime: true, steps }
    }

    if (n === 3) {
      steps.push(`3 is a prime number (only divisible by 1 and itself).`)
      return { isPrime: true, steps }
    }

    if (n % 2 === 0) {
      steps.push(`${n} is even (divisible by 2), so it is composite.`)
      return { isPrime: false, smallestDivisor: 2, steps }
    }

    steps.push(`${n} is odd, checking for divisors...`)

    if (useBasic) {
      steps.push(`Using basic trial division: checking all odd numbers from 3 to ${n - 1}`)
      for (let i = 3; i < n; i += 2) {
        if (n % i === 0) {
          steps.push(`Found divisor: ${n} ÷ ${i} = ${n / i}`)
          return { isPrime: false, smallestDivisor: i, steps }
        }
      }
    } else {
      const sqrtN = Math.floor(Math.sqrt(absN))
      steps.push(`Using optimized √n check: only need to check divisors up to √${n} ≈ ${sqrtN}`)

      // Check if divisible by 3
      if (n % 3 === 0) {
        steps.push(`${n} is divisible by 3, so it is composite.`)
        return { isPrime: false, smallestDivisor: 3, steps }
      }

      // Check divisors of form 6k±1 up to √n
      steps.push(`Checking divisors of form 6k±1 (5, 7, 11, 13, ...)`)
      for (let i = 5; i <= sqrtN; i += 6) {
        if (n % i === 0) {
          steps.push(`Found divisor: ${n} ÷ ${i} = ${n / i}`)
          return { isPrime: false, smallestDivisor: i, steps }
        }
        if (n % (i + 2) === 0) {
          steps.push(`Found divisor: ${n} ÷ ${i + 2} = ${n / (i + 2)}`)
          return { isPrime: false, smallestDivisor: i + 2, steps }
        }
      }
    }

    steps.push(`No divisors found. ${n} is prime!`)
    return { isPrime: true, steps }
  }

  const findPrimesInRange = (start: number, end: number): number[] => {
    const primes: number[] = []
    for (let i = Math.max(2, start); i <= end; i++) {
      const { isPrime } = checkPrime(i, false)
      if (isPrime) {
        primes.push(i)
      }
    }
    return primes
  }

  const handleCalculate = () => {
    setError("")
    setResult(null)
    setRangeResult(null)

    const num = Number.parseInt(number, 10)
    if (isNaN(num)) {
      setError("Please enter a valid integer")
      return
    }

    if (Math.abs(num) > 10000000) {
      setError("For performance reasons, please enter a number less than 10,000,000")
      return
    }

    const { isPrime, smallestDivisor, steps } = checkPrime(num, method === "basic")

    let status: "prime" | "composite" | "neither"
    if (num <= 1) {
      status = "neither"
    } else if (isPrime) {
      status = "prime"
    } else {
      status = "composite"
    }

    const primeFactors = status === "composite" ? getPrimeFactors(num) : undefined

    setResult({
      number: num,
      isPrime,
      status,
      smallestDivisor,
      primeFactors,
      steps,
    })

    // Check for range
    if (showRange && upperLimit) {
      const upper = Number.parseInt(upperLimit, 10)
      if (!isNaN(upper) && upper >= num && upper <= num + 1000) {
        const primes = findPrimesInRange(num, upper)
        setRangeResult({
          primes,
          count: primes.length,
        })
      } else if (upper > num + 1000) {
        setError("Range limit exceeded. Maximum range is 1000 numbers.")
      }
    }
  }

  const handleReset = () => {
    setNumber("")
    setUpperLimit("")
    setResult(null)
    setRangeResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = `${result.number} is ${result.status}`
      if (result.primeFactors) {
        text += `. Prime factorization: ${result.primeFactors.map((f) => (f.power > 1 ? `${f.factor}^${f.power}` : `${f.factor}`)).join(" × ")}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Prime Number Check Result",
          text: `I checked if ${result.number} is prime using CalcHub! Result: ${result.status}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "prime":
        return { text: "text-green-600", bg: "bg-green-50 border-green-200" }
      case "composite":
        return { text: "text-blue-600", bg: "bg-blue-50 border-blue-200" }
      case "neither":
        return { text: "text-gray-600", bg: "bg-gray-50 border-gray-200" }
      default:
        return { text: "text-gray-600", bg: "bg-gray-50 border-gray-200" }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Prime Number Checker</CardTitle>
                    <CardDescription>Check if a number is prime or composite</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="number">Number to Check</Label>
                  <Input
                    id="number"
                    type="number"
                    placeholder="Enter an integer (e.g., 17, 100, 997)"
                    value={number}
                    onChange={(e) => setNumber(e.target.value)}
                  />
                </div>

                {/* Method Selection */}
                <div className="space-y-2">
                  <Label>Check Method</Label>
                  <Select value={method} onValueChange={(v) => setMethod(v as CheckMethod)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="optimized">Optimized (√n check)</SelectItem>
                      <SelectItem value="basic">Basic Trial Division</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-steps">Show Step-by-Step</Label>
                  <Switch id="show-steps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Range Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-range">Find Primes in Range</Label>
                  <Switch id="show-range" checked={showRange} onCheckedChange={setShowRange} />
                </div>

                {/* Upper Limit for Range */}
                {showRange && (
                  <div className="space-y-2">
                    <Label htmlFor="upper-limit">Upper Limit (max 1000 from start)</Label>
                    <Input
                      id="upper-limit"
                      type="number"
                      placeholder="Enter upper limit"
                      value={upperLimit}
                      onChange={(e) => setUpperLimit(e.target.value)}
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={handleCalculate} className="w-full" size="lg">
                  Check Prime
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getStatusColor(result.status).bg} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Result</p>
                      <p className={`text-4xl font-bold ${getStatusColor(result.status).text} mb-2`}>
                        {result.status.charAt(0).toUpperCase() + result.status.slice(1)}
                      </p>
                      <p className="text-lg font-medium text-foreground">{result.number}</p>
                    </div>

                    {/* Smallest Divisor */}
                    {result.smallestDivisor && (
                      <div className="mt-4 p-3 bg-background rounded-lg">
                        <p className="text-sm text-muted-foreground">Smallest Divisor</p>
                        <p className="text-xl font-bold text-foreground">{result.smallestDivisor}</p>
                      </div>
                    )}

                    {/* Prime Factorization */}
                    {result.primeFactors && result.primeFactors.length > 0 && (
                      <div className="mt-4 p-3 bg-background rounded-lg">
                        <p className="text-sm text-muted-foreground mb-2">Prime Factorization</p>
                        <p className="text-lg font-mono font-semibold">
                          {result.number} ={" "}
                          {result.primeFactors.map((f, i) => (
                            <span key={i}>
                              {i > 0 && " × "}
                              {f.factor}
                              {f.power > 1 && <sup>{f.power}</sup>}
                            </span>
                          ))}
                        </p>
                      </div>
                    )}

                    {/* Step-by-Step */}
                    {showSteps && result.steps.length > 0 && (
                      <Collapsible open={stepsOpen} onOpenChange={setStepsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            Step-by-Step Explanation
                            {stepsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="mt-2 p-3 bg-background rounded-lg space-y-2">
                            {result.steps.map((step, i) => (
                              <div key={i} className="flex gap-2 text-sm">
                                <span className="text-muted-foreground font-mono">{i + 1}.</span>
                                <span className="text-foreground">{step}</span>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}

                {/* Range Result */}
                {rangeResult && (
                  <Collapsible open={rangeOpen} onOpenChange={setRangeOpen}>
                    <CollapsibleTrigger asChild>
                      <Button variant="outline" size="sm" className="w-full justify-between bg-transparent">
                        Primes in Range ({rangeResult.count} found)
                        {rangeOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <div className="mt-2 p-3 bg-muted rounded-lg">
                        <div className="flex flex-wrap gap-2">
                          {rangeResult.primes.map((p) => (
                            <span key={p} className="px-2 py-1 bg-green-100 text-green-700 rounded text-sm font-mono">
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Number Classifications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Prime</span>
                      <span className="text-sm text-green-600">Divisible only by 1 and itself</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Composite</span>
                      <span className="text-sm text-blue-600">Has other divisors</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">Neither</span>
                      <span className="text-sm text-gray-600">0, 1, and negative numbers</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">First 25 Prime Numbers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {[
                      2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97,
                    ].map((p) => (
                      <span key={p} className="px-2 py-1 bg-green-100 text-green-700 rounded text-sm font-mono">
                        {p}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Check Methods</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Optimized √n Check</p>
                    <p>
                      Only checks divisors up to √n since if n = a × b and a {">"} √n, then b {"<"} √n. Uses 6k±1
                      optimization.
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-1">Basic Trial Division</p>
                    <p>Checks all odd numbers from 3 to n-1. Slower but demonstrates the fundamental approach.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What Are Prime Numbers?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A prime number is a natural number greater than 1 that has no positive divisors other than 1 and
                  itself. In other words, a prime number can only be divided evenly by 1 and the number itself. The
                  first few prime numbers are 2, 3, 5, 7, 11, 13, 17, 19, 23, and 29.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Prime numbers are fundamental to number theory and have important applications in cryptography,
                  computer science, and mathematics. The number 2 is the only even prime number, as all other even
                  numbers are divisible by 2. Numbers greater than 1 that are not prime are called composite numbers.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How Primality Testing Works</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The most straightforward way to test if a number n is prime is trial division: check if n is divisible
                  by any integer from 2 to n-1. However, this can be optimized significantly by only checking up to √n,
                  since if n = a × b and both a and b were greater than √n, then a × b would be greater than n.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Further optimization uses the fact that all primes greater than 3 are of the form 6k±1. This means we
                  only need to check divisibility by 2, 3, and numbers of the form 6k±1 up to √n. For very large
                  numbers, probabilistic tests like Miller-Rabin are used.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  This prime number checker uses standard mathematical tests optimized for performance. For extremely
                  large numbers (beyond the calculator's limit), advanced probabilistic methods like Miller-Rabin or AKS
                  primality tests may be required for efficient verification.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
