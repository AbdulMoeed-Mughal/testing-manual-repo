"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Home, Info, Calculator, Building2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"

export function HouseConstructionCostCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [area, setArea] = useState("")
  const [costPerUnit, setCostPerUnit] = useState("")
  const [floors, setFloors] = useState("1")
  const [materialCost, setMaterialCost] = useState("")
  const [laborCost, setLaborCost] = useState("")
  const [finishingCost, setFinishingCost] = useState("")
  const [contingency, setContingency] = useState("10")
  const [currency, setCurrency] = useState<"USD" | "INR">("USD")
  const [result, setResult] = useState<{
    baseCost: number
    material: number
    labor: number
    finishing: number
    subtotal: number
    contingencyAmount: number
    totalCost: number
    costPerFloor: number
  } | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCost = () => {
    setError("")
    setResult(null)

    const areaNum = Number.parseFloat(area)
    const costNum = Number.parseFloat(costPerUnit)
    const floorsNum = Number.parseInt(floors) || 1
    const materialNum = Number.parseFloat(materialCost) || 0
    const laborNum = Number.parseFloat(laborCost) || 0
    const finishingNum = Number.parseFloat(finishingCost) || 0
    const contingencyNum = Number.parseFloat(contingency)

    if (isNaN(areaNum) || areaNum <= 0) {
      setError("Please enter a valid area greater than 0")
      return
    }

    if (isNaN(costNum) || costNum <= 0) {
      setError("Please enter a valid cost per unit area")
      return
    }

    if (floorsNum < 1) {
      setError("Number of floors must be at least 1")
      return
    }

    if (materialNum < 0 || laborNum < 0 || finishingNum < 0) {
      setError("Cost values cannot be negative")
      return
    }

    if (isNaN(contingencyNum) || contingencyNum < 0) {
      setError("Please enter a valid contingency percentage")
      return
    }

    const baseCost = areaNum * costNum
    const subtotal = baseCost + materialNum + laborNum + finishingNum
    const contingencyAmount = (subtotal * contingencyNum) / 100
    const totalCost = subtotal + contingencyAmount
    const costPerFloor = totalCost / floorsNum

    setResult({
      baseCost,
      material: materialNum,
      labor: laborNum,
      finishing: finishingNum,
      subtotal,
      contingencyAmount,
      totalCost,
      costPerFloor,
    })
  }

  const handleReset = () => {
    setArea("")
    setCostPerUnit("")
    setFloors("1")
    setMaterialCost("")
    setLaborCost("")
    setFinishingCost("")
    setContingency("10")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `House Construction Cost: ${currency === "USD" ? "$" : "₹"}${result.totalCost.toFixed(2)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "House Construction Cost Estimate",
          text: `My estimated house construction cost is ${currency === "USD" ? "$" : "₹"}${result.totalCost.toFixed(2)}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setArea("")
    setCostPerUnit("")
    setResult(null)
    setError("")
  }

  const toggleCurrency = () => {
    setCurrency((prev) => (prev === "USD" ? "INR" : "USD"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">House Construction Cost Calculator</CardTitle>
                    <CardDescription>Estimate total construction cost</CardDescription>
                  </div>
                </div>

                {/* Unit & Currency Toggle */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Unit System</span>
                    <button
                      onClick={toggleUnitSystem}
                      className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                    >
                      <span
                        className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                          unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                        }`}
                      />
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        m²
                      </span>
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        ft²
                      </span>
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Currency</span>
                    <button
                      onClick={toggleCurrency}
                      className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                    >
                      <span
                        className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                          currency === "INR" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                        }`}
                      />
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          currency === "USD" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        USD
                      </span>
                      <span
                        className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                          currency === "INR" ? "text-primary-foreground" : "text-muted-foreground"
                        }`}
                      >
                        INR
                      </span>
                    </button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Area Input */}
                <div className="space-y-2">
                  <Label htmlFor="area">
                    Built-up Area ({unitSystem === "metric" ? "m²" : "ft²"})
                  </Label>
                  <Input
                    id="area"
                    type="number"
                    placeholder="Enter built-up area"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Cost per Unit */}
                <div className="space-y-2">
                  <Label htmlFor="costPerUnit">
                    Cost per {unitSystem === "metric" ? "m²" : "ft²"} ({currency === "USD" ? "$" : "₹"})
                  </Label>
                  <Input
                    id="costPerUnit"
                    type="number"
                    placeholder="Enter cost per unit area"
                    value={costPerUnit}
                    onChange={(e) => setCostPerUnit(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Number of Floors */}
                <div className="space-y-2">
                  <Label htmlFor="floors">Number of Floors</Label>
                  <Input
                    id="floors"
                    type="number"
                    placeholder="Enter number of floors"
                    value={floors}
                    onChange={(e) => setFloors(e.target.value)}
                    min="1"
                  />
                </div>

                {/* Optional Costs */}
                <div className="space-y-3 pt-2">
                  <Label className="text-base">Optional Additional Costs</Label>
                  
                  <div className="space-y-2">
                    <Label htmlFor="material" className="text-sm font-normal">
                      Material Cost ({currency === "USD" ? "$" : "₹"})
                    </Label>
                    <Input
                      id="material"
                      type="number"
                      placeholder="Additional material cost"
                      value={materialCost}
                      onChange={(e) => setMaterialCost(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="labor" className="text-sm font-normal">
                      Labor Cost ({currency === "USD" ? "$" : "₹"})
                    </Label>
                    <Input
                      id="labor"
                      type="number"
                      placeholder="Additional labor cost"
                      value={laborCost}
                      onChange={(e) => setLaborCost(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="finishing" className="text-sm font-normal">
                      Finishing/Fittings Cost ({currency === "USD" ? "$" : "₹"})
                    </Label>
                    <Input
                      id="finishing"
                      type="number"
                      placeholder="Finishing and fittings cost"
                      value={finishingCost}
                      onChange={(e) => setFinishingCost(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Contingency */}
                <div className="space-y-2">
                  <Label htmlFor="contingency">Contingency (%)</Label>
                  <Input
                    id="contingency"
                    type="number"
                    placeholder="Enter contingency percentage"
                    value={contingency}
                    onChange={(e) => setContingency(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCost} className="w-full" size="lg">
                  Calculate Cost
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Total Construction Cost</p>
                        <p className="text-4xl font-bold text-amber-600">
                          {currency === "USD" ? "$" : "₹"}
                          {result.totalCost.toFixed(2)}
                        </p>
                      </div>

                      {/* Breakdown */}
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Base Construction</span>
                          <span className="font-medium">
                            {currency === "USD" ? "$" : "₹"}
                            {result.baseCost.toFixed(2)}
                          </span>
                        </div>
                        {result.material > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Materials</span>
                            <span className="font-medium">
                              {currency === "USD" ? "$" : "₹"}
                              {result.material.toFixed(2)}
                            </span>
                          </div>
                        )}
                        {result.labor > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Labor</span>
                            <span className="font-medium">
                              {currency === "USD" ? "$" : "₹"}
                              {result.labor.toFixed(2)}
                            </span>
                          </div>
                        )}
                        {result.finishing > 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Finishing/Fittings</span>
                            <span className="font-medium">
                              {currency === "USD" ? "$" : "₹"}
                              {result.finishing.toFixed(2)}
                            </span>
                          </div>
                        )}
                        <div className="border-t border-amber-200 pt-2 flex justify-between">
                          <span className="text-muted-foreground">Subtotal</span>
                          <span className="font-medium">
                            {currency === "USD" ? "$" : "₹"}
                            {result.subtotal.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Contingency ({contingency}%)</span>
                          <span className="font-medium">
                            {currency === "USD" ? "$" : "₹"}
                            {result.contingencyAmount.toFixed(2)}
                          </span>
                        </div>
                        <div className="border-t border-amber-200 pt-2 flex justify-between font-semibold">
                          <span>Cost per Floor</span>
                          <span className="text-amber-600">
                            {currency === "USD" ? "$" : "₹"}
                            {result.costPerFloor.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Average Construction Costs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Basic Construction</p>
                      <p className="text-muted-foreground">$80-120/ft² or ₹800-1200/ft²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Standard Construction</p>
                      <p className="text-muted-foreground">$120-180/ft² or ₹1200-1800/ft²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Premium Construction</p>
                      <p className="text-muted-foreground">$180-300/ft² or ₹1800-3000/ft²</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted/50">
                      <p className="font-medium">Luxury Construction</p>
                      <p className="text-muted-foreground">$300+/ft² or ₹3000+/ft²</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cost Components</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="flex justify-between">
                    <span>Structure & Shell</span>
                    <span className="font-medium">40-50%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Finishing & Fixtures</span>
                    <span className="font-medium">25-30%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>MEP Systems</span>
                    <span className="font-medium">15-20%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>External Works</span>
                    <span className="font-medium">5-10%</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is House Construction Cost */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is House Construction Cost?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  House construction cost refers to the total expenditure required to build a residential structure from
                  foundation to completion. This comprehensive figure includes all expenses related to materials, labor,
                  equipment, permits, and finishing work. Understanding construction costs is crucial for proper budget
                  planning, securing financing, and ensuring your dream home can be built within your financial means.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The total cost varies significantly based on location, design complexity, material quality, and
                  finishing standards. Urban areas typically have higher costs due to land prices and labor rates, while
                  rural construction may be more economical. Professional estimation considers all cost components
                  including hidden expenses like utilities connection, landscaping, and regulatory fees to provide
                  realistic budget projections.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Construction Cost */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Construction Cost</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The basic method for calculating house construction cost starts with determining the built-up area
                  (total floor area including all floors) and multiplying it by the local construction rate per square
                  foot or square meter. These rates vary by region and construction grade - basic, standard, premium, or
                  luxury. For example, a 2000 sq ft house at $150/sq ft would have a base cost of $300,000.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To this base cost, add specific expenses for materials, specialized labor, high-quality finishes, and
                  fittings. Include costs for electrical systems, plumbing, HVAC, flooring, fixtures, painting, and
                  landscaping. Always add a contingency of 10-15% to cover unforeseen expenses, price escalations, and
                  design modifications. Multi-floor construction requires additional structural support and vertical
                  transportation costs. Professional quantity surveyors can provide detailed item-wise estimates for
                  accuracy.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Construction Costs</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What factors affect construction costs most?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Location, material quality, design complexity, and finishing standards have the biggest impact.
                      Labor costs vary by region and skilled worker availability. Complex architectural designs with
                      curves, multiple levels, or custom features cost more than simple rectangular plans. Premium
                      materials and high-end finishes significantly increase expenses.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">How can I reduce construction costs?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Choose simple, efficient designs with standard dimensions to minimize waste. Use locally available
                      materials to save on transportation. Plan properly to avoid changes during construction. Buy
                      materials in bulk when possible. Consider alternative materials that offer good value. However,
                      don't compromise on structural integrity or essential quality aspects.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Should I build all at once or in phases?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Building in one phase is usually more economical due to bulk material discounts, continuous labor,
                      and avoided setup costs. However, phased construction allows spreading costs over time and
                      flexibility in design changes. Consider your financial situation, time constraints, and whether
                      you need to occupy part of the building while construction continues.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">What is included in the contingency amount?</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      Contingency covers unexpected costs like site conditions, material price increases, design
                      modifications, weather delays, and unforeseen structural requirements. A 10-15% contingency is
                      standard for residential construction. It provides a financial buffer ensuring the project can be
                      completed even if actual costs exceed estimates.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <p className="text-sm text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Construction cost estimates are approximate and for planning purposes
                  only. Actual costs depend on material quality, labor rates, design complexity, site conditions,
                  location, market fluctuations, and contractor pricing. Always obtain detailed quotations from multiple
                  contractors and maintain adequate contingency for unforeseen expenses. Consult with professional
                  architects and quantity surveyors for accurate project-specific estimates.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
