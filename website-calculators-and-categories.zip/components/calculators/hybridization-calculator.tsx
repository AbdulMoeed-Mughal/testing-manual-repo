"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Atom, Info, AlertTriangle, BookOpen } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface HybridizationResult {
  hybridization: string
  stericNumber: number
  bondAngle: string
  geometry: string
  electronGeometry: string
  color: string
  bgColor: string
}

export function HybridizationCalculator() {
  const [sigmaBonds, setSigmaBonds] = useState("")
  const [lonePairs, setLonePairs] = useState("")
  const [result, setResult] = useState<HybridizationResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateHybridization = () => {
    setError("")
    setResult(null)

    const sigmaNum = Number.parseInt(sigmaBonds)
    const loneNum = Number.parseInt(lonePairs)

    if (isNaN(sigmaNum) || sigmaNum < 0) {
      setError("Please enter a valid number of sigma bonds (0 or greater)")
      return
    }

    if (isNaN(loneNum) || loneNum < 0) {
      setError("Please enter a valid number of lone pairs (0 or greater)")
      return
    }

    const stericNumber = sigmaNum + loneNum

    if (stericNumber < 2 || stericNumber > 6) {
      setError("Steric number must be between 2 and 6 for valid hybridization")
      return
    }

    let hybridization: string
    let bondAngle: string
    let electronGeometry: string
    let geometry: string
    let color: string
    let bgColor: string

    // Determine hybridization and electron geometry based on steric number
    switch (stericNumber) {
      case 2:
        hybridization = "sp"
        electronGeometry = "Linear"
        bondAngle = "180°"
        color = "text-blue-600"
        bgColor = "bg-blue-50 border-blue-200"
        break
      case 3:
        hybridization = "sp²"
        electronGeometry = "Trigonal Planar"
        bondAngle = "120°"
        color = "text-green-600"
        bgColor = "bg-green-50 border-green-200"
        break
      case 4:
        hybridization = "sp³"
        electronGeometry = "Tetrahedral"
        bondAngle = "109.5°"
        color = "text-purple-600"
        bgColor = "bg-purple-50 border-purple-200"
        break
      case 5:
        hybridization = "sp³d"
        electronGeometry = "Trigonal Bipyramidal"
        bondAngle = "90° / 120°"
        color = "text-orange-600"
        bgColor = "bg-orange-50 border-orange-200"
        break
      case 6:
        hybridization = "sp³d²"
        electronGeometry = "Octahedral"
        bondAngle = "90°"
        color = "text-red-600"
        bgColor = "bg-red-50 border-red-200"
        break
      default:
        setError("Invalid steric number")
        return
    }

    // Determine molecular geometry based on sigma bonds and lone pairs
    if (stericNumber === 2) {
      geometry = loneNum === 0 ? "Linear" : "Linear"
    } else if (stericNumber === 3) {
      if (loneNum === 0) geometry = "Trigonal Planar"
      else if (loneNum === 1) geometry = "Bent"
      else geometry = "Linear"
    } else if (stericNumber === 4) {
      if (loneNum === 0) geometry = "Tetrahedral"
      else if (loneNum === 1) geometry = "Trigonal Pyramidal"
      else if (loneNum === 2) geometry = "Bent"
      else geometry = "Linear"
    } else if (stericNumber === 5) {
      if (loneNum === 0) geometry = "Trigonal Bipyramidal"
      else if (loneNum === 1) geometry = "Seesaw"
      else if (loneNum === 2) geometry = "T-Shaped"
      else geometry = "Linear"
    } else if (stericNumber === 6) {
      if (loneNum === 0) geometry = "Octahedral"
      else if (loneNum === 1) geometry = "Square Pyramidal"
      else if (loneNum === 2) geometry = "Square Planar"
      else geometry = "T-Shaped"
    } else {
      geometry = "Unknown"
    }

    // Adjust bond angle for lone pairs
    if (loneNum > 0 && stericNumber === 4) {
      if (loneNum === 1) bondAngle = "~107°"
      else if (loneNum === 2) bondAngle = "~104.5°"
    }

    setResult({
      hybridization,
      stericNumber,
      bondAngle,
      geometry,
      electronGeometry,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setSigmaBonds("")
    setLonePairs("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Hybridization: ${result.hybridization}, Steric Number: ${result.stericNumber}, Molecular Geometry: ${result.geometry}, Bond Angle: ${result.bondAngle}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Hybridization Result",
          text: `Hybridization: ${result.hybridization}, Molecular Geometry: ${result.geometry}, Bond Angle: ${result.bondAngle}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <Atom className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Hybridization Calculator</CardTitle>
                    <CardDescription>Predict orbital hybridization from bonding</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Sigma Bonds Input */}
                <div className="space-y-2">
                  <Label htmlFor="sigmaBonds">Number of Sigma Bonds</Label>
                  <Input
                    id="sigmaBonds"
                    type="number"
                    placeholder="Enter number of sigma bonds"
                    value={sigmaBonds}
                    onChange={(e) => setSigmaBonds(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Lone Pairs Input */}
                <div className="space-y-2">
                  <Label htmlFor="lonePairs">Number of Lone Pairs on Central Atom</Label>
                  <Input
                    id="lonePairs"
                    type="number"
                    placeholder="Enter number of lone pairs"
                    value={lonePairs}
                    onChange={(e) => setLonePairs(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateHybridization} className="w-full" size="lg">
                  Calculate Hybridization
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Hybridization</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.hybridization}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.geometry}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="text-center p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Steric Number</p>
                        <p className="font-semibold">{result.stericNumber}</p>
                      </div>
                      <div className="text-center p-2 bg-white/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">Bond Angle</p>
                        <p className="font-semibold">{result.bondAngle}</p>
                      </div>
                    </div>

                    <div className="text-center p-2 bg-white/50 rounded-lg mt-3">
                      <p className="text-xs text-muted-foreground">Electron Geometry</p>
                      <p className="font-semibold">{result.electronGeometry}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Hybridization Types</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">sp</span>
                      <span className="text-sm text-blue-600">Linear (180°)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">sp²</span>
                      <span className="text-sm text-green-600">Trigonal Planar (120°)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">sp³</span>
                      <span className="text-sm text-purple-600">Tetrahedral (109.5°)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">sp³d</span>
                      <span className="text-sm text-orange-600">Trig. Bipyramidal (90°/120°)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">sp³d²</span>
                      <span className="text-sm text-red-600">Octahedral (90°)</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Steric Number Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Steric Number = Sigma Bonds + Lone Pairs</p>
                  </div>
                  <p>
                    The steric number determines hybridization: <strong>2 = sp</strong>, <strong>3 = sp²</strong>,{" "}
                    <strong>4 = sp³</strong>, <strong>5 = sp³d</strong>, <strong>6 = sp³d²</strong>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Hybridization */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Orbital Hybridization?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Orbital hybridization is a concept in chemistry that describes the mixing of atomic orbitals to form new
                  hybrid orbitals suitable for bonding. When atoms form covalent bonds, their atomic orbitals (s, p, d)
                  can combine to create equivalent hybrid orbitals that have different shapes and energies than the
                  original atomic orbitals.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This hybridization model, developed by Linus Pauling, helps explain molecular geometries and bonding
                  characteristics that cannot be explained by simple atomic orbital theory. The type of hybridization
                  directly determines the geometry of molecules and the angles between bonds, making it essential for
                  understanding molecular structure.
                </p>
              </CardContent>
            </Card>

            {/* How to Determine Hybridization */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  <CardTitle>How to Determine Hybridization</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To determine the hybridization of a central atom, first count the number of sigma bonds (single bonds,
                  or one bond from double/triple bonds) and lone pairs around the central atom. The sum of these gives
                  the steric number, which directly corresponds to the hybridization type.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, in water (H₂O), the oxygen atom has 2 sigma bonds (to hydrogen atoms) and 2 lone pairs,
                  giving a steric number of 4. This means oxygen is sp³ hybridized with a tetrahedral electron geometry,
                  though the molecular geometry is bent due to the lone pairs pushing the bonds closer together.
                </p>
              </CardContent>
            </Card>

            {/* Limitations */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Limitations and Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Hybridization predictions are based on VSEPR theory and steric number calculations. While this model
                  works well for many molecules, it has limitations. Actual hybridization may vary due to resonance
                  structures, molecular orbital delocalization, or complex electronic effects in transition metal
                  compounds.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator provides idealized predictions based on classical hybridization theory. For accurate
                  analysis of complex molecules, especially those involving d-block elements or extensive conjugation,
                  more advanced computational methods or experimental data should be consulted.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
