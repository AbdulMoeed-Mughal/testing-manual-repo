"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

type CircuitMode = "charging" | "discharging"

interface RLResult {
  timeConstant: number
  timeConstantUnit: string
  currentAtTime: number | null
  voltageResistor: number | null
  voltageInductor: number | null
  maxCurrent: number
  milestones: { tau: number; current: number; percentage: number }[]
}

export function RLCircuitCalculator() {
  const [mode, setMode] = useState<CircuitMode>("charging")
  const [resistance, setResistance] = useState("")
  const [resistanceUnit, setResistanceUnit] = useState("Ω")
  const [inductance, setInductance] = useState("")
  const [inductanceUnit, setInductanceUnit] = useState("H")
  const [voltage, setVoltage] = useState("")
  const [initialCurrent, setInitialCurrent] = useState("")
  const [timePoint, setTimePoint] = useState("")
  const [showSteps, setShowSteps] = useState(false)
  const [result, setResult] = useState<RLResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const resistanceMultipliers: Record<string, number> = {
    Ω: 1,
    kΩ: 1000,
    MΩ: 1000000,
  }

  const inductanceMultipliers: Record<string, number> = {
    H: 1,
    mH: 0.001,
    µH: 0.000001,
  }

  const calculateRL = () => {
    setError("")
    setResult(null)

    const R = Number.parseFloat(resistance) * resistanceMultipliers[resistanceUnit]
    const L = Number.parseFloat(inductance) * inductanceMultipliers[inductanceUnit]
    const V = Number.parseFloat(voltage)
    const I0 = Number.parseFloat(initialCurrent) || 0
    const t = Number.parseFloat(timePoint)

    if (isNaN(R) || R <= 0) {
      setError("Please enter a valid resistance greater than 0")
      return
    }

    if (isNaN(L) || L <= 0) {
      setError("Please enter a valid inductance greater than 0")
      return
    }

    if (mode === "charging" && (isNaN(V) || V <= 0)) {
      setError("Please enter a valid source voltage greater than 0")
      return
    }

    if (mode === "discharging" && (isNaN(I0) || I0 <= 0)) {
      setError("Please enter a valid initial current greater than 0 for discharging mode")
      return
    }

    // Time constant: τ = L / R
    const tau = L / R

    // Determine appropriate unit for time constant
    let timeConstantUnit = "s"
    let displayTau = tau
    if (tau < 0.001) {
      displayTau = tau * 1000000
      timeConstantUnit = "µs"
    } else if (tau < 1) {
      displayTau = tau * 1000
      timeConstantUnit = "ms"
    }

    // Max current (steady state for charging)
    const maxCurrent = mode === "charging" ? V / R : I0

    // Calculate milestones (1τ through 5τ)
    const milestones = [1, 2, 3, 4, 5].map((n) => {
      let current: number
      let percentage: number
      if (mode === "charging") {
        current = (V / R) * (1 - Math.exp(-n))
        percentage = (1 - Math.exp(-n)) * 100
      } else {
        current = I0 * Math.exp(-n)
        percentage = Math.exp(-n) * 100
      }
      return { tau: n, current, percentage }
    })

    // Calculate current and voltages at specific time point
    let currentAtTime: number | null = null
    let voltageResistor: number | null = null
    let voltageInductor: number | null = null

    if (!isNaN(t) && t >= 0) {
      if (mode === "charging") {
        currentAtTime = (V / R) * (1 - Math.exp(-t / tau))
        voltageResistor = currentAtTime * R
        voltageInductor = V - voltageResistor
      } else {
        currentAtTime = I0 * Math.exp(-t / tau)
        voltageResistor = currentAtTime * R
        voltageInductor = -voltageResistor // Opposing the change
      }
    }

    setResult({
      timeConstant: displayTau,
      timeConstantUnit,
      currentAtTime,
      voltageResistor,
      voltageInductor,
      maxCurrent,
      milestones,
    })
  }

  const handleReset = () => {
    setResistance("")
    setInductance("")
    setVoltage("")
    setInitialCurrent("")
    setTimePoint("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `RL Circuit: τ = ${result.timeConstant.toFixed(4)} ${result.timeConstantUnit}, Max Current = ${result.maxCurrent.toFixed(6)} A`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "RL Circuit Calculation",
          text: `RL Circuit: τ = ${result.timeConstant.toFixed(4)} ${result.timeConstantUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatNumber = (num: number, decimals = 6) => {
    if (Math.abs(num) < 0.000001) return num.toExponential(3)
    if (Math.abs(num) > 1000000) return num.toExponential(3)
    return num.toFixed(decimals)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">RL Circuit Calculator</CardTitle>
                    <CardDescription>Calculate RL time constant and current behavior</CardDescription>
                  </div>
                </div>

                {/* Mode Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Circuit Mode</span>
                  <button
                    onClick={() => setMode(mode === "charging" ? "discharging" : "charging")}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        mode === "discharging" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "charging" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Charging
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        mode === "discharging" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Discharging
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Resistance Input */}
                <div className="space-y-2">
                  <Label htmlFor="resistance">Resistance (R)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="resistance"
                      type="number"
                      placeholder="Enter resistance"
                      value={resistance}
                      onChange={(e) => setResistance(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={resistanceUnit} onValueChange={setResistanceUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Ω">Ω</SelectItem>
                        <SelectItem value="kΩ">kΩ</SelectItem>
                        <SelectItem value="MΩ">MΩ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Inductance Input */}
                <div className="space-y-2">
                  <Label htmlFor="inductance">Inductance (L)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="inductance"
                      type="number"
                      placeholder="Enter inductance"
                      value={inductance}
                      onChange={(e) => setInductance(e.target.value)}
                      min="0"
                      step="any"
                      className="flex-1"
                    />
                    <Select value={inductanceUnit} onValueChange={setInductanceUnit}>
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="H">H</SelectItem>
                        <SelectItem value="mH">mH</SelectItem>
                        <SelectItem value="µH">µH</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Voltage Input (for charging) */}
                {mode === "charging" && (
                  <div className="space-y-2">
                    <Label htmlFor="voltage">Source Voltage (V)</Label>
                    <Input
                      id="voltage"
                      type="number"
                      placeholder="Enter source voltage in volts"
                      value={voltage}
                      onChange={(e) => setVoltage(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Initial Current Input (for discharging) */}
                {mode === "discharging" && (
                  <div className="space-y-2">
                    <Label htmlFor="initialCurrent">Initial Current (I₀) in Amps</Label>
                    <Input
                      id="initialCurrent"
                      type="number"
                      placeholder="Enter initial current"
                      value={initialCurrent}
                      onChange={(e) => setInitialCurrent(e.target.value)}
                      min="0"
                      step="any"
                    />
                  </div>
                )}

                {/* Time Point Input (optional) */}
                <div className="space-y-2">
                  <Label htmlFor="timePoint">Time Point (optional, seconds)</Label>
                  <Input
                    id="timePoint"
                    type="number"
                    placeholder="Enter time to calculate I(t) and V(t)"
                    value={timePoint}
                    onChange={(e) => setTimePoint(e.target.value)}
                    min="0"
                    step="any"
                  />
                </div>

                {/* Show Steps Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="showSteps">Show step-by-step solution</Label>
                  <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRL} className="w-full" size="lg">
                  Calculate RL Circuit
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Time Constant (τ)</p>
                      <p className="text-4xl font-bold text-yellow-600 mb-1">
                        {result.timeConstant.toFixed(4)} {result.timeConstantUnit}
                      </p>
                      <p className="text-sm text-muted-foreground">τ = L / R</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg border">
                        <p className="text-xs text-muted-foreground">Max/Initial Current</p>
                        <p className="text-lg font-semibold text-foreground">{formatNumber(result.maxCurrent)} A</p>
                      </div>
                      {result.currentAtTime !== null && (
                        <div className="p-3 bg-white rounded-lg border">
                          <p className="text-xs text-muted-foreground">Current at t</p>
                          <p className="text-lg font-semibold text-foreground">
                            {formatNumber(result.currentAtTime)} A
                          </p>
                        </div>
                      )}
                    </div>

                    {result.voltageResistor !== null && result.voltageInductor !== null && (
                      <div className="grid grid-cols-2 gap-3 mb-4">
                        <div className="p-3 bg-white rounded-lg border">
                          <p className="text-xs text-muted-foreground">V across Resistor</p>
                          <p className="text-lg font-semibold text-foreground">
                            {formatNumber(result.voltageResistor, 4)} V
                          </p>
                        </div>
                        <div className="p-3 bg-white rounded-lg border">
                          <p className="text-xs text-muted-foreground">V across Inductor</p>
                          <p className="text-lg font-semibold text-foreground">
                            {formatNumber(result.voltageInductor, 4)} V
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Step-by-step solution */}
                    {showSteps && (
                      <div className="mt-4 p-3 bg-white rounded-lg border text-sm space-y-2">
                        <p className="font-semibold">Step-by-step Solution:</p>
                        <p>
                          1. Time constant: τ = L / R = {inductance} {inductanceUnit} / {resistance} {resistanceUnit}
                        </p>
                        <p>
                          2. τ = {result.timeConstant.toFixed(6)} {result.timeConstantUnit}
                        </p>
                        {mode === "charging" && (
                          <>
                            <p>
                              3. Max current: I_max = V / R = {voltage} V / ({resistance} {resistanceUnit})
                            </p>
                            <p>4. I_max = {formatNumber(result.maxCurrent)} A</p>
                            {result.currentAtTime !== null && (
                              <>
                                <p>5. Current formula: I(t) = (V/R) × (1 − e^(−t/τ))</p>
                                <p>
                                  6. I({timePoint}s) = {formatNumber(result.currentAtTime)} A
                                </p>
                              </>
                            )}
                          </>
                        )}
                        {mode === "discharging" && (
                          <>
                            <p>3. Initial current: I₀ = {initialCurrent} A</p>
                            {result.currentAtTime !== null && (
                              <>
                                <p>4. Current formula: I(t) = I₀ × e^(−t/τ)</p>
                                <p>
                                  5. I({timePoint}s) = {formatNumber(result.currentAtTime)} A
                                </p>
                              </>
                            )}
                          </>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Time Constant Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {result ? (
                      result.milestones.map((m) => (
                        <div
                          key={m.tau}
                          className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200"
                        >
                          <span className="font-medium text-yellow-700">{m.tau}τ</span>
                          <span className="text-sm text-yellow-600">
                            {mode === "charging"
                              ? `${m.percentage.toFixed(1)}% of max`
                              : `${m.percentage.toFixed(1)}% remaining`}
                          </span>
                        </div>
                      ))
                    ) : (
                      <>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                          <span className="font-medium">1τ</span>
                          <span className="text-sm text-muted-foreground">63.2% (charging) / 36.8% (discharging)</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                          <span className="font-medium">3τ</span>
                          <span className="text-sm text-muted-foreground">95.0% (charging) / 5.0% (discharging)</span>
                        </div>
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                          <span className="font-medium">5τ</span>
                          <span className="text-sm text-muted-foreground">99.3% (considered complete)</span>
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Info className="h-5 w-5 text-primary" />
                    <CardTitle>What is an RL Circuit?</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="prose prose-gray max-w-none">
                  <p className="text-muted-foreground leading-relaxed">
                    An RL circuit consists of a resistor (R) and an inductor (L) connected in series with a voltage
                    source. Unlike capacitors that store energy in an electric field, inductors store energy in a
                    magnetic field created by current flowing through them. The time constant τ = L/R determines how
                    quickly the current rises or falls in the circuit.
                  </p>
                  <p className="text-muted-foreground leading-relaxed mt-4">
                    When voltage is applied, the inductor opposes changes in current flow (Lenz's Law), causing the
                    current to increase gradually rather than instantaneously. During discharge, the collapsing magnetic
                    field maintains current flow temporarily, causing an exponential decay. After approximately 5 time
                    constants, the circuit is considered to have reached its steady state.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is an RL Circuit?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An RL circuit consists of a resistor (R) and an inductor (L) connected in series with a voltage
                  source. Unlike capacitors that store energy in an electric field, inductors store energy in a magnetic
                  field created by current flowing through them. The time constant τ = L/R determines how quickly the
                  current rises or falls in the circuit.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  When voltage is applied, the inductor opposes changes in current flow (Lenz's Law), causing the
                  current to increase gradually rather than instantaneously. During discharge, the collapsing magnetic
                  field maintains current flow temporarily, causing an exponential decay. After approximately 5 time
                  constants, the circuit is considered to have reached its steady state.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      RL circuit calculations are estimates based on ideal conditions. Actual behavior may vary due to
                      parasitic elements, tolerance, and temperature effects. Consult circuit datasheets or an
                      electrical engineer for precise analysis.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
