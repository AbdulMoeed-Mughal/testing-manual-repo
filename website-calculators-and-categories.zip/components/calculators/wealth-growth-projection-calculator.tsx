"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Target,
  DollarSign,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { CurrencySelector } from "@/components/ui/currency-selector"
import { formatCurrency, currencySymbols, type Currency } from "@/lib/currency"

interface ProjectionResult {
  futureValue: number
  totalContributions: number
  totalInterest: number
  inflationAdjustedValue: number | null
  yearlyBreakdown: {
    year: number
    startBalance: number
    contributions: number
    interest: number
    endBalance: number
    inflationAdjusted: number | null
  }[]
}

export function WealthGrowthProjectionCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [initialInvestment, setInitialInvestment] = useState("")
  const [monthlyContribution, setMonthlyContribution] = useState("")
  const [annualReturnRate, setAnnualReturnRate] = useState("")
  const [duration, setDuration] = useState("")
  const [compoundingFrequency, setCompoundingFrequency] = useState("12")
  const [inflationRate, setInflationRate] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showBreakdown, setShowBreakdown] = useState(false)
  const [result, setResult] = useState<ProjectionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const P = Number.parseFloat(initialInvestment)
    const PMT = Number.parseFloat(monthlyContribution) || 0
    const r = Number.parseFloat(annualReturnRate) / 100
    const t = Number.parseFloat(duration)
    const n = Number.parseInt(compoundingFrequency)
    const inflation = Number.parseFloat(inflationRate) / 100 || 0

    if (isNaN(P) || P < 0) {
      setError("Please enter a valid initial investment amount")
      return
    }

    if (isNaN(r) || r <= 0) {
      setError("Please enter a valid annual return rate greater than 0")
      return
    }

    if (isNaN(t) || t <= 0) {
      setError("Please enter a valid duration greater than 0")
      return
    }

    const yearlyBreakdown: ProjectionResult["yearlyBreakdown"] = []
    let currentBalance = P
    let totalContributions = P
    const annualContribution = PMT * 12
    const periodicRate = r / n

    for (let year = 1; year <= t; year++) {
      const startBalance = currentBalance
      let yearInterest = 0

      // Compound interest calculation with periodic contributions
      for (let period = 0; period < n; period++) {
        const interest = currentBalance * periodicRate
        yearInterest += interest
        currentBalance += interest
        currentBalance += annualContribution / n
      }

      totalContributions += annualContribution

      const inflationAdjusted = inflation > 0 ? currentBalance / Math.pow(1 + inflation, year) : null

      yearlyBreakdown.push({
        year,
        startBalance,
        contributions: annualContribution,
        interest: yearInterest,
        endBalance: currentBalance,
        inflationAdjusted,
      })
    }

    const futureValue = currentBalance
    const totalInterest = futureValue - totalContributions
    const inflationAdjustedValue = inflation > 0 ? futureValue / Math.pow(1 + inflation, t) : null

    setResult({
      futureValue,
      totalContributions,
      totalInterest,
      inflationAdjustedValue,
      yearlyBreakdown,
    })
  }

  const handleReset = () => {
    setInitialInvestment("")
    setMonthlyContribution("")
    setAnnualReturnRate("")
    setDuration("")
    setCompoundingFrequency("12")
    setInflationRate("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Wealth Growth Projection:\nFuture Value: ${formatCurrency(result.futureValue, currency)}\nTotal Contributions: ${formatCurrency(result.totalContributions, currency)}\nTotal Interest Earned: ${formatCurrency(result.totalInterest, currency)}${result.inflationAdjustedValue ? `\nInflation-Adjusted Value: ${formatCurrency(result.inflationAdjustedValue, currency)}` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Wealth Growth Projection",
          text: `My projected wealth: ${formatCurrency(result.futureValue, currency)} after ${duration} years`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getGrowthMultiplier = () => {
    if (!result) return 0
    return result.futureValue / result.totalContributions
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Wealth Growth Projection</CardTitle>
                    <CardDescription>Estimate future value of your investments</CardDescription>
                  </div>
                </div>
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Initial Investment */}
                <div className="space-y-2">
                  <Label htmlFor="initialInvestment">Initial Investment ({currencySymbols[currency]})</Label>
                  <Input
                    id="initialInvestment"
                    type="number"
                    placeholder="e.g., 10000"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Monthly Contribution */}
                <div className="space-y-2">
                  <Label htmlFor="monthlyContribution">Monthly Contribution ({currencySymbols[currency]})</Label>
                  <Input
                    id="monthlyContribution"
                    type="number"
                    placeholder="e.g., 500"
                    value={monthlyContribution}
                    onChange={(e) => setMonthlyContribution(e.target.value)}
                    min="0"
                    step="50"
                  />
                </div>

                {/* Annual Return Rate */}
                <div className="space-y-2">
                  <Label htmlFor="annualReturnRate">Expected Annual Return Rate (%)</Label>
                  <Input
                    id="annualReturnRate"
                    type="number"
                    placeholder="e.g., 8"
                    value={annualReturnRate}
                    onChange={(e) => setAnnualReturnRate(e.target.value)}
                    min="0"
                    max="50"
                    step="0.1"
                  />
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Investment Duration (Years)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="e.g., 20"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    min="1"
                    max="100"
                    step="1"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="compoundingFrequency">Compounding Frequency</Label>
                      <Select value={compoundingFrequency} onValueChange={setCompoundingFrequency}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">Annually</SelectItem>
                          <SelectItem value="4">Quarterly</SelectItem>
                          <SelectItem value="12">Monthly</SelectItem>
                          <SelectItem value="365">Daily</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="inflationRate">Expected Inflation Rate (%)</Label>
                      <Input
                        id="inflationRate"
                        type="number"
                        placeholder="e.g., 3"
                        value={inflationRate}
                        onChange={(e) => setInflationRate(e.target.value)}
                        min="0"
                        max="20"
                        step="0.1"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Projection
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Projected Wealth</p>
                      <p className="text-4xl font-bold text-green-600 mb-1">
                        {formatCurrency(result.futureValue, currency)}
                      </p>
                      <p className="text-sm text-green-600">{getGrowthMultiplier().toFixed(2)}x growth multiplier</p>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Contributions</p>
                        <p className="font-semibold text-sm">{formatCurrency(result.totalContributions, currency)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Interest Earned</p>
                        <p className="font-semibold text-sm text-green-600">
                          {formatCurrency(result.totalInterest, currency)}
                        </p>
                      </div>
                    </div>

                    {result.inflationAdjustedValue && (
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg mb-4">
                        <p className="text-xs text-amber-700 mb-1">Inflation-Adjusted Value</p>
                        <p className="font-semibold text-amber-800">
                          {formatCurrency(result.inflationAdjustedValue, currency)}
                        </p>
                        <p className="text-xs text-amber-600 mt-1">
                          Purchasing power in today's {currencySymbols[currency]}
                        </p>
                      </div>
                    )}

                    {/* Year-by-Year Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full mb-2 bg-transparent">
                          {showBreakdown ? "Hide" : "Show"} Year-by-Year Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="max-h-60 overflow-y-auto rounded-lg border bg-white">
                          <table className="w-full text-xs">
                            <thead className="sticky top-0 bg-muted">
                              <tr>
                                <th className="p-2 text-left">Year</th>
                                <th className="p-2 text-right">Contributions</th>
                                <th className="p-2 text-right">Interest</th>
                                <th className="p-2 text-right">Balance</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.yearlyBreakdown.map((row) => (
                                <tr key={row.year} className="border-t">
                                  <td className="p-2">{row.year}</td>
                                  <td className="p-2 text-right">{formatCurrency(row.contributions, currency)}</td>
                                  <td className="p-2 text-right text-green-600">
                                    {formatCurrency(row.interest, currency)}
                                  </td>
                                  <td className="p-2 text-right font-medium">
                                    {formatCurrency(row.endBalance, currency)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Growth Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Conservative</span>
                      <span className="text-sm text-green-600">5-6% annual return</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Moderate</span>
                      <span className="text-sm text-blue-600">7-9% annual return</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Aggressive</span>
                      <span className="text-sm text-purple-600">10-12% annual return</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Compound Interest Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">
                      FV = P(1 + r/n)^(nt) + PMT × [((1 + r/n)^(nt) - 1) / (r/n)]
                    </p>
                  </div>
                  <div className="space-y-1 text-xs">
                    <p>
                      <strong>FV</strong> = Future Value
                    </p>
                    <p>
                      <strong>P</strong> = Initial Principal
                    </p>
                    <p>
                      <strong>r</strong> = Annual Interest Rate
                    </p>
                    <p>
                      <strong>n</strong> = Compounding Frequency
                    </p>
                    <p>
                      <strong>t</strong> = Time in Years
                    </p>
                    <p>
                      <strong>PMT</strong> = Regular Contribution
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rule of 72</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <p className="mb-3">Quick way to estimate how long it takes to double your money:</p>
                  <div className="p-3 bg-muted rounded-lg font-mono text-center mb-3">
                    <p className="font-semibold text-foreground">Years to Double = 72 ÷ Interest Rate</p>
                  </div>
                  <p className="text-xs">At 8% return, your money doubles in approximately 9 years.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Wealth Growth Projection?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Wealth growth projection is a financial planning tool that estimates the future value of your
                  investments based on your current assets, regular contributions, expected returns, and time horizon.
                  It uses the power of compound interest to show how your wealth can grow exponentially over time,
                  helping you set realistic financial goals and plan for major life events like retirement, education
                  funding, or major purchases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key to building wealth is understanding that time is your greatest ally. The earlier you start
                  investing and the more consistently you contribute, the more dramatic the effects of compounding
                  become. Even small, regular contributions can grow into substantial wealth over decades.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">1. Enter Your Starting Point</h4>
                    <p className="text-blue-700 text-sm">
                      Input your initial investment amount. This could be your current savings, an inheritance, or any
                      lump sum you're starting with.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">2. Set Regular Contributions</h4>
                    <p className="text-green-700 text-sm">
                      Enter how much you plan to invest each month. Consistent contributions are often more impactful
                      than the initial amount due to dollar-cost averaging.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">3. Choose Return Rate & Duration</h4>
                    <p className="text-purple-700 text-sm">
                      Select a realistic expected return rate based on your investment strategy and the number of years
                      you plan to invest. Historical stock market returns average 7-10% annually.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Maximizing Wealth Growth</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Start Early</h4>
                    <p className="text-sm text-muted-foreground">
                      Time is the most powerful factor in compound growth. Starting 10 years earlier can double your
                      final wealth even with smaller contributions.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Stay Consistent</h4>
                    <p className="text-sm text-muted-foreground">
                      Regular contributions through market ups and downs (dollar-cost averaging) reduces risk and builds
                      discipline.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Minimize Fees</h4>
                    <p className="text-sm text-muted-foreground">
                      High investment fees can significantly erode returns over time. Look for low-cost index funds and
                      ETFs.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Consider Inflation</h4>
                    <p className="text-sm text-muted-foreground">
                      Use the inflation adjustment option to see your wealth's real purchasing power in future dollars.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-800 text-sm leading-relaxed">
                  Wealth growth projections are estimates based on entered values and assumed rates of return. Actual
                  results may vary due to market conditions, inflation, fees, taxes, and other factors. Past performance
                  does not guarantee future results. This calculator is for educational and planning purposes only.
                  Consult a qualified financial advisor for personalized investment guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
