"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  Home,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Percent,
  Calculator,
  Building,
  TrendingUp,
  Scale,
  Activity,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface RentVsBuyResult {
  totalBuyCost: number
  totalRentCost: number
  netBenefit: number
  recommendation: "buy" | "rent" | "neutral"
  monthlyMortgage: number
  monthlyOwnershipCost: number
  finalHomeValue: number
  totalMortgageInterest: number
  totalPropertyTax: number
  totalMaintenance: number
  totalRentPaid: number
  opportunityCostGain: number
  homeEquityBuilt: number
  breakEvenYear: number | null
  yearByYear: YearComparison[]
}

interface YearComparison {
  year: number
  cumulativeBuyCost: number
  cumulativeRentCost: number
  homeValue: number
  equityBuilt: number
  netBuyPosition: number
}

export function RentVsBuyCalculator() {
  const [homePrice, setHomePrice] = useState("")
  const [downPayment, setDownPayment] = useState("")
  const [downPaymentType, setDownPaymentType] = useState<"amount" | "percent">("percent")
  const [interestRate, setInterestRate] = useState("")
  const [loanTerm, setLoanTerm] = useState("30")
  const [monthlyRent, setMonthlyRent] = useState("")
  const [timeHorizon, setTimeHorizon] = useState("10")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [propertyTaxRate, setPropertyTaxRate] = useState("1.2")
  const [insuranceRate, setInsuranceRate] = useState("0.5")
  const [maintenanceRate, setMaintenanceRate] = useState("1")
  const [appreciationRate, setAppreciationRate] = useState("3")
  const [rentIncreaseRate, setRentIncreaseRate] = useState("3")
  const [investmentReturnRate, setInvestmentReturnRate] = useState("7")
  const [result, setResult] = useState<RentVsBuyResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)
  const [showYearByYear, setShowYearByYear] = useState(false)

  const calculateRentVsBuy = () => {
    setError("")
    setResult(null)

    const price = Number.parseFloat(homePrice)
    const dp = Number.parseFloat(downPayment)
    const rate = Number.parseFloat(interestRate)
    const term = Number.parseInt(loanTerm)
    const rent = Number.parseFloat(monthlyRent)
    const years = Number.parseInt(timeHorizon)
    const propTax = Number.parseFloat(propertyTaxRate) / 100
    const insurance = Number.parseFloat(insuranceRate) / 100
    const maintenance = Number.parseFloat(maintenanceRate) / 100
    const appreciation = Number.parseFloat(appreciationRate) / 100
    const rentIncrease = Number.parseFloat(rentIncreaseRate) / 100
    const investReturn = Number.parseFloat(investmentReturnRate) / 100

    // Validation
    if (!homePrice || price <= 0) {
      setError("Please enter a valid home price")
      return
    }
    if (!downPayment || dp < 0) {
      setError("Please enter a valid down payment")
      return
    }
    if (!interestRate || rate <= 0 || rate > 30) {
      setError("Please enter a valid interest rate (0-30%)")
      return
    }
    if (!monthlyRent || rent <= 0) {
      setError("Please enter a valid monthly rent")
      return
    }

    // Calculate down payment amount
    let downPaymentAmount: number
    if (downPaymentType === "percent") {
      if (dp > 100) {
        setError("Down payment percentage cannot exceed 100%")
        return
      }
      downPaymentAmount = price * (dp / 100)
    } else {
      if (dp > price) {
        setError("Down payment cannot exceed home price")
        return
      }
      downPaymentAmount = dp
    }

    // Calculate loan amount and monthly mortgage payment
    const loanAmount = price - downPaymentAmount
    const monthlyRate = rate / 100 / 12
    const numPayments = term * 12

    let monthlyMortgage = 0
    if (loanAmount > 0 && monthlyRate > 0) {
      monthlyMortgage =
        (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, numPayments))) /
        (Math.pow(1 + monthlyRate, numPayments) - 1)
    }

    // Calculate year-by-year comparison
    const yearByYear: YearComparison[] = []
    let cumulativeBuyCost = downPaymentAmount // Start with down payment
    let cumulativeRentCost = 0
    let currentRent = rent
    let currentHomeValue = price
    let remainingLoan = loanAmount
    let totalInterestPaid = 0
    let totalPropertyTaxPaid = 0
    let totalMaintenancePaid = 0
    let breakEvenYear: number | null = null

    for (let year = 1; year <= years; year++) {
      // Buying costs for this year
      const yearMortgage = monthlyMortgage * 12
      const yearPropertyTax = currentHomeValue * propTax
      const yearInsurance = currentHomeValue * insurance
      const yearMaintenance = currentHomeValue * maintenance

      // Calculate interest vs principal for this year
      let yearInterest = 0
      let yearPrincipal = 0
      for (let month = 0; month < 12; month++) {
        if (remainingLoan > 0) {
          const monthInterest = remainingLoan * monthlyRate
          const monthPrincipal = Math.min(monthlyMortgage - monthInterest, remainingLoan)
          yearInterest += monthInterest
          yearPrincipal += monthPrincipal
          remainingLoan -= monthPrincipal
        }
      }
      totalInterestPaid += yearInterest
      totalPropertyTaxPaid += yearPropertyTax
      totalMaintenancePaid += yearMaintenance

      cumulativeBuyCost += yearMortgage + yearPropertyTax + yearInsurance + yearMaintenance

      // Renting costs for this year
      const yearRent = currentRent * 12
      cumulativeRentCost += yearRent
      currentRent *= 1 + rentIncrease

      // Home appreciation
      currentHomeValue *= 1 + appreciation

      // Calculate equity built
      const equityBuilt = currentHomeValue - remainingLoan

      // Net buy position = equity - cumulative costs + down payment opportunity cost
      const downPaymentOpportunityCost = downPaymentAmount * Math.pow(1 + investReturn, year) - downPaymentAmount
      const netBuyPosition = equityBuilt - cumulativeBuyCost + downPaymentAmount

      yearByYear.push({
        year,
        cumulativeBuyCost,
        cumulativeRentCost,
        homeValue: currentHomeValue,
        equityBuilt,
        netBuyPosition,
      })

      // Check for break-even
      if (breakEvenYear === null && netBuyPosition > 0) {
        breakEvenYear = year
      }
    }

    // Calculate opportunity cost of down payment invested
    const opportunityCostGain = downPaymentAmount * Math.pow(1 + investReturn, years) - downPaymentAmount

    // Final calculations
    const totalBuyCost = cumulativeBuyCost
    const totalRentCost = cumulativeRentCost + opportunityCostGain
    const finalEquity = currentHomeValue - remainingLoan
    const netBenefit = finalEquity - totalBuyCost + downPaymentAmount - (totalRentCost - opportunityCostGain)

    // Determine recommendation
    let recommendation: "buy" | "rent" | "neutral"
    if (netBenefit > price * 0.05) {
      recommendation = "buy"
    } else if (netBenefit < -price * 0.05) {
      recommendation = "rent"
    } else {
      recommendation = "neutral"
    }

    setResult({
      totalBuyCost,
      totalRentCost,
      netBenefit,
      recommendation,
      monthlyMortgage,
      monthlyOwnershipCost:
        monthlyMortgage + (price * propTax) / 12 + (price * insurance) / 12 + (price * maintenance) / 12,
      finalHomeValue: currentHomeValue,
      totalMortgageInterest: totalInterestPaid,
      totalPropertyTax: totalPropertyTaxPaid,
      totalMaintenance: totalMaintenancePaid,
      totalRentPaid: cumulativeRentCost,
      opportunityCostGain,
      homeEquityBuilt: finalEquity,
      breakEvenYear,
      yearByYear,
    })
  }

  const handleReset = () => {
    setHomePrice("")
    setDownPayment("")
    setDownPaymentType("percent")
    setInterestRate("")
    setLoanTerm("30")
    setMonthlyRent("")
    setTimeHorizon("10")
    setShowAdvanced(false)
    setPropertyTaxRate("1.2")
    setInsuranceRate("0.5")
    setMaintenanceRate("1")
    setAppreciationRate("3")
    setRentIncreaseRate("3")
    setInvestmentReturnRate("7")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
    setShowYearByYear(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Rent vs Buy Analysis (${timeHorizon} years):\n\nBuying:\n- Total Cost: ${formatCurrency(result.totalBuyCost)}\n- Home Equity: ${formatCurrency(result.homeEquityBuilt)}\n- Final Home Value: ${formatCurrency(result.finalHomeValue)}\n\nRenting:\n- Total Cost: ${formatCurrency(result.totalRentCost)}\n\nNet Benefit of Buying: ${formatCurrency(result.netBenefit)}\nRecommendation: ${result.recommendation.toUpperCase()}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Rent vs Buy Analysis",
          text: `Over ${timeHorizon} years: ${result.recommendation === "buy" ? "Buying" : result.recommendation === "rent" ? "Renting" : "Either option"} is better with a ${formatCurrency(Math.abs(result.netBenefit))} ${result.netBenefit >= 0 ? "advantage" : "disadvantage"}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  const getRecommendationColor = (rec: string) => {
    if (rec === "buy") return "bg-green-50 border-green-200 text-green-700"
    if (rec === "rent") return "bg-blue-50 border-blue-200 text-blue-700"
    return "bg-yellow-50 border-yellow-200 text-yellow-700"
  }

  const getRecommendationLabel = (rec: string) => {
    if (rec === "buy") return "Buying is Better"
    if (rec === "rent") return "Renting is Better"
    return "Both Options Similar"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Scale className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Rent vs Buy Calculator</CardTitle>
                    <CardDescription>Compare renting vs buying a home</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Buying Section */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                    <Home className="h-4 w-4" />
                    Buying Details
                  </div>

                  {/* Home Price */}
                  <div className="space-y-2">
                    <Label htmlFor="homePrice">Home Price ($)</Label>
                    <Input
                      id="homePrice"
                      type="number"
                      placeholder="e.g., 400000"
                      value={homePrice}
                      onChange={(e) => setHomePrice(e.target.value)}
                      min="0"
                      step="1000"
                    />
                  </div>

                  {/* Down Payment */}
                  <div className="space-y-2">
                    <Label>Down Payment</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder={downPaymentType === "percent" ? "20" : "80000"}
                        value={downPayment}
                        onChange={(e) => setDownPayment(e.target.value)}
                        min="0"
                        className="flex-1"
                      />
                      <div className="flex border rounded-lg overflow-hidden">
                        <Button
                          type="button"
                          variant={downPaymentType === "percent" ? "default" : "ghost"}
                          size="sm"
                          className="rounded-none px-3"
                          onClick={() => setDownPaymentType("percent")}
                        >
                          <Percent className="h-4 w-4" />
                        </Button>
                        <Button
                          type="button"
                          variant={downPaymentType === "amount" ? "default" : "ghost"}
                          size="sm"
                          className="rounded-none px-3"
                          onClick={() => setDownPaymentType("amount")}
                        >
                          <DollarSign className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Interest Rate */}
                  <div className="space-y-2">
                    <Label htmlFor="interestRate">Interest Rate (%)</Label>
                    <Input
                      id="interestRate"
                      type="number"
                      placeholder="e.g., 6.5"
                      value={interestRate}
                      onChange={(e) => setInterestRate(e.target.value)}
                      min="0"
                      max="30"
                      step="0.1"
                    />
                  </div>

                  {/* Loan Term */}
                  <div className="space-y-2">
                    <Label>Loan Term</Label>
                    <Select value={loanTerm} onValueChange={setLoanTerm}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select term" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 years</SelectItem>
                        <SelectItem value="20">20 years</SelectItem>
                        <SelectItem value="30">30 years</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Renting Section */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                    <Building className="h-4 w-4" />
                    Renting Details
                  </div>

                  {/* Monthly Rent */}
                  <div className="space-y-2">
                    <Label htmlFor="monthlyRent">Monthly Rent ($)</Label>
                    <Input
                      id="monthlyRent"
                      type="number"
                      placeholder="e.g., 2000"
                      value={monthlyRent}
                      onChange={(e) => setMonthlyRent(e.target.value)}
                      min="0"
                      step="50"
                    />
                  </div>
                </div>

                {/* Time Horizon */}
                <div className="space-y-2">
                  <Label>Time Horizon (Years)</Label>
                  <Select value={timeHorizon} onValueChange={setTimeHorizon}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select years" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 years</SelectItem>
                      <SelectItem value="5">5 years</SelectItem>
                      <SelectItem value="7">7 years</SelectItem>
                      <SelectItem value="10">10 years</SelectItem>
                      <SelectItem value="15">15 years</SelectItem>
                      <SelectItem value="20">20 years</SelectItem>
                      <SelectItem value="30">30 years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Advanced Options */}
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="w-full justify-between"
                  >
                    <span>Advanced Options</span>
                    {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>

                  {showAdvanced && (
                    <div className="space-y-3 p-3 border rounded-lg bg-muted/30">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor="propertyTaxRate">Property Tax (%/yr)</Label>
                          <Input
                            id="propertyTaxRate"
                            type="number"
                            placeholder="1.2"
                            value={propertyTaxRate}
                            onChange={(e) => setPropertyTaxRate(e.target.value)}
                            min="0"
                            max="10"
                            step="0.1"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="insuranceRate">Insurance (%/yr)</Label>
                          <Input
                            id="insuranceRate"
                            type="number"
                            placeholder="0.5"
                            value={insuranceRate}
                            onChange={(e) => setInsuranceRate(e.target.value)}
                            min="0"
                            max="5"
                            step="0.1"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="maintenanceRate">Maintenance (%/yr)</Label>
                          <Input
                            id="maintenanceRate"
                            type="number"
                            placeholder="1"
                            value={maintenanceRate}
                            onChange={(e) => setMaintenanceRate(e.target.value)}
                            min="0"
                            max="5"
                            step="0.1"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="appreciationRate">Home Appreciation (%/yr)</Label>
                          <Input
                            id="appreciationRate"
                            type="number"
                            placeholder="3"
                            value={appreciationRate}
                            onChange={(e) => setAppreciationRate(e.target.value)}
                            min="-10"
                            max="20"
                            step="0.5"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="rentIncreaseRate">Rent Increase (%/yr)</Label>
                          <Input
                            id="rentIncreaseRate"
                            type="number"
                            placeholder="3"
                            value={rentIncreaseRate}
                            onChange={(e) => setRentIncreaseRate(e.target.value)}
                            min="0"
                            max="20"
                            step="0.5"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="investmentReturnRate">Investment Return (%/yr)</Label>
                          <Input
                            id="investmentReturnRate"
                            type="number"
                            placeholder="7"
                            value={investmentReturnRate}
                            onChange={(e) => setInvestmentReturnRate(e.target.value)}
                            min="0"
                            max="30"
                            step="0.5"
                          />
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Investment return is for opportunity cost of down payment if renting
                      </p>
                    </div>
                  )}
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRentVsBuy} className="w-full" size="lg">
                  Compare Rent vs Buy
                </Button>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleReset} className="flex-1 bg-transparent">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset
                  </Button>
                  <Button variant="outline" onClick={handleCopy} disabled={!result} className="flex-1 bg-transparent">
                    {copied ? <Check className="mr-2 h-4 w-4" /> : <Copy className="mr-2 h-4 w-4" />}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                  <Button variant="outline" onClick={handleShare} disabled={!result} className="flex-1 bg-transparent">
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                </div>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${getRecommendationColor(result.recommendation)}`}
                  >
                    <div className="text-center mb-4">
                      <div className="flex items-center justify-center gap-2 mb-1">
                        <Scale className="h-5 w-5" />
                        <span className="text-sm font-medium">{getRecommendationLabel(result.recommendation)}</span>
                      </div>
                      <div className="text-3xl font-bold">
                        {result.netBenefit >= 0 ? "+" : "-"}
                        {formatCurrency(Math.abs(result.netBenefit))}
                      </div>
                      <div className="text-sm opacity-80">
                        Net {result.netBenefit >= 0 ? "advantage" : "disadvantage"} of buying over {timeHorizon} years
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{formatCurrency(result.totalBuyCost)}</div>
                        <div className="text-xs opacity-70">Total Buy Cost</div>
                      </div>
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{formatCurrency(result.totalRentPaid)}</div>
                        <div className="text-xs opacity-70">Total Rent Paid</div>
                      </div>
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{formatCurrency(result.homeEquityBuilt)}</div>
                        <div className="text-xs opacity-70">Home Equity Built</div>
                      </div>
                      <div className="bg-white/50 rounded-lg p-2 text-center">
                        <div className="font-semibold">{formatCurrency(result.finalHomeValue)}</div>
                        <div className="text-xs opacity-70">Final Home Value</div>
                      </div>
                    </div>

                    {/* Expandable Details */}
                    <div className="mt-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowDetails(!showDetails)}
                        className="w-full justify-between hover:bg-white/30"
                      >
                        <span className="text-sm">View Details</span>
                        {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>

                      {showDetails && (
                        <div className="mt-2 space-y-2 text-sm">
                          <div className="font-medium mb-2">Monthly Costs:</div>
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Mortgage Payment</span>
                            <span className="font-medium">{formatCurrency(result.monthlyMortgage)}/mo</span>
                          </div>
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Total Ownership Cost</span>
                            <span className="font-medium">{formatCurrency(result.monthlyOwnershipCost)}/mo</span>
                          </div>
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Monthly Rent (initial)</span>
                            <span className="font-medium">{formatCurrency(Number.parseFloat(monthlyRent))}/mo</span>
                          </div>

                          <div className="font-medium mt-3 mb-2">Total Costs Over {timeHorizon} Years:</div>
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Mortgage Interest</span>
                            <span className="font-medium">{formatCurrency(result.totalMortgageInterest)}</span>
                          </div>
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Property Taxes</span>
                            <span className="font-medium">{formatCurrency(result.totalPropertyTax)}</span>
                          </div>
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Maintenance</span>
                            <span className="font-medium">{formatCurrency(result.totalMaintenance)}</span>
                          </div>
                          <div className="flex justify-between p-2 bg-white/30 rounded">
                            <span>Opportunity Cost (down payment)</span>
                            <span className="font-medium">{formatCurrency(result.opportunityCostGain)}</span>
                          </div>
                          {result.breakEvenYear && (
                            <div className="flex justify-between p-2 bg-white/30 rounded">
                              <span>Break-Even Year</span>
                              <span className="font-medium">Year {result.breakEvenYear}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Year by Year Comparison */}
                {result && result.yearByYear.length > 0 && (
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowYearByYear(!showYearByYear)}
                      className="w-full justify-between"
                    >
                      <span>Year-by-Year Comparison</span>
                      {showYearByYear ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>

                    {showYearByYear && (
                      <div className="border rounded-lg overflow-hidden max-h-64 overflow-y-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-muted/50 sticky top-0">
                            <tr>
                              <th className="p-2 text-left">Year</th>
                              <th className="p-2 text-right">Buy Cost</th>
                              <th className="p-2 text-right">Rent Cost</th>
                              <th className="p-2 text-right">Home Equity</th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.yearByYear.map((year) => (
                              <tr key={year.year} className="border-t">
                                <td className="p-2 font-medium">{year.year}</td>
                                <td className="p-2 text-right">{formatCurrency(year.cumulativeBuyCost)}</td>
                                <td className="p-2 text-right">{formatCurrency(year.cumulativeRentCost)}</td>
                                <td className="p-2 text-right">{formatCurrency(year.equityBuilt)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-4">
              {/* Key Factors */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-green-600" />
                    Key Comparison Factors
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-xs font-medium">
                      1
                    </div>
                    <div>
                      <div className="font-medium">Home Appreciation</div>
                      <div className="text-muted-foreground">Potential increase in home value over time</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-xs font-medium">
                      2
                    </div>
                    <div>
                      <div className="font-medium">Equity Building</div>
                      <div className="text-muted-foreground">Ownership stake grows with each payment</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-medium">
                      3
                    </div>
                    <div>
                      <div className="font-medium">Opportunity Cost</div>
                      <div className="text-muted-foreground">What your down payment could earn if invested</div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="h-5 w-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-medium">
                      4
                    </div>
                    <div>
                      <div className="font-medium">Time Horizon</div>
                      <div className="text-muted-foreground">Longer stays favor buying due to fixed costs</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Homeownership Costs */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Home className="h-4 w-4 text-green-600" />
                    Typical Homeownership Costs
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Property Tax</span>
                      <span className="font-medium">0.5% - 2.5% / year</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Home Insurance</span>
                      <span className="font-medium">0.3% - 1% / year</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Maintenance</span>
                      <span className="font-medium">1% - 2% / year</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">PMI (if applicable)</span>
                      <span className="font-medium">0.5% - 1% / year</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Break-Even Info */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Calculator className="h-4 w-4 text-green-600" />
                    Break-Even Point
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm">
                  <p className="text-muted-foreground mb-2">
                    The break-even point is when buying becomes financially advantageous over renting, typically:
                  </p>
                  <ul className="space-y-1 text-muted-foreground">
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-green-500" />
                      3-5 years in appreciating markets
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-yellow-500" />
                      5-7 years in stable markets
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-red-500" />
                      7+ years in expensive markets
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Info className="h-4 w-4 text-primary" />
                  When to Buy
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ul className="space-y-1">
                  <li>• Planning to stay 5+ years in the same area</li>
                  <li>• Have stable income and job security</li>
                  <li>• Can afford 20% down to avoid PMI</li>
                  <li>• Local market has good appreciation potential</li>
                  <li>• Rent is high relative to mortgage costs</li>
                  <li>• Ready for homeownership responsibilities</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="h-4 w-4 text-primary" />
                  When to Rent
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ul className="space-y-1">
                  <li>• May relocate within 3-5 years</li>
                  <li>• Job or income uncertainty</li>
                  <li>• Saving for a larger down payment</li>
                  <li>• Housing market is overvalued</li>
                  <li>• Want flexibility and mobility</li>
                  <li>• Investment returns exceed home appreciation</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Home className="h-4 w-4 text-primary" />
                  Hidden Costs of Homeownership
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ul className="space-y-1">
                  <li>• Closing costs (2-5% of purchase price)</li>
                  <li>• Moving expenses</li>
                  <li>• HOA fees (if applicable)</li>
                  <li>• Major repairs (roof, HVAC, plumbing)</li>
                  <li>• Lawn care and landscaping</li>
                  <li>• Higher utility costs than apartments</li>
                  <li>• Selling costs (5-6% agent commissions)</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm bg-yellow-50/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  Important Disclaimer
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>
                  Rent vs buy calculations are estimates and may vary based on market conditions, local costs, and
                  individual circumstances. This calculator does not account for tax benefits, closing costs when
                  selling, or all potential expenses. Consult a financial advisor for personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
