"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Square, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type ElementType = "Slab" | "Beam" | "Column"

interface CoverBlockResult {
  numberOfBlocks: number
  blockSize: string
  spacing: number
  unit: string
}

export function CoverBlockCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [coverRequired, setCoverRequired] = useState("")
  const [barDiameter, setBarDiameter] = useState("")
  const [barSpacing, setBarSpacing] = useState("")
  const [elementLength, setElementLength] = useState("")
  const [elementType, setElementType] = useState<ElementType>("Slab")
  const [result, setResult] = useState<CoverBlockResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateCoverBlocks = () => {
    setError("")
    setResult(null)

    const cover = Number.parseFloat(coverRequired)
    const diameter = Number.parseFloat(barDiameter)
    const spacing = Number.parseFloat(barSpacing)
    const length = Number.parseFloat(elementLength)

    if (isNaN(cover) || cover <= 0) {
      setError("Please enter a valid concrete cover greater than 0")
      return
    }

    if (isNaN(diameter) || diameter <= 0) {
      setError("Please enter a valid bar diameter greater than 0")
      return
    }

    if (isNaN(spacing) || spacing <= 0) {
      setError("Please enter a valid bar spacing greater than 0")
      return
    }

    if (isNaN(length) || length <= 0) {
      setError("Please enter a valid element length greater than 0")
      return
    }

    // Convert to mm if imperial
    const coverMm = unitSystem === "imperial" ? cover * 25.4 : cover
    const diameterMm = unitSystem === "imperial" ? diameter * 25.4 : diameter
    const spacingMm = unitSystem === "imperial" ? spacing * 25.4 : spacing
    const lengthMm = unitSystem === "imperial" ? length * 304.8 : length * 1000 // ft to mm or m to mm

    // Calculate number of cover blocks
    // Formula: Number = (Length / Spacing) + 1
    const numberOfBlocks = Math.ceil(lengthMm / spacingMm) + 1

    // Determine recommended block size based on cover and bar diameter
    let blockSizeMm: number
    if (coverMm <= 20) {
      blockSizeMm = 20
    } else if (coverMm <= 25) {
      blockSizeMm = 25
    } else if (coverMm <= 30) {
      blockSizeMm = 30
    } else if (coverMm <= 40) {
      blockSizeMm = 40
    } else if (coverMm <= 50) {
      blockSizeMm = 50
    } else {
      blockSizeMm = Math.ceil(coverMm / 10) * 10
    }

    // Convert results based on unit system
    let blockSizeDisplay: string
    let spacingDisplay: number
    let unit: string

    if (unitSystem === "metric") {
      blockSizeDisplay = `${blockSizeMm}mm`
      spacingDisplay = Math.round(spacingMm)
      unit = "mm"
    } else {
      const blockSizeInches = Math.round((blockSizeMm / 25.4) * 10) / 10
      blockSizeDisplay = `${blockSizeInches}"`
      spacingDisplay = Math.round((spacingMm / 25.4) * 10) / 10
      unit = "in"
    }

    setResult({
      numberOfBlocks,
      blockSize: blockSizeDisplay,
      spacing: spacingDisplay,
      unit,
    })
  }

  const handleReset = () => {
    setCoverRequired("")
    setBarDiameter("")
    setBarSpacing("")
    setElementLength("")
    setElementType("Slab")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Cover Blocks Required: ${result.numberOfBlocks} blocks | Size: ${result.blockSize} | Spacing: ${result.spacing} ${result.unit}`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Cover Block Calculation",
          text: `${result.numberOfBlocks} cover blocks required (${result.blockSize}) for ${elementType}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setCoverRequired("")
    setBarDiameter("")
    setBarSpacing("")
    setElementLength("")
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Square className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Cover Block Calculator</CardTitle>
                    <CardDescription>Calculate cover block quantity and spacing</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Element Type */}
                <div className="space-y-2">
                  <Label htmlFor="elementType">Element Type</Label>
                  <Select value={elementType} onValueChange={(value) => setElementType(value as ElementType)}>
                    <SelectTrigger id="elementType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Slab">Slab</SelectItem>
                      <SelectItem value="Beam">Beam</SelectItem>
                      <SelectItem value="Column">Column</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Cover Required */}
                <div className="space-y-2">
                  <Label htmlFor="coverRequired">Concrete Cover Required ({unitSystem === "metric" ? "mm" : "in"})</Label>
                  <Input
                    id="coverRequired"
                    type="number"
                    placeholder={`Enter required cover in ${unitSystem === "metric" ? "millimeters" : "inches"}`}
                    value={coverRequired}
                    onChange={(e) => setCoverRequired(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Bar Diameter */}
                <div className="space-y-2">
                  <Label htmlFor="barDiameter">Bar Diameter ({unitSystem === "metric" ? "mm" : "in"})</Label>
                  <Input
                    id="barDiameter"
                    type="number"
                    placeholder={`Enter bar diameter in ${unitSystem === "metric" ? "millimeters" : "inches"}`}
                    value={barDiameter}
                    onChange={(e) => setBarDiameter(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Bar Spacing */}
                <div className="space-y-2">
                  <Label htmlFor="barSpacing">Bar Spacing ({unitSystem === "metric" ? "mm" : "in"})</Label>
                  <Input
                    id="barSpacing"
                    type="number"
                    placeholder={`Enter spacing between bars in ${unitSystem === "metric" ? "millimeters" : "inches"}`}
                    value={barSpacing}
                    onChange={(e) => setBarSpacing(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Element Length */}
                <div className="space-y-2">
                  <Label htmlFor="elementLength">Element Length ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="elementLength"
                    type="number"
                    placeholder={`Enter length in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={elementLength}
                    onChange={(e) => setElementLength(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCoverBlocks} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate Cover Blocks
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Cover Blocks Required</p>
                        <p className="text-4xl font-bold text-amber-600">{result.numberOfBlocks}</p>
                        <p className="text-sm text-amber-700 mt-1">blocks</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Recommended Block Size:</span>
                          <span className="font-semibold">{result.blockSize}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Placement Spacing:</span>
                          <span className="font-semibold">
                            {result.spacing} {result.unit}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Element Type:</span>
                          <span className="font-semibold">{elementType}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Cover Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="font-medium">Slabs (Mild)</span>
                      <span className="text-muted-foreground">15-20mm</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="font-medium">Beams (Mild)</span>
                      <span className="text-muted-foreground">25-30mm</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="font-medium">Columns (Mild)</span>
                      <span className="text-muted-foreground">40-50mm</span>
                    </div>
                    <div className="flex justify-between p-2 rounded bg-muted">
                      <span className="font-medium">Footings</span>
                      <span className="text-muted-foreground">50-75mm</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cover Block Materials</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground mb-1">Concrete Blocks</p>
                    <p>Most common, durable, same material as structure</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground mb-1">Plastic Blocks</p>
                    <p>Lightweight, rust-proof, consistent dimensions</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-medium text-foreground mb-1">Mortar/Brick Pieces</p>
                    <p>Traditional method, less reliable for uniform cover</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What are Cover Blocks */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What are Cover Blocks?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Cover blocks, also known as spacers or chairs, are small structural elements placed between
                  reinforcement bars and formwork to maintain the specified concrete cover. They ensure that
                  reinforcement is properly positioned at the designed distance from the concrete surface, protecting
                  steel from environmental exposure and ensuring adequate fire resistance and structural integrity.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Proper concrete cover is essential for protecting reinforcement from corrosion, providing fire
                  resistance, and ensuring proper bond between steel and concrete. Cover blocks help achieve consistent
                  cover throughout the structure, preventing issues like spalling, rust staining, and reduced structural
                  capacity. They are critical quality control elements in reinforced concrete construction.
                </p>
              </CardContent>
            </Card>

            {/* Placement Guidelines */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Placement Guidelines</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Cover blocks should be placed at regular intervals along reinforcement bars, typically at spacings of
                  500-1000mm (20-40 inches) depending on the structural element and bar size. For slabs, blocks are
                  placed in a grid pattern to support the reinforcement mesh. In beams and columns, they should be
                  positioned to maintain cover on all exposed faces.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The spacing between cover blocks should be close enough to prevent reinforcement from sagging or
                  moving during concrete placement. For horizontal slabs, closer spacing may be needed if workers will
                  walk on the reinforcement. Ensure blocks are securely tied or attached to the reinforcement to
                  prevent displacement during concreting. Always verify that the block thickness matches or slightly
                  exceeds the specified cover requirement.
                </p>
              </CardContent>
            </Card>

            {/* Best Practices */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Square className="h-5 w-5 text-primary" />
                  <CardTitle>Best Practices and Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Use cover blocks of the same concrete grade as the structural element or higher to prevent weak points
                  in the structure. Plastic cover blocks offer advantages in corrosive environments as they don't rust
                  or cause staining. Ensure blocks are clean and properly positioned before concrete placement - they
                  should not be moved or adjusted once concreting begins.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For critical structures or harsh exposure conditions, increase the number of cover blocks beyond
                  minimum requirements to ensure reinforcement stays in position. Document the type, size, and spacing
                  of cover blocks used for quality assurance records. In areas with multiple layers of reinforcement,
                  use different sized blocks for each layer to maintain proper spacing between steel layers as well as
                  from formwork surfaces.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Disclaimer</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Cover block calculations are approximate and should be verified with project specifications and
                      structural drawings. Actual placement must comply with design codes (IS 456, ACI 318, etc.) and
                      site-specific requirements. Cover requirements may vary based on exposure conditions, structural
                      importance, and local building regulations. Always consult with the project structural engineer
                      for final approval of cover block specifications and placement details.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
