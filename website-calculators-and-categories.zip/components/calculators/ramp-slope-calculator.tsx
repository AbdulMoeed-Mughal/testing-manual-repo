"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, TrendingUp, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type SlopeType = "ratio" | "percentage"

interface RampResult {
  length: number
  slopePercentage: number
  slopeAngle: number
  compliant: boolean
  color: string
  bgColor: string
}

export function RampSlopeCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [rise, setRise] = useState("")
  const [slopeType, setSlopeType] = useState<SlopeType>("ratio")
  const [slopeRatio, setSlopeRatio] = useState("12")
  const [slopePercentage, setSlopePercentage] = useState("")
  const [rampWidth, setRampWidth] = useState("")
  const [result, setResult] = useState<RampResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateRamp = () => {
    setError("")
    setResult(null)

    const riseNum = Number.parseFloat(rise)
    if (isNaN(riseNum) || riseNum <= 0) {
      setError("Please enter a valid rise greater than 0")
      return
    }

    let length: number
    let percentage: number

    if (slopeType === "ratio") {
      const ratioNum = Number.parseFloat(slopeRatio)
      if (isNaN(ratioNum) || ratioNum <= 0) {
        setError("Please enter a valid slope ratio")
        return
      }
      length = riseNum * ratioNum
      percentage = (1 / ratioNum) * 100
    } else {
      const percentNum = Number.parseFloat(slopePercentage)
      if (isNaN(percentNum) || percentNum <= 0 || percentNum > 100) {
        setError("Please enter a valid slope percentage (0-100)")
        return
      }
      percentage = percentNum
      length = riseNum / (percentNum / 100)
    }

    const angleRadians = Math.atan(riseNum / length)
    const angleDegrees = (angleRadians * 180) / Math.PI

    // Check accessibility compliance (1:12 = 8.33% is standard for wheelchair access)
    const compliant = percentage <= 8.33
    const color = compliant ? "text-green-600" : "text-amber-600"
    const bgColor = compliant ? "bg-green-50 border-green-200" : "bg-amber-50 border-amber-200"

    setResult({
      length: Math.round(length * 100) / 100,
      slopePercentage: Math.round(percentage * 100) / 100,
      slopeAngle: Math.round(angleDegrees * 100) / 100,
      compliant,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setRise("")
    setSlopeRatio("12")
    setSlopePercentage("")
    setRampWidth("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "m" : "ft"
      await navigator.clipboard.writeText(
        `Ramp Length: ${result.length} ${unit}, Slope: ${result.slopePercentage}%, Angle: ${result.slopeAngle}°`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const unit = unitSystem === "metric" ? "m" : "ft"
        await navigator.share({
          title: "Ramp Slope Calculation",
          text: `Ramp Length: ${result.length} ${unit}, Slope: ${result.slopePercentage}%, Angle: ${result.slopeAngle}°`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
  }

  const setPresetSlope = (ratio: string) => {
    setSlopeRatio(ratio)
    setSlopeType("ratio")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Ramp Slope Calculator</CardTitle>
                    <CardDescription>Calculate ramp dimensions and slope</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Rise Input */}
                <div className="space-y-2">
                  <Label htmlFor="rise">Vertical Rise ({unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="rise"
                    type="number"
                    placeholder="Enter rise height"
                    value={rise}
                    onChange={(e) => setRise(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Slope Type Selection */}
                <div className="space-y-2">
                  <Label>Slope Type</Label>
                  <Select value={slopeType} onValueChange={(value: SlopeType) => setSlopeType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ratio">Ratio (1:X)</SelectItem>
                      <SelectItem value="percentage">Percentage (%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Slope Input */}
                {slopeType === "ratio" ? (
                  <div className="space-y-2">
                    <Label htmlFor="slopeRatio">Slope Ratio (1:X)</Label>
                    <Input
                      id="slopeRatio"
                      type="number"
                      placeholder="Enter ratio denominator (e.g., 12 for 1:12)"
                      value={slopeRatio}
                      onChange={(e) => setSlopeRatio(e.target.value)}
                      min="1"
                      step="1"
                    />
                    <div className="flex gap-2 flex-wrap">
                      <Button type="button" variant="outline" size="sm" onClick={() => setPresetSlope("12")}>
                        1:12
                      </Button>
                      <Button type="button" variant="outline" size="sm" onClick={() => setPresetSlope("20")}>
                        1:20
                      </Button>
                      <Button type="button" variant="outline" size="sm" onClick={() => setPresetSlope("10")}>
                        1:10
                      </Button>
                      <Button type="button" variant="outline" size="sm" onClick={() => setPresetSlope("8")}>
                        1:8
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="slopePercentage">Slope Percentage (%)</Label>
                    <Input
                      id="slopePercentage"
                      type="number"
                      placeholder="Enter slope percentage"
                      value={slopePercentage}
                      onChange={(e) => setSlopePercentage(e.target.value)}
                      min="0"
                      max="100"
                      step="0.1"
                    />
                  </div>
                )}

                {/* Ramp Width (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="rampWidth">Ramp Width (Optional, {unitSystem === "metric" ? "m" : "ft"})</Label>
                  <Input
                    id="rampWidth"
                    type="number"
                    placeholder="Enter ramp width"
                    value={rampWidth}
                    onChange={(e) => setRampWidth(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRamp} className="w-full" size="lg">
                  Calculate Ramp
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-current/10">
                        <p className="text-sm text-muted-foreground mb-1">Ramp Length</p>
                        <p className={`text-4xl font-bold ${result.color}`}>
                          {result.length} {unitSystem === "metric" ? "m" : "ft"}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-muted-foreground">Slope</p>
                          <p className={`font-semibold ${result.color}`}>{result.slopePercentage}%</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Angle</p>
                          <p className={`font-semibold ${result.color}`}>{result.slopeAngle}°</p>
                        </div>
                      </div>

                      <div className={`p-2 rounded-lg text-center text-sm font-medium ${result.color}`}>
                        {result.compliant ? "✓ Meets Wheelchair Accessibility" : "⚠ Exceeds Standard Wheelchair Slope"}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Standard Ramp Slopes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-green-700">Wheelchair Access</span>
                        <span className="text-sm text-green-600">1:12</span>
                      </div>
                      <p className="text-xs text-green-600">8.33% slope - ADA compliant</p>
                    </div>
                    <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-blue-700">Gentle Slope</span>
                        <span className="text-sm text-blue-600">1:20</span>
                      </div>
                      <p className="text-xs text-blue-600">5% slope - Maximum comfort</p>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-amber-700">Vehicle Ramp</span>
                        <span className="text-sm text-amber-600">1:10</span>
                      </div>
                      <p className="text-xs text-amber-600">10% slope - For vehicles</p>
                    </div>
                    <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-red-700">Steep Ramp</span>
                        <span className="text-sm text-red-600">1:8</span>
                      </div>
                      <p className="text-xs text-red-600">12.5% slope - Temporary use only</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">For Ratio (1:X):</p>
                    <p className="font-mono">Length = Rise × X</p>
                    <p className="font-mono">Slope % = (1/X) × 100</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg space-y-2">
                    <p className="font-semibold text-foreground">Angle Calculation:</p>
                    <p className="font-mono">Angle = arctan(Rise/Length) × 180/π</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Ramp Slope */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Ramp Slope?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Ramp slope is the ratio of vertical rise to horizontal run, expressing how steep or gradual a ramp
                  surface is. It's a critical factor in ramp design that affects usability, safety, and accessibility. The
                  slope is typically expressed as a ratio (like 1:12, meaning 1 unit of rise for every 12 units of run) or
                  as a percentage. Understanding ramp slope is essential for designing ramps that comply with accessibility
                  standards, provide safe access for wheelchairs and mobility devices, and accommodate vehicle traffic where
                  needed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The Americans with Disabilities Act (ADA) and similar international standards specify maximum ramp slopes
                  to ensure accessibility for people with disabilities. The standard 1:12 slope (8.33%) is the maximum
                  allowed for wheelchair access in most situations, though gentler slopes are always preferable when space
                  permits. Steeper ramps require more physical effort to navigate and may not be suitable for all users,
                  while very gentle slopes provide easier access but require more horizontal space.
                </p>
              </CardContent>
            </Card>

            {/* How to Calculate Ramp Slope */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Calculate Ramp Slope?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating ramp slope begins with measuring the vertical rise - the height difference between the lower
                  and upper levels the ramp will connect. Once you know the rise and your desired slope ratio, you can
                  calculate the required ramp length. For example, with a 1:12 slope and a 24-inch rise, you would need a
                  ramp length of 24 × 12 = 288 inches (24 feet). The calculation ensures the ramp meets accessibility
                  requirements while fitting within available space constraints.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  To convert between different slope expressions, use these relationships: a 1:12 ratio equals 8.33%, while
                  a 1:20 ratio equals 5%. The slope angle in degrees can be found using the arctangent (inverse tangent)
                  function: angle = arctan(rise/run). For instance, a 1:12 slope has an angle of approximately 4.76
                  degrees. Understanding these conversions helps you work with different building codes and specifications
                  that may express slope requirements in different formats.
                </p>
              </CardContent>
            </Card>

            {/* Accessibility Standards */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Ramp Accessibility Standards</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The ADA Standards for Accessible Design specify that ramps must have a maximum slope of 1:12 (8.33%) for
                  new construction and alterations. This means for every inch of vertical rise, there must be at least 12
                  inches of ramp run. Ramps with slopes between 1:12 and 1:16 are considered ideal, providing easier access
                  for wheelchair users and people with mobility challenges. When space allows, designing ramps with gentler
                  slopes (1:20 or less) significantly improves usability and reduces physical strain.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Beyond slope requirements, accessibility standards also specify other critical ramp features: minimum
                  width of 36 inches (42 inches preferred), level landings at the top and bottom, handrails on both sides
                  for ramps longer than 6 feet, edge protection to prevent wheels from slipping off, and maximum rise of 30
                  inches between landings. These comprehensive requirements work together to create ramps that are safe,
                  functional, and truly accessible to all users, regardless of their mobility level or the assistive devices
                  they use.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm text-amber-900">
                    <p className="font-semibold">Important Notice:</p>
                    <p className="leading-relaxed">
                      Ramp slope calculations provided by this calculator are approximate and intended for initial planning
                      purposes only. Actual ramp design must comply with local building codes, accessibility regulations
                      (such as ADA in the United States), and be reviewed by qualified professionals. Factors such as
                      surface texture, weather conditions, landing requirements, handrail specifications, and edge
                      protection must also be considered in final ramp designs.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
