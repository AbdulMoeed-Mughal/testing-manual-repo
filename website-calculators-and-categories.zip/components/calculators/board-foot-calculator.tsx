"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Ruler,
  Info,
  AlertTriangle,
  Calculator,
  TreePine,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface BoardFootResult {
  boardFeetPerPiece: number
  totalBoardFeet: number
  numberOfBoards: number
}

export function BoardFootCalculator() {
  const [thickness, setThickness] = useState("")
  const [width, setWidth] = useState("")
  const [length, setLength] = useState("")
  const [numberOfBoards, setNumberOfBoards] = useState("1")
  const [result, setResult] = useState<BoardFootResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateBoardFeet = () => {
    setError("")
    setResult(null)

    const thicknessNum = Number.parseFloat(thickness)
    const widthNum = Number.parseFloat(width)
    const lengthNum = Number.parseFloat(length)
    const boardsNum = Number.parseInt(numberOfBoards) || 1

    if (isNaN(thicknessNum) || thicknessNum <= 0) {
      setError("Please enter a valid thickness greater than 0")
      return
    }
    if (isNaN(widthNum) || widthNum <= 0) {
      setError("Please enter a valid width greater than 0")
      return
    }
    if (isNaN(lengthNum) || lengthNum <= 0) {
      setError("Please enter a valid length greater than 0")
      return
    }
    if (boardsNum < 1) {
      setError("Number of boards must be at least 1")
      return
    }

    // Board Feet = (Thickness × Width × Length) ÷ 12
    const boardFeetPerPiece = (thicknessNum * widthNum * lengthNum) / 12
    const totalBoardFeet = boardFeetPerPiece * boardsNum

    setResult({
      boardFeetPerPiece: Math.round(boardFeetPerPiece * 1000) / 1000,
      totalBoardFeet: Math.round(totalBoardFeet * 1000) / 1000,
      numberOfBoards: boardsNum,
    })
  }

  const handleReset = () => {
    setThickness("")
    setWidth("")
    setLength("")
    setNumberOfBoards("1")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Board Foot Calculation:\n- Board Feet per Piece: ${result.boardFeetPerPiece} BF\n- Number of Boards: ${result.numberOfBoards}\n- Total Board Feet: ${result.totalBoardFeet} BF`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Board Foot Calculation",
          text: `I calculated my lumber needs using CalcHub! Total: ${result.totalBoardFeet} board feet for ${result.numberOfBoards} boards.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  // Common lumber sizes for quick selection
  const commonSizes = [
    { name: "1×4", thickness: "1", width: "4" },
    { name: "1×6", thickness: "1", width: "6" },
    { name: "1×8", thickness: "1", width: "8" },
    { name: "1×12", thickness: "1", width: "12" },
    { name: "2×4", thickness: "2", width: "4" },
    { name: "2×6", thickness: "2", width: "6" },
    { name: "2×8", thickness: "2", width: "8" },
    { name: "2×10", thickness: "2", width: "10" },
    { name: "2×12", thickness: "2", width: "12" },
    { name: "4×4", thickness: "4", width: "4" },
  ]

  const applyCommonSize = (t: string, w: string) => {
    setThickness(t)
    setWidth(w)
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <TreePine className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Board Foot Calculator</CardTitle>
                    <CardDescription>Calculate lumber board feet</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Common Sizes Quick Select */}
                <div className="space-y-2">
                  <Label className="text-sm text-muted-foreground">Quick Select (Nominal Size)</Label>
                  <div className="flex flex-wrap gap-2">
                    {commonSizes.map((size) => (
                      <Button
                        key={size.name}
                        variant="outline"
                        size="sm"
                        onClick={() => applyCommonSize(size.thickness, size.width)}
                        className={`text-xs ${
                          thickness === size.thickness && width === size.width
                            ? "bg-amber-50 border-amber-300 text-amber-700"
                            : ""
                        }`}
                      >
                        {size.name}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Thickness Input */}
                <div className="space-y-2">
                  <Label htmlFor="thickness">Thickness (inches)</Label>
                  <Input
                    id="thickness"
                    type="number"
                    placeholder="Enter thickness in inches"
                    value={thickness}
                    onChange={(e) => setThickness(e.target.value)}
                    min="0"
                    step="0.25"
                  />
                </div>

                {/* Width Input */}
                <div className="space-y-2">
                  <Label htmlFor="width">Width (inches)</Label>
                  <Input
                    id="width"
                    type="number"
                    placeholder="Enter width in inches"
                    value={width}
                    onChange={(e) => setWidth(e.target.value)}
                    min="0"
                    step="0.25"
                  />
                </div>

                {/* Length Input */}
                <div className="space-y-2">
                  <Label htmlFor="length">Length (feet)</Label>
                  <Input
                    id="length"
                    type="number"
                    placeholder="Enter length in feet"
                    value={length}
                    onChange={(e) => setLength(e.target.value)}
                    min="0"
                    step="0.5"
                  />
                </div>

                {/* Number of Boards */}
                <div className="space-y-2">
                  <Label htmlFor="numberOfBoards">Number of Boards (optional)</Label>
                  <Input
                    id="numberOfBoards"
                    type="number"
                    placeholder="Enter number of boards"
                    value={numberOfBoards}
                    onChange={(e) => setNumberOfBoards(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBoardFeet} className="w-full" size="lg">
                  Calculate Board Feet
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Board Feet per Piece</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">{result.boardFeetPerPiece}</p>
                      <p className="text-sm text-amber-700">BF</p>
                    </div>

                    {result.numberOfBoards > 1 && (
                      <div className="mt-4 pt-4 border-t border-amber-200 text-center">
                        <p className="text-sm text-muted-foreground mb-1">Total for {result.numberOfBoards} boards</p>
                        <p className="text-3xl font-bold text-amber-700">{result.totalBoardFeet} BF</p>
                      </div>
                    )}

                    {/* Calculation Steps */}
                    <div className="mt-4">
                      <button
                        onClick={() => setShowSteps(!showSteps)}
                        className="text-sm text-amber-600 hover:text-amber-800 font-medium flex items-center gap-1 mx-auto"
                      >
                        <Calculator className="h-4 w-4" />
                        {showSteps ? "Hide" : "Show"} Calculation
                      </button>

                      {showSteps && (
                        <div className="mt-3 p-3 bg-white/60 rounded-lg text-sm space-y-2">
                          <p className="font-medium text-foreground">Step-by-Step:</p>
                          <div className="space-y-1 text-muted-foreground">
                            <p>1. Formula: BF = (T × W × L) ÷ 12</p>
                            <p>
                              2. BF = ({thickness}" × {width}" × {length}') ÷ 12
                            </p>
                            <p>3. BF = {(Number(thickness) * Number(width) * Number(length)).toFixed(2)} ÷ 12</p>
                            <p>4. BF = {result.boardFeetPerPiece} board feet per piece</p>
                            {result.numberOfBoards > 1 && (
                              <>
                                <p className="pt-2 border-t border-amber-100">
                                  5. Total = {result.boardFeetPerPiece} × {result.numberOfBoards} boards
                                </p>
                                <p>6. Total = {result.totalBoardFeet} board feet</p>
                              </>
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Board Foot Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">BF = (T × W × L) ÷ 12</p>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>
                      <strong>T</strong> = Thickness in inches
                    </p>
                    <p>
                      <strong>W</strong> = Width in inches
                    </p>
                    <p>
                      <strong>L</strong> = Length in feet
                    </p>
                    <p>
                      <strong>BF</strong> = Board Feet
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Board Feet Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1×6×8'</span>
                      <span className="font-medium">4 BF</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>1×12×8'</span>
                      <span className="font-medium">8 BF</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>2×4×8'</span>
                      <span className="font-medium">5.33 BF</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>2×6×8'</span>
                      <span className="font-medium">8 BF</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>2×10×8'</span>
                      <span className="font-medium">13.33 BF</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>4×4×8'</span>
                      <span className="font-medium">10.67 BF</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Important Note</p>
                      <p>
                        Results are estimates based on nominal lumber dimensions. Actual lumber sizes may vary due to
                        milling, finishing, and drying. Always verify with your lumber supplier.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Board Foot?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A board foot (BF) is the standard unit of measurement for lumber volume in the United States and
                  Canada. One board foot is equivalent to a piece of wood that is 1 inch thick, 12 inches wide, and 12
                  inches long, or 144 cubic inches of wood. This measurement system has been used by the lumber industry
                  for over a century and remains the primary way hardwood lumber is bought and sold.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding board feet is essential for woodworkers, carpenters, and contractors because lumber
                  pricing is typically quoted per board foot. Whether you're building furniture, framing a house, or
                  working on any woodworking project, knowing how to calculate board feet helps you accurately estimate
                  material costs and order the right amount of lumber.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Nominal vs. Actual Dimensions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When working with lumber, it's important to understand the difference between nominal and actual
                  dimensions. Nominal dimensions are the names used to describe lumber sizes (like 2×4 or 1×6), while
                  actual dimensions are the true measurements after milling and drying. For example, a nominal 2×4
                  actually measures 1.5" × 3.5".
                </p>
                <div className="mt-4 overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 pr-4 font-semibold">Nominal Size</th>
                        <th className="text-left py-2 font-semibold">Actual Size</th>
                      </tr>
                    </thead>
                    <tbody className="text-muted-foreground">
                      <tr className="border-b">
                        <td className="py-2 pr-4">1×4</td>
                        <td className="py-2">3/4" × 3-1/2"</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4">1×6</td>
                        <td className="py-2">3/4" × 5-1/2"</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4">2×4</td>
                        <td className="py-2">1-1/2" × 3-1/2"</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4">2×6</td>
                        <td className="py-2">1-1/2" × 5-1/2"</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4">2×10</td>
                        <td className="py-2">1-1/2" × 9-1/4"</td>
                      </tr>
                      <tr>
                        <td className="py-2 pr-4">4×4</td>
                        <td className="py-2">3-1/2" × 3-1/2"</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For board foot calculations at lumberyards, nominal dimensions are typically used. However, for
                  hardwood lumber sold rough (unfinished), actual measurements are used. Always confirm with your
                  supplier which measurement convention they use.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TreePine className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The board foot measurement is used extensively in various woodworking and construction scenarios:
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Furniture Making</h4>
                    <p className="text-sm text-muted-foreground">
                      Calculate material needs for tables, chairs, cabinets, and other furniture projects. Helps
                      estimate costs when using premium hardwoods.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Deck Building</h4>
                    <p className="text-sm text-muted-foreground">
                      Determine lumber quantities for deck boards, joists, and railings. Essential for accurate project
                      budgeting.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Home Framing</h4>
                    <p className="text-sm text-muted-foreground">
                      Estimate framing lumber for walls, floors, and roofs. Helps contractors price jobs accurately.
                    </p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Custom Millwork</h4>
                    <p className="text-sm text-muted-foreground">
                      Calculate wood needed for trim, molding, and architectural details. Important for custom home
                      builds.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Add for Waste</h4>
                    <p className="text-sm text-blue-700">
                      Always add 10-20% extra to your board foot calculations to account for defects, cutting waste, and
                      mistakes. For complex projects with many cuts, consider adding even more.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Verify Measurements</h4>
                    <p className="text-sm text-green-700">
                      Double-check all measurements before placing orders. Remember that lumber is often sold in even
                      lengths (6', 8', 10', 12'), so factor this into your planning.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Consider Wood Species</h4>
                    <p className="text-sm text-amber-700">
                      Different wood species have different prices per board foot. Hardwoods like oak, walnut, and maple
                      are significantly more expensive than softwoods like pine or spruce.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
