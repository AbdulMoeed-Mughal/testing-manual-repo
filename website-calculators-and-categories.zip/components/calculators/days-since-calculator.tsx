"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Calendar, Info, TrendingUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface DaysResult {
  days: number
  weeks: number
  months: number
  years: number
}

export function DaysSinceCalculator() {
  const [pastDate, setPastDate] = useState("")
  const [includeCurrentDay, setIncludeCurrentDay] = useState(false)
  const [result, setResult] = useState<DaysResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateDaysSince = () => {
    setError("")
    setResult(null)

    if (!pastDate) {
      setError("Please enter a past date")
      return
    }

    const past = new Date(pastDate)
    const current = new Date()
    current.setHours(0, 0, 0, 0)

    if (past > current) {
      setError("Date cannot be in the future")
      return
    }

    if (isNaN(past.getTime())) {
      setError("Please enter a valid date")
      return
    }

    const timeDiff = current.getTime() - past.getTime()
    let days = Math.floor(timeDiff / (1000 * 60 * 60 * 24))

    if (includeCurrentDay) {
      days++
    }

    const weeks = Math.floor(days / 7)
    const months = Math.floor(days / 30.44) // Average month length
    const years = Math.floor(days / 365.25) // Account for leap years

    setResult({ days, weeks, months, years })
  }

  const handleReset = () => {
    setPastDate("")
    setIncludeCurrentDay(false)
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `${result.days} days since (${result.weeks} weeks, ${result.months} months, ${result.years} years)`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Days Since Calculation",
          text: `It's been ${result.days} days since ${pastDate}! Calculated using CalcHub.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getMilestone = (days: number): string | null => {
    if (days === 100) return "100 Days!"
    if (days === 365) return "1 Year!"
    if (days === 500) return "500 Days!"
    if (days === 1000) return "1000 Days!"
    if (days === 2000) return "2000 Days!"
    if (days === 5000) return "5000 Days!"
    if (days === 10000) return "10,000 Days!"
    return null
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Calendar className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Days Since Calculator</CardTitle>
                    <CardDescription>Track days since past events</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Past Date Input */}
                <div className="space-y-2">
                  <Label htmlFor="pastDate">Past Date</Label>
                  <Input
                    id="pastDate"
                    type="date"
                    value={pastDate}
                    onChange={(e) => setPastDate(e.target.value)}
                    max={new Date().toISOString().split("T")[0]}
                  />
                </div>

                {/* Include Current Day Checkbox */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="includeCurrentDay"
                    checked={includeCurrentDay}
                    onCheckedChange={(checked) => setIncludeCurrentDay(checked as boolean)}
                  />
                  <label
                    htmlFor="includeCurrentDay"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Include current day in count
                  </label>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateDaysSince} className="w-full" size="lg">
                  Calculate Days Since
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center space-y-3">
                      <div className="pb-3 border-b border-cyan-200">
                        <p className="text-sm text-muted-foreground mb-1">Days Since</p>
                        <p className="text-5xl font-bold text-cyan-600">{result.days.toLocaleString()}</p>
                        <p className="text-sm text-cyan-700 mt-1">days</p>
                      </div>

                      {getMilestone(result.days) && (
                        <div className="p-3 bg-gradient-to-r from-cyan-100 to-cyan-50 rounded-lg border border-cyan-300">
                          <p className="text-cyan-800 font-semibold">🎉 {getMilestone(result.days)}</p>
                        </div>
                      )}

                      <div className="grid grid-cols-3 gap-3 text-center">
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-xl font-bold text-cyan-600">{result.weeks}</p>
                          <p className="text-xs text-muted-foreground">Weeks</p>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-xl font-bold text-cyan-600">{result.months}</p>
                          <p className="text-xs text-muted-foreground">Months</p>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <p className="text-xl font-bold text-cyan-600">{result.years}</p>
                          <p className="text-xs text-muted-foreground">Years</p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Time Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center justify-between p-2 rounded bg-cyan-50">
                      <span className="font-medium text-cyan-700">100 days</span>
                      <span className="text-cyan-600">First milestone</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-cyan-50">
                      <span className="font-medium text-cyan-700">365 days</span>
                      <span className="text-cyan-600">One year</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-cyan-50">
                      <span className="font-medium text-cyan-700">1000 days</span>
                      <span className="text-cyan-600">Major milestone</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-cyan-50">
                      <span className="font-medium text-cyan-700">10,000 days</span>
                      <span className="text-cyan-600">Epic milestone</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Notes</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>Days are counted from midnight to midnight in your local timezone.</p>
                  <p>Weeks are calculated as complete 7-day periods.</p>
                  <p>Months use an average of 30.44 days for approximation.</p>
                  <p>Years account for leap years with an average of 365.25 days.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Days Since */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Days Since?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Days since calculations help you track the passage of time from important past events. Whether you're
                  marking sobriety milestones, relationship anniversaries, project start dates, or personal achievements,
                  knowing exactly how many days have passed provides a tangible measure of progress and time elapsed.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This simple yet powerful metric has applications in habit tracking, recovery programs, business
                  analytics, and personal goal management. Seeing the accumulation of days can be motivating and help
                  maintain awareness of long-term commitments and achievements.
                </p>
              </CardContent>
            </Card>

            {/* Common Uses */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>Common Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Sobriety and Recovery</h4>
                    <p className="text-cyan-700 text-sm">
                      Track days of sobriety or recovery. Each day represents progress and commitment to personal health
                      goals. Milestone days (100, 365, 1000) become meaningful celebrations of achievement.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Relationships and Anniversaries</h4>
                    <p className="text-cyan-700 text-sm">
                      Calculate days since first meeting, wedding, or other relationship milestones. Some couples
                      celebrate unique anniversaries like 500 or 1000 days together alongside traditional yearly
                      celebrations.
                    </p>
                  </div>
                  <div className="p-4 bg-cyan-50 border border-cyan-200 rounded-lg">
                    <h4 className="font-semibold text-cyan-800 mb-2">Business and Projects</h4>
                    <p className="text-cyan-700 text-sm">
                      Track days since product launch, company founding, or project start. This metric helps measure
                      time-to-market, project duration, and business milestones for reporting and planning purposes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <div className="p-4 bg-muted rounded-lg border border-border text-sm text-muted-foreground">
              <p className="font-medium text-foreground mb-2">Note:</p>
              <p>
                Days since calculation is based on the entered date and current date. Results may vary due to time zones
                and calendar differences. The calculator counts complete days from midnight to midnight.
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
