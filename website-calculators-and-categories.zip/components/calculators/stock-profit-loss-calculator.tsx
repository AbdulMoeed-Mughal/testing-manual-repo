"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  TrendingDown,
  Info,
  AlertTriangle,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, currencySymbols, formatCurrency } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

interface StockResult {
  totalPurchaseCost: number
  totalSellingProceeds: number
  profitLoss: number
  profitLossPercentage: number
  totalWithDividends: number
  profitLossWithDividends: number
  profitLossPercentageWithDividends: number
  isProfit: boolean
  buyingFees: number
  sellingFees: number
  dividends: number
}

export function StockProfitLossCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [purchasePrice, setPurchasePrice] = useState("")
  const [sharesCount, setSharesCount] = useState("")
  const [sellingPrice, setSellingPrice] = useState("")
  const [buyingFees, setBuyingFees] = useState("")
  const [sellingFees, setSellingFees] = useState("")
  const [dividends, setDividends] = useState("")
  const [result, setResult] = useState<StockResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)

  const calculateProfitLoss = () => {
    setError("")
    setResult(null)

    const purchasePriceNum = Number.parseFloat(purchasePrice)
    const sharesNum = Number.parseFloat(sharesCount)
    const sellingPriceNum = Number.parseFloat(sellingPrice)
    const buyingFeesNum = Number.parseFloat(buyingFees) || 0
    const sellingFeesNum = Number.parseFloat(sellingFees) || 0
    const dividendsNum = Number.parseFloat(dividends) || 0

    if (isNaN(purchasePriceNum) || purchasePriceNum <= 0) {
      setError("Please enter a valid purchase price greater than 0")
      return
    }

    if (isNaN(sharesNum) || sharesNum <= 0) {
      setError("Please enter a valid number of shares greater than 0")
      return
    }

    if (isNaN(sellingPriceNum) || sellingPriceNum <= 0) {
      setError("Please enter a valid selling price greater than 0")
      return
    }

    // Calculate total purchase cost
    const totalPurchaseCost = purchasePriceNum * sharesNum + buyingFeesNum

    // Calculate total selling proceeds
    const totalSellingProceeds = sellingPriceNum * sharesNum - sellingFeesNum

    // Calculate profit/loss without dividends
    const profitLoss = totalSellingProceeds - totalPurchaseCost
    const profitLossPercentage = (profitLoss / totalPurchaseCost) * 100

    // Calculate with dividends
    const totalWithDividends = totalSellingProceeds + dividendsNum
    const profitLossWithDividends = totalWithDividends - totalPurchaseCost
    const profitLossPercentageWithDividends = (profitLossWithDividends / totalPurchaseCost) * 100

    setResult({
      totalPurchaseCost,
      totalSellingProceeds,
      profitLoss,
      profitLossPercentage,
      totalWithDividends,
      profitLossWithDividends,
      profitLossPercentageWithDividends,
      isProfit: profitLoss >= 0,
      buyingFees: buyingFeesNum,
      sellingFees: sellingFeesNum,
      dividends: dividendsNum,
    })
  }

  const handleReset = () => {
    setPurchasePrice("")
    setSharesCount("")
    setSellingPrice("")
    setBuyingFees("")
    setSellingFees("")
    setDividends("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Stock Investment: ${result.isProfit ? "Profit" : "Loss"} of ${formatCurrency(Math.abs(result.profitLoss), currency)} (${result.profitLossPercentage.toFixed(2)}%)`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Stock Profit/Loss Result",
          text: `My stock investment resulted in a ${result.isProfit ? "profit" : "loss"} of ${formatCurrency(Math.abs(result.profitLoss), currency)} (${result.profitLossPercentage.toFixed(2)}%)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Stock Profit/Loss Calculator</CardTitle>
                    <CardDescription>Calculate your stock investment returns</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Purchase Price Input */}
                <div className="space-y-2">
                  <Label htmlFor="purchasePrice">Purchase Price per Share ({symbol})</Label>
                  <Input
                    id="purchasePrice"
                    type="number"
                    placeholder="Enter purchase price"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Number of Shares Input */}
                <div className="space-y-2">
                  <Label htmlFor="sharesCount">Number of Shares</Label>
                  <Input
                    id="sharesCount"
                    type="number"
                    placeholder="Enter number of shares"
                    value={sharesCount}
                    onChange={(e) => setSharesCount(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Selling Price Input */}
                <div className="space-y-2">
                  <Label htmlFor="sellingPrice">Selling Price per Share ({symbol})</Label>
                  <Input
                    id="sellingPrice"
                    type="number"
                    placeholder="Enter selling price"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="buyingFees">Buying Fees ({symbol})</Label>
                        <Input
                          id="buyingFees"
                          type="number"
                          placeholder="0.00"
                          value={buyingFees}
                          onChange={(e) => setBuyingFees(e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="sellingFees">Selling Fees ({symbol})</Label>
                        <Input
                          id="sellingFees"
                          type="number"
                          placeholder="0.00"
                          value={sellingFees}
                          onChange={(e) => setSellingFees(e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dividends">Dividends Received ({symbol})</Label>
                      <Input
                        id="dividends"
                        type="number"
                        placeholder="0.00"
                        value={dividends}
                        onChange={(e) => setDividends(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateProfitLoss} className="w-full" size="lg">
                  Calculate Profit/Loss
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${result.isProfit ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"} transition-all duration-300`}
                  >
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.isProfit ? "Total Profit" : "Total Loss"}
                      </p>
                      <div className="flex items-center justify-center gap-2">
                        {result.isProfit ? (
                          <TrendingUp className={`h-8 w-8 text-green-600`} />
                        ) : (
                          <TrendingDown className={`h-8 w-8 text-red-600`} />
                        )}
                        <p className={`text-4xl font-bold ${result.isProfit ? "text-green-600" : "text-red-600"}`}>
                          {result.isProfit ? "+" : "-"}
                          {formatCurrency(Math.abs(result.profitLoss), currency)}
                        </p>
                      </div>
                      <p className={`text-lg font-semibold ${result.isProfit ? "text-green-600" : "text-red-600"}`}>
                        {result.isProfit ? "+" : ""}
                        {result.profitLossPercentage.toFixed(2)}%
                      </p>
                    </div>

                    {/* Visual Comparison Bar */}
                    <div className="mt-4 space-y-2">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Cost: {formatCurrency(result.totalPurchaseCost, currency)}</span>
                        <span>Proceeds: {formatCurrency(result.totalSellingProceeds, currency)}</span>
                      </div>
                      <div className="h-4 bg-muted rounded-full overflow-hidden flex">
                        <div
                          className="bg-blue-500 h-full"
                          style={{
                            width: `${Math.min((result.totalPurchaseCost / (result.totalPurchaseCost + result.totalSellingProceeds)) * 100, 100)}%`,
                          }}
                        />
                        <div
                          className={`${result.isProfit ? "bg-green-500" : "bg-red-500"} h-full`}
                          style={{
                            width: `${Math.min((result.totalSellingProceeds / (result.totalPurchaseCost + result.totalSellingProceeds)) * 100, 100)}%`,
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="flex items-center gap-1">
                          <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                          Purchase Cost
                        </span>
                        <span className="flex items-center gap-1">
                          <span
                            className={`w-2 h-2 ${result.isProfit ? "bg-green-500" : "bg-red-500"} rounded-full`}
                          ></span>
                          Selling Proceeds
                        </span>
                      </div>
                    </div>

                    {/* Details */}
                    <Collapsible open={showDetails} onOpenChange={setShowDetails}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-4">
                          {showDetails ? "Hide Details" : "Show Details"}
                          {showDetails ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-4 space-y-3">
                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div className="p-3 bg-background rounded-lg">
                            <p className="text-muted-foreground">Total Purchase Cost</p>
                            <p className="font-semibold">{formatCurrency(result.totalPurchaseCost, currency)}</p>
                          </div>
                          <div className="p-3 bg-background rounded-lg">
                            <p className="text-muted-foreground">Total Selling Proceeds</p>
                            <p className="font-semibold">{formatCurrency(result.totalSellingProceeds, currency)}</p>
                          </div>
                          {result.buyingFees > 0 && (
                            <div className="p-3 bg-background rounded-lg">
                              <p className="text-muted-foreground">Buying Fees</p>
                              <p className="font-semibold">{formatCurrency(result.buyingFees, currency)}</p>
                            </div>
                          )}
                          {result.sellingFees > 0 && (
                            <div className="p-3 bg-background rounded-lg">
                              <p className="text-muted-foreground">Selling Fees</p>
                              <p className="font-semibold">{formatCurrency(result.sellingFees, currency)}</p>
                            </div>
                          )}
                          {result.dividends > 0 && (
                            <>
                              <div className="p-3 bg-background rounded-lg">
                                <p className="text-muted-foreground">Dividends Received</p>
                                <p className="font-semibold text-green-600">
                                  +{formatCurrency(result.dividends, currency)}
                                </p>
                              </div>
                              <div className="p-3 bg-background rounded-lg">
                                <p className="text-muted-foreground">Total Return (with Dividends)</p>
                                <p
                                  className={`font-semibold ${result.profitLossWithDividends >= 0 ? "text-green-600" : "text-red-600"}`}
                                >
                                  {result.profitLossWithDividends >= 0 ? "+" : ""}
                                  {formatCurrency(result.profitLossWithDividends, currency)} (
                                  {result.profitLossPercentageWithDividends.toFixed(2)}%)
                                </p>
                              </div>
                            </>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Return Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Excellent Return</span>
                      <span className="text-sm text-green-600">{"> 20%"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">Good Return</span>
                      <span className="text-sm text-emerald-600">10% – 20%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Return</span>
                      <span className="text-sm text-yellow-600">0% – 10%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Loss</span>
                      <span className="text-sm text-red-600">{"< 0%"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center space-y-2">
                    <p className="font-semibold text-foreground text-xs">
                      Profit/Loss = Selling Proceeds − Purchase Cost
                    </p>
                    <p className="font-semibold text-foreground text-xs">Return % = (Profit/Loss ÷ Cost) × 100</p>
                  </div>
                  <p>
                    <strong>Purchase Cost</strong> = (Price × Shares) + Buying Fees
                  </p>
                  <p>
                    <strong>Selling Proceeds</strong> = (Price × Shares) − Selling Fees
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Stock Profit/Loss?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Stock profit or loss represents the financial gain or reduction in value from buying and selling
                  shares of a company. When you purchase stocks at a certain price and later sell them at a higher
                  price, the difference is your profit. Conversely, if you sell at a lower price than your purchase
                  price, you incur a loss. Understanding your investment returns is crucial for making informed
                  decisions about your portfolio.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculation becomes more comprehensive when you factor in transaction costs (brokerage fees) and
                  any dividend income received during the holding period. Transaction fees reduce your overall return,
                  while dividends add to it. A complete analysis of your stock investment should include all these
                  components to give you an accurate picture of your investment performance.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  To calculate your stock investment return, enter the price per share at which you purchased the stock,
                  the number of shares you bought, and the current or selling price per share. The calculator will
                  instantly show you the profit or loss amount and the percentage return on your investment.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For a more accurate calculation, expand the Advanced Options to include any brokerage or transaction
                  fees you paid when buying and selling, as well as any dividends you received. These additional inputs
                  help provide a complete picture of your actual investment return, accounting for all costs and income
                  associated with the investment.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Important Considerations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Transaction Costs</h4>
                    <p className="text-blue-700 text-sm">
                      Brokerage fees, commissions, and other transaction costs can significantly impact your returns,
                      especially on smaller investments. Always factor these in when calculating your actual profit or
                      loss.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Dividend Income</h4>
                    <p className="text-green-700 text-sm">
                      Dividends are often overlooked but can be a significant component of total return. Include all
                      dividend payments received during your holding period for accurate calculations.
                    </p>
                  </div>
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Tax Implications</h4>
                    <p className="text-yellow-700 text-sm">
                      Remember that capital gains and dividends may be subject to taxes, which will affect your net
                      return. Consult a tax professional for advice specific to your situation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <p className="text-sm text-muted-foreground">
                    <strong>Disclaimer:</strong> Stock profit/loss calculations are estimates based on entered values.
                    Actual investment outcomes may vary due to market fluctuations, fees, and taxes. This calculator
                    does not account for inflation, opportunity cost, or time value of money. Consult a financial
                    advisor for personalized investment guidance.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
