"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, TrendingUp, Info, AlertTriangle, Building2 } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type ConcreteGrade = "M10" | "M15" | "M20" | "M25" | "M30" | "M35" | "M40"
type CuringType = "standard" | "accelerated" | "steam"
type StrengthUnit = "MPa" | "psi"

interface StrengthResult {
  strength: number
  percentage: number
  designStrength: number
  category: string
  recommendation: string
  color: string
  bgColor: string
}

export function ConcreteStrengthGainCalculator() {
  const [concreteGrade, setConcreteGrade] = useState<ConcreteGrade>("M25")
  const [age, setAge] = useState("")
  const [curingType, setCuringType] = useState<CuringType>("standard")
  const [strengthUnit, setStrengthUnit] = useState<StrengthUnit>("MPa")
  const [result, setResult] = useState<StrengthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateStrength = () => {
    setError("")
    setResult(null)

    const ageNum = Number.parseFloat(age)
    if (isNaN(ageNum) || ageNum < 1) {
      setError("Please enter a valid age of at least 1 day")
      return
    }

    if (ageNum > 365) {
      setError("Age should typically be within 365 days for practical purposes")
      return
    }

    // Design strength at 28 days (in MPa)
    const gradeStrength: Record<ConcreteGrade, number> = {
      M10: 10,
      M15: 15,
      M20: 20,
      M25: 25,
      M30: 30,
      M35: 35,
      M40: 40,
    }

    const designStrength = gradeStrength[concreteGrade]

    // Calculate strength gain using maturity method: f(t) = f_ck × (t / (t + 4))
    // This is a simplified version of the actual strength gain curve
    let strengthFactor: number

    if (curingType === "steam") {
      // Steam curing accelerates early strength gain
      strengthFactor = ageNum / (ageNum + 1)
    } else if (curingType === "accelerated") {
      // Accelerated curing with admixtures
      strengthFactor = ageNum / (ageNum + 2)
    } else {
      // Standard water curing
      strengthFactor = ageNum / (ageNum + 4)
    }

    // Adjust for typical strength gain milestones
    if (ageNum <= 1) {
      strengthFactor = 0.16 // ~16% at 1 day
    } else if (ageNum <= 3) {
      strengthFactor = 0.4 // ~40% at 3 days
    } else if (ageNum <= 7) {
      strengthFactor = 0.65 // ~65% at 7 days
    } else if (ageNum <= 14) {
      strengthFactor = 0.85 // ~85% at 14 days
    } else if (ageNum >= 28) {
      strengthFactor = 1.0 + (ageNum - 28) * 0.001 // Slight continued gain after 28 days
      if (strengthFactor > 1.15) strengthFactor = 1.15 // Cap at 115%
    }

    let currentStrength = designStrength * strengthFactor
    const percentage = (strengthFactor * 100)

    // Convert to psi if needed
    if (strengthUnit === "psi") {
      currentStrength = currentStrength * 145.038 // 1 MPa = 145.038 psi
    }

    const displayDesignStrength = strengthUnit === "MPa" ? designStrength : designStrength * 145.038

    // Determine category and recommendation
    let category: string
    let recommendation: string
    let color: string
    let bgColor: string

    if (percentage < 50) {
      category = "Early Stage"
      recommendation = "Concrete is still developing. Continue curing and avoid loading. Do not remove formwork yet."
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else if (percentage < 70) {
      category = "Developing Strength"
      recommendation =
        "Concrete is gaining strength. Continue curing. Light formwork removal may be considered for some elements."
      color = "text-orange-600"
      bgColor = "bg-orange-50 border-orange-200"
    } else if (percentage < 90) {
      category = "Good Strength"
      recommendation = "Concrete has good strength. Most formwork can be removed. Continue curing for full strength."
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (percentage < 100) {
      category = "Near Design Strength"
      recommendation = "Concrete is approaching design strength. Normal loading can begin with engineering approval."
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else {
      category = "Full Design Strength"
      recommendation = "Concrete has achieved design strength. Full loading permitted as per design specifications."
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    }

    setResult({
      strength: Math.round(currentStrength * 10) / 10,
      percentage: Math.round(percentage * 10) / 10,
      designStrength: Math.round(displayDesignStrength * 10) / 10,
      category,
      recommendation,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setConcreteGrade("M25")
    setAge("")
    setCuringType("standard")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Concrete Strength: ${result.strength} ${strengthUnit} (${result.percentage}% of design strength) for ${concreteGrade} at ${age} days`
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Concrete Strength Gain Result",
          text: `Estimated strength: ${result.strength} ${strengthUnit} (${result.percentage}% of design) for ${concreteGrade} at ${age} days`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleStrengthUnit = () => {
    setStrengthUnit((prev) => (prev === "MPa" ? "psi" : "MPa"))
    setResult(null)
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Concrete Strength Gain Calculator</CardTitle>
                    <CardDescription>Estimate strength development over time</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Concrete Grade */}
                <div className="space-y-2">
                  <Label htmlFor="grade">Concrete Grade</Label>
                  <Select value={concreteGrade} onValueChange={(value: ConcreteGrade) => setConcreteGrade(value)}>
                    <SelectTrigger id="grade">
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M10">M10 (10 MPa)</SelectItem>
                      <SelectItem value="M15">M15 (15 MPa)</SelectItem>
                      <SelectItem value="M20">M20 (20 MPa)</SelectItem>
                      <SelectItem value="M25">M25 (25 MPa)</SelectItem>
                      <SelectItem value="M30">M30 (30 MPa)</SelectItem>
                      <SelectItem value="M35">M35 (35 MPa)</SelectItem>
                      <SelectItem value="M40">M40 (40 MPa)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Age */}
                <div className="space-y-2">
                  <Label htmlFor="age">Age of Concrete (days)</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter age in days"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    step="1"
                  />
                </div>

                {/* Curing Type */}
                <div className="space-y-2">
                  <Label htmlFor="curing">Curing Type</Label>
                  <Select value={curingType} onValueChange={(value: CuringType) => setCuringType(value)}>
                    <SelectTrigger id="curing">
                      <SelectValue placeholder="Select curing type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">Standard Water Curing</SelectItem>
                      <SelectItem value="accelerated">Accelerated Curing</SelectItem>
                      <SelectItem value="steam">Steam Curing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Unit Selection */}
                <div className="space-y-2">
                  <Label>Strength Unit</Label>
                  <button
                    onClick={toggleStrengthUnit}
                    className="relative inline-flex h-9 w-full items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        strengthUnit === "psi" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        strengthUnit === "MPa" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      MPa
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        strengthUnit === "psi" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      psi
                    </span>
                  </button>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateStrength} className="w-full" size="lg">
                  Calculate Strength
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Estimated Strength</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.strength}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{strengthUnit}</p>
                      <p className="text-sm text-muted-foreground mt-2">{result.category}</p>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between p-2 bg-background/50 rounded">
                        <span className="text-muted-foreground">Design Strength:</span>
                        <span className="font-medium">
                          {result.designStrength} {strengthUnit}
                        </span>
                      </div>
                      <div className="flex justify-between p-2 bg-background/50 rounded">
                        <span className="text-muted-foreground">Strength Achieved:</span>
                        <span className="font-medium">{result.percentage}%</span>
                      </div>
                      <div className="p-3 bg-background/50 rounded mt-3">
                        <p className="font-medium mb-1">Recommendation:</p>
                        <p className="text-muted-foreground text-xs leading-relaxed">{result.recommendation}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Strength Gain</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">1 Day</span>
                      <span className="text-sm text-amber-600">~16%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">3 Days</span>
                      <span className="text-sm text-amber-600">~40%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">7 Days</span>
                      <span className="text-sm text-amber-600">~65%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <span className="font-medium text-amber-700">28 Days</span>
                      <span className="text-sm text-amber-600">100%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Curing Methods</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div>
                    <h4 className="font-semibold mb-1">Standard Curing</h4>
                    <p className="text-muted-foreground text-xs">Normal strength gain with water curing</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Accelerated Curing</h4>
                    <p className="text-muted-foreground text-xs">Faster early strength with admixtures</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Steam Curing</h4>
                    <p className="text-muted-foreground text-xs">Rapid strength gain for precast elements</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Strength Gain */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Concrete Strength Gain?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Concrete strength gain refers to the progressive increase in compressive strength that occurs as
                  concrete cures over time. This process is driven by the hydration reaction between cement and water,
                  which forms calcium silicate hydrates (C-S-H) that bind the aggregate particles together. The rate of
                  strength gain is most rapid in the first few days and gradually slows down, with concrete typically
                  achieving its design strength at 28 days under standard curing conditions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Understanding the strength development curve is crucial for construction scheduling, formwork removal,
                  and load application. While concrete continues to gain strength well beyond 28 days, the rate of gain
                  becomes progressively slower. Factors affecting strength gain include water-cement ratio, cement type,
                  aggregate quality, curing conditions (temperature and moisture), and the use of admixtures or
                  supplementary cementitious materials.
                </p>
              </CardContent>
            </Card>

            {/* How Strength Develops */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>How Concrete Strength Develops</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The strength development of concrete follows a predictable pattern described by the maturity method.
                  At early ages (1-3 days), concrete rapidly gains strength as the initial hydration reactions occur.
                  By 7 days, concrete typically reaches about 65-70% of its 28-day strength, making this a critical
                  milestone for many construction activities. The rate of strength gain then slows, with concrete
                  achieving approximately 85-90% of design strength by 14 days and reaching 100% at 28 days.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Different curing methods can significantly accelerate or modify this curve. Steam curing, commonly
                  used for precast concrete elements, can achieve 70% of design strength within 24 hours by elevating
                  temperatures and maintaining optimal moisture. Chemical accelerators can speed early strength gain
                  without heat, beneficial for cold weather construction. However, rapid early strength gain may
                  sometimes come at the cost of slightly lower ultimate strength, making proper curing method selection
                  critical for specific applications.
                </p>
              </CardContent>
            </Card>

            {/* Common Questions */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>Common Questions About Strength Gain</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Why is 28 days the standard testing age?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    The 28-day testing age became standard because concrete achieves most of its design strength by this
                    time, providing a practical balance between waiting for full development and construction timelines.
                    It's a convention established by codes and standards worldwide.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Does concrete continue gaining strength after 28 days?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Yes, concrete continues to gain strength for months or even years after 28 days, though at a
                    decreasing rate. Long-term strength can be 10-20% higher than 28-day strength, especially for
                    concrete containing supplementary cementitious materials like fly ash.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">When can formwork be safely removed?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Formwork removal timing depends on the structural element and achieved strength. Vertical forms
                    (columns, walls) can typically be removed at 24-48 hours. Soffit forms for slabs require 70% design
                    strength, usually 7-14 days. Always follow engineering specifications and local codes.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">How does temperature affect strength gain?</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Higher temperatures accelerate hydration and early strength gain but may reduce ultimate strength.
                    Cold temperatures slow hydration significantly—below 10°C, hydration nearly stops. The maturity
                    method accounts for temperature by calculating equivalent age at a reference temperature.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-amber-900 mb-2">Important Note</h3>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Concrete strength estimates are indicative and based on typical strength gain curves. Actual
                      strength depends on numerous factors including mix design, curing conditions, temperature,
                      materials quality, and site practices. For critical structural decisions, always conduct physical
                      testing and consult with a qualified structural engineer.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
