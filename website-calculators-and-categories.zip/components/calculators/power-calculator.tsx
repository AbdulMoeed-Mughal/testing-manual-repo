"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Zap, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculateTarget = "P" | "V" | "I" | "R"

interface PowerResult {
  value: number
  unit: string
  formula: string
  steps: string[]
}

const prefixes = [
  { value: "p", label: "pico (p)", multiplier: 1e-12 },
  { value: "n", label: "nano (n)", multiplier: 1e-9 },
  { value: "µ", label: "micro (µ)", multiplier: 1e-6 },
  { value: "m", label: "milli (m)", multiplier: 1e-3 },
  { value: "base", label: "base", multiplier: 1 },
  { value: "k", label: "kilo (k)", multiplier: 1e3 },
  { value: "M", label: "Mega (M)", multiplier: 1e6 },
  { value: "G", label: "Giga (G)", multiplier: 1e9 },
]

export function PowerCalculator() {
  const [target, setTarget] = useState<CalculateTarget>("P")
  const [voltage, setVoltage] = useState("")
  const [voltagePrefix, setVoltagePrefix] = useState("base")
  const [current, setCurrent] = useState("")
  const [currentPrefix, setCurrentPrefix] = useState("base")
  const [resistance, setResistance] = useState("")
  const [resistancePrefix, setResistancePrefix] = useState("base")
  const [power, setPower] = useState("")
  const [powerPrefix, setPowerPrefix] = useState("base")
  const [result, setResult] = useState<PowerResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const getMultiplier = (prefix: string) => {
    return prefixes.find((p) => p.value === prefix)?.multiplier || 1
  }

  const formatWithPrefix = (value: number, baseUnit: string): { value: number; unit: string } => {
    const absValue = Math.abs(value)

    if (absValue === 0) return { value: 0, unit: baseUnit }

    if (absValue >= 1e9) return { value: value / 1e9, unit: `G${baseUnit}` }
    if (absValue >= 1e6) return { value: value / 1e6, unit: `M${baseUnit}` }
    if (absValue >= 1e3) return { value: value / 1e3, unit: `k${baseUnit}` }
    if (absValue >= 1) return { value: value, unit: baseUnit }
    if (absValue >= 1e-3) return { value: value / 1e-3, unit: `m${baseUnit}` }
    if (absValue >= 1e-6) return { value: value / 1e-6, unit: `µ${baseUnit}` }
    if (absValue >= 1e-9) return { value: value / 1e-9, unit: `n${baseUnit}` }
    return { value: value / 1e-12, unit: `p${baseUnit}` }
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const V = voltage ? Number.parseFloat(voltage) * getMultiplier(voltagePrefix) : null
    const I = current ? Number.parseFloat(current) * getMultiplier(currentPrefix) : null
    const R = resistance ? Number.parseFloat(resistance) * getMultiplier(resistancePrefix) : null
    const P = power ? Number.parseFloat(power) * getMultiplier(powerPrefix) : null

    // Validate no negative values
    if ((V !== null && V < 0) || (I !== null && I < 0) || (R !== null && R < 0) || (P !== null && P < 0)) {
      setError("Negative values are not allowed")
      return
    }

    let calculatedValue: number
    let formula: string
    let steps: string[]
    let baseUnit: string

    switch (target) {
      case "P":
        if (V !== null && I !== null) {
          calculatedValue = V * I
          formula = "P = V × I"
          steps = [
            `Using formula: P = V × I`,
            `P = ${V.toExponential(4)} V × ${I.toExponential(4)} A`,
            `P = ${calculatedValue.toExponential(4)} W`,
          ]
        } else if (V !== null && R !== null && R !== 0) {
          calculatedValue = (V * V) / R
          formula = "P = V² ÷ R"
          steps = [
            `Using formula: P = V² ÷ R`,
            `P = (${V.toExponential(4)} V)² ÷ ${R.toExponential(4)} Ω`,
            `P = ${(V * V).toExponential(4)} V² ÷ ${R.toExponential(4)} Ω`,
            `P = ${calculatedValue.toExponential(4)} W`,
          ]
        } else if (I !== null && R !== null) {
          calculatedValue = I * I * R
          formula = "P = I² × R"
          steps = [
            `Using formula: P = I² × R`,
            `P = (${I.toExponential(4)} A)² × ${R.toExponential(4)} Ω`,
            `P = ${(I * I).toExponential(4)} A² × ${R.toExponential(4)} Ω`,
            `P = ${calculatedValue.toExponential(4)} W`,
          ]
        } else {
          setError("Please enter at least two values (V and I, V and R, or I and R)")
          return
        }
        baseUnit = "W"
        break

      case "V":
        if (P !== null && I !== null && I !== 0) {
          calculatedValue = P / I
          formula = "V = P ÷ I"
          steps = [
            `Using formula: V = P ÷ I`,
            `V = ${P.toExponential(4)} W ÷ ${I.toExponential(4)} A`,
            `V = ${calculatedValue.toExponential(4)} V`,
          ]
        } else if (P !== null && R !== null) {
          calculatedValue = Math.sqrt(P * R)
          formula = "V = √(P × R)"
          steps = [
            `Using formula: V = √(P × R)`,
            `V = √(${P.toExponential(4)} W × ${R.toExponential(4)} Ω)`,
            `V = √(${(P * R).toExponential(4)})`,
            `V = ${calculatedValue.toExponential(4)} V`,
          ]
        } else if (I !== null && R !== null) {
          calculatedValue = I * R
          formula = "V = I × R"
          steps = [
            `Using formula: V = I × R (Ohm's Law)`,
            `V = ${I.toExponential(4)} A × ${R.toExponential(4)} Ω`,
            `V = ${calculatedValue.toExponential(4)} V`,
          ]
        } else {
          setError("Please enter at least two values (P and I, P and R, or I and R)")
          return
        }
        baseUnit = "V"
        break

      case "I":
        if (P !== null && V !== null && V !== 0) {
          calculatedValue = P / V
          formula = "I = P ÷ V"
          steps = [
            `Using formula: I = P ÷ V`,
            `I = ${P.toExponential(4)} W ÷ ${V.toExponential(4)} V`,
            `I = ${calculatedValue.toExponential(4)} A`,
          ]
        } else if (P !== null && R !== null && R !== 0) {
          calculatedValue = Math.sqrt(P / R)
          formula = "I = √(P ÷ R)"
          steps = [
            `Using formula: I = √(P ÷ R)`,
            `I = √(${P.toExponential(4)} W ÷ ${R.toExponential(4)} Ω)`,
            `I = √(${(P / R).toExponential(4)})`,
            `I = ${calculatedValue.toExponential(4)} A`,
          ]
        } else if (V !== null && R !== null && R !== 0) {
          calculatedValue = V / R
          formula = "I = V ÷ R"
          steps = [
            `Using formula: I = V ÷ R (Ohm's Law)`,
            `I = ${V.toExponential(4)} V ÷ ${R.toExponential(4)} Ω`,
            `I = ${calculatedValue.toExponential(4)} A`,
          ]
        } else {
          setError("Please enter at least two values (P and V, P and R, or V and R)")
          return
        }
        baseUnit = "A"
        break

      case "R":
        if (V !== null && P !== null && P !== 0) {
          calculatedValue = (V * V) / P
          formula = "R = V² ÷ P"
          steps = [
            `Using formula: R = V² ÷ P`,
            `R = (${V.toExponential(4)} V)² ÷ ${P.toExponential(4)} W`,
            `R = ${(V * V).toExponential(4)} V² ÷ ${P.toExponential(4)} W`,
            `R = ${calculatedValue.toExponential(4)} Ω`,
          ]
        } else if (P !== null && I !== null && I !== 0) {
          calculatedValue = P / (I * I)
          formula = "R = P ÷ I²"
          steps = [
            `Using formula: R = P ÷ I²`,
            `R = ${P.toExponential(4)} W ÷ (${I.toExponential(4)} A)²`,
            `R = ${P.toExponential(4)} W ÷ ${(I * I).toExponential(4)} A²`,
            `R = ${calculatedValue.toExponential(4)} Ω`,
          ]
        } else if (V !== null && I !== null && I !== 0) {
          calculatedValue = V / I
          formula = "R = V ÷ I"
          steps = [
            `Using formula: R = V ÷ I (Ohm's Law)`,
            `R = ${V.toExponential(4)} V ÷ ${I.toExponential(4)} A`,
            `R = ${calculatedValue.toExponential(4)} Ω`,
          ]
        } else {
          setError("Please enter at least two values (V and P, P and I, or V and I)")
          return
        }
        baseUnit = "Ω"
        break

      default:
        return
    }

    const formatted = formatWithPrefix(calculatedValue, baseUnit)
    setResult({
      value: formatted.value,
      unit: formatted.unit,
      formula,
      steps,
    })
  }

  const handleReset = () => {
    setVoltage("")
    setVoltagePrefix("base")
    setCurrent("")
    setCurrentPrefix("base")
    setResistance("")
    setResistancePrefix("base")
    setPower("")
    setPowerPrefix("base")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `${target} = ${result.value.toPrecision(6)} ${result.unit} (${result.formula})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const getTargetLabel = (t: CalculateTarget) => {
    switch (t) {
      case "P":
        return "Power (P)"
      case "V":
        return "Voltage (V)"
      case "I":
        return "Current (I)"
      case "R":
        return "Resistance (R)"
    }
  }

  const getTargetColor = (t: CalculateTarget) => {
    switch (t) {
      case "P":
        return "text-yellow-600"
      case "V":
        return "text-blue-600"
      case "I":
        return "text-green-600"
      case "R":
        return "text-red-600"
    }
  }

  const getTargetBg = (t: CalculateTarget) => {
    switch (t) {
      case "P":
        return "bg-yellow-50 border-yellow-200"
      case "V":
        return "bg-blue-50 border-blue-200"
      case "I":
        return "bg-green-50 border-green-200"
      case "R":
        return "bg-red-50 border-red-200"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Power Calculator</CardTitle>
                    <CardDescription>Calculate electrical power relationships</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Target Selection */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select
                    value={target}
                    onValueChange={(v) => {
                      setTarget(v as CalculateTarget)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="P">Power (P) - Watts</SelectItem>
                      <SelectItem value="V">Voltage (V) - Volts</SelectItem>
                      <SelectItem value="I">Current (I) - Amperes</SelectItem>
                      <SelectItem value="R">Resistance (R) - Ohms</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Voltage Input */}
                {target !== "V" && (
                  <div className="space-y-2">
                    <Label htmlFor="voltage">Voltage (V)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="voltage"
                        type="number"
                        placeholder="Enter voltage"
                        value={voltage}
                        onChange={(e) => setVoltage(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={voltagePrefix} onValueChange={setVoltagePrefix}>
                        <SelectTrigger className="w-28">
                          <SelectValue placeholder="V" />
                        </SelectTrigger>
                        <SelectContent>
                          {prefixes.map((p) => (
                            <SelectItem key={p.value} value={p.value}>
                              {p.value === "base" ? "V" : `${p.value}V`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Current Input */}
                {target !== "I" && (
                  <div className="space-y-2">
                    <Label htmlFor="current">Current (I)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="current"
                        type="number"
                        placeholder="Enter current"
                        value={current}
                        onChange={(e) => setCurrent(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={currentPrefix} onValueChange={setCurrentPrefix}>
                        <SelectTrigger className="w-28">
                          <SelectValue placeholder="A" />
                        </SelectTrigger>
                        <SelectContent>
                          {prefixes.map((p) => (
                            <SelectItem key={p.value} value={p.value}>
                              {p.value === "base" ? "A" : `${p.value}A`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Resistance Input */}
                {target !== "R" && (
                  <div className="space-y-2">
                    <Label htmlFor="resistance">Resistance (R)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="resistance"
                        type="number"
                        placeholder="Enter resistance"
                        value={resistance}
                        onChange={(e) => setResistance(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={resistancePrefix} onValueChange={setResistancePrefix}>
                        <SelectTrigger className="w-28">
                          <SelectValue placeholder="Ω" />
                        </SelectTrigger>
                        <SelectContent>
                          {prefixes.map((p) => (
                            <SelectItem key={p.value} value={p.value}>
                              {p.value === "base" ? "Ω" : `${p.value}Ω`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Power Input */}
                {target !== "P" && (
                  <div className="space-y-2">
                    <Label htmlFor="power">Power (P)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="power"
                        type="number"
                        placeholder="Enter power"
                        value={power}
                        onChange={(e) => setPower(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={powerPrefix} onValueChange={setPowerPrefix}>
                        <SelectTrigger className="w-28">
                          <SelectValue placeholder="W" />
                        </SelectTrigger>
                        <SelectContent>
                          {prefixes.map((p) => (
                            <SelectItem key={p.value} value={p.value}>
                              {p.value === "base" ? "W" : `${p.value}W`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  <Calculator className="mr-2 h-4 w-4" />
                  Calculate {getTargetLabel(target)}
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getTargetBg(target)} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{getTargetLabel(target)}</p>
                      <p className={`text-4xl font-bold ${getTargetColor(target)} mb-1`}>
                        {result.value.toPrecision(6)}
                      </p>
                      <p className={`text-xl font-semibold ${getTargetColor(target)} mb-2`}>{result.unit}</p>
                      <p className="text-sm text-muted-foreground font-mono">{result.formula}</p>
                    </div>

                    {/* Step-by-step toggle */}
                    <div className="mt-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowSteps(!showSteps)}
                        className="w-full text-muted-foreground"
                      >
                        {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                      </Button>
                      {showSteps && (
                        <div className="mt-3 p-3 bg-background rounded-lg text-sm space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="font-mono text-xs text-muted-foreground">
                              {step}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Power Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                    <p className="font-semibold text-yellow-800 text-sm mb-1">Calculate Power (P)</p>
                    <p className="font-mono text-xs text-yellow-700">P = V × I</p>
                    <p className="font-mono text-xs text-yellow-700">P = V² ÷ R</p>
                    <p className="font-mono text-xs text-yellow-700">P = I² × R</p>
                  </div>
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="font-semibold text-blue-800 text-sm mb-1">Calculate Voltage (V)</p>
                    <p className="font-mono text-xs text-blue-700">V = P ÷ I</p>
                    <p className="font-mono text-xs text-blue-700">V = √(P × R)</p>
                    <p className="font-mono text-xs text-blue-700">V = I × R</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="font-semibold text-green-800 text-sm mb-1">Calculate Current (I)</p>
                    <p className="font-mono text-xs text-green-700">I = P ÷ V</p>
                    <p className="font-mono text-xs text-green-700">I = √(P ÷ R)</p>
                    <p className="font-mono text-xs text-green-700">I = V ÷ R</p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                    <p className="font-semibold text-red-800 text-sm mb-1">Calculate Resistance (R)</p>
                    <p className="font-mono text-xs text-red-700">R = V² ÷ P</p>
                    <p className="font-mono text-xs text-red-700">R = P ÷ I²</p>
                    <p className="font-mono text-xs text-red-700">R = V ÷ I</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Prefixes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono font-semibold">G</span> = 10⁹ (Giga)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono font-semibold">M</span> = 10⁶ (Mega)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono font-semibold">k</span> = 10³ (kilo)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono font-semibold">m</span> = 10⁻³ (milli)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono font-semibold">µ</span> = 10⁻⁶ (micro)
                    </div>
                    <div className="p-2 bg-muted rounded">
                      <span className="font-mono font-semibold">n</span> = 10⁻⁹ (nano)
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Results assume ideal electrical conditions. Real circuits may vary due to component tolerances
                        and environmental factors.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Electrical Power</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Electrical power is a fundamental concept in physics and electrical engineering that describes the
                  rate at which electrical energy is transferred or converted in an electrical circuit. Measured in
                  watts (W), power represents how quickly work is being done by or on an electrical system.
                  Understanding power relationships is essential for designing efficient circuits, selecting appropriate
                  components, and ensuring safe operation of electrical systems.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept of electrical power was developed during the 19th century as scientists and engineers
                  worked to harness electricity for practical applications. James Watt, whose name is now the unit of
                  power, made significant contributions to understanding energy transfer, although his work primarily
                  focused on steam engines. The application of power concepts to electricity came later through the work
                  of scientists like James Prescott Joule and Georg Ohm.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>The Power Triangle and Relationships</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The relationships between power, voltage, current, and resistance form an interconnected web of
                  equations often visualized as the "power wheel" or "PIE wheel." The most fundamental equation is P = V
                  × I, which states that power equals voltage multiplied by current. This makes intuitive sense: voltage
                  represents the "pressure" pushing electrons, while current represents the flow rate of those
                  electrons.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  By combining the basic power equation with Ohm's Law (V = I × R), we can derive additional formulas.
                  Substituting V = I × R into P = V × I gives us P = I² × R, showing that power is proportional to the
                  square of the current. Similarly, substituting I = V/R gives us P = V²/R. These variations allow us to
                  calculate power when we have different known quantities.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications of Power Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Power calculations have countless real-world applications. In home electrical systems, understanding
                  power helps determine how many appliances can safely share a circuit. A typical 15-amp household
                  circuit at 120V can provide 1,800W of power. Knowing this, you can calculate whether adding another
                  device might overload the circuit.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In electronics design, power calculations are crucial for selecting components with appropriate
                  ratings. Resistors, for example, are rated for maximum power dissipation. A resistor in a circuit
                  carrying more power than its rating will overheat and potentially fail. Engineers must calculate
                  expected power dissipation and select components with adequate safety margins, typically choosing
                  components rated for at least twice the expected power.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Battery life calculations also depend on power relationships. A battery's capacity is often rated in
                  milliamp-hours (mAh). By calculating the power consumption of a device and converting to current draw,
                  you can estimate how long a battery will last. For example, a 1000mAh battery powering a device
                  drawing 100mA will theoretically last about 10 hours.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Power Loss and Efficiency</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  An important application of power calculations involves understanding power loss in electrical
                  systems. When current flows through any conductor with resistance, power is dissipated as heat
                  according to P = I²R. This is why high-voltage transmission lines are used for long-distance power
                  distribution: by increasing voltage and decreasing current for the same power transfer, the I²R losses
                  are dramatically reduced.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Efficiency calculations compare power output to power input. No real electrical system is 100%
                  efficient; some power is always lost to heat, electromagnetic radiation, or other forms. Understanding
                  these losses through power calculations helps engineers design more efficient systems, whether it's a
                  power supply, motor, or LED lighting system. Improving efficiency by even a few percentage points can
                  result in significant energy savings at scale.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
