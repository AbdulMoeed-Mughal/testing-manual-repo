"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Cog, Info, ChevronDown, ChevronUp } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type CalculationMethod = "force" | "distance"
type ForceUnit = "N" | "kN" | "lb" | "kgf"
type DistanceUnit = "m" | "cm" | "mm" | "ft" | "in"
type MachineType = "general" | "lever" | "pulley" | "inclinedPlane" | "wedge" | "screw" | "wheelAxle"

interface MAResult {
  ma: number
  effectiveMA: number
  efficiency: number
  machineType: string
  rating: string
  color: string
  bgColor: string
}

const forceConversions: Record<ForceUnit, number> = {
  N: 1,
  kN: 1000,
  lb: 4.44822,
  kgf: 9.80665,
}

const distanceConversions: Record<DistanceUnit, number> = {
  m: 1,
  cm: 0.01,
  mm: 0.001,
  ft: 0.3048,
  in: 0.0254,
}

const machineTypes: { value: MachineType; label: string; description: string }[] = [
  { value: "general", label: "General", description: "Any mechanical system" },
  { value: "lever", label: "Lever", description: "MA = effort arm / load arm" },
  { value: "pulley", label: "Pulley System", description: "MA = number of supporting ropes" },
  { value: "inclinedPlane", label: "Inclined Plane", description: "MA = length / height" },
  { value: "wedge", label: "Wedge", description: "MA = length / thickness" },
  { value: "screw", label: "Screw", description: "MA = 2πr / pitch" },
  { value: "wheelAxle", label: "Wheel & Axle", description: "MA = wheel radius / axle radius" },
]

export function MechanicalAdvantageCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("force")
  const [machineType, setMachineType] = useState<MachineType>("general")
  const [inputForce, setInputForce] = useState("")
  const [outputForce, setOutputForce] = useState("")
  const [inputDistance, setInputDistance] = useState("")
  const [outputDistance, setOutputDistance] = useState("")
  const [forceUnit, setForceUnit] = useState<ForceUnit>("N")
  const [distanceUnit, setDistanceUnit] = useState<DistanceUnit>("m")
  const [efficiency, setEfficiency] = useState("100")
  const [result, setResult] = useState<MAResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateMA = () => {
    setError("")
    setResult(null)

    let ma = 0

    if (method === "force") {
      const fIn = Number.parseFloat(inputForce)
      const fOut = Number.parseFloat(outputForce)

      if (isNaN(fIn) || fIn <= 0) {
        setError("Please enter a valid input force greater than 0")
        return
      }
      if (isNaN(fOut) || fOut <= 0) {
        setError("Please enter a valid output force greater than 0")
        return
      }

      // Convert to Newtons
      const fInN = fIn * forceConversions[forceUnit]
      const fOutN = fOut * forceConversions[forceUnit]

      ma = fOutN / fInN
    } else {
      const dIn = Number.parseFloat(inputDistance)
      const dOut = Number.parseFloat(outputDistance)

      if (isNaN(dIn) || dIn <= 0) {
        setError("Please enter a valid input distance greater than 0")
        return
      }
      if (isNaN(dOut) || dOut <= 0) {
        setError("Please enter a valid output distance greater than 0")
        return
      }

      // Convert to meters
      const dInM = dIn * distanceConversions[distanceUnit]
      const dOutM = dOut * distanceConversions[distanceUnit]

      ma = dInM / dOutM
    }

    const effValue = Number.parseFloat(efficiency) || 100
    if (effValue < 0 || effValue > 100) {
      setError("Efficiency must be between 0 and 100%")
      return
    }

    const effectiveMA = ma * (effValue / 100)

    let rating: string
    let color: string
    let bgColor: string

    if (ma < 1) {
      rating = "Disadvantage"
      color = "text-red-600"
      bgColor = "bg-red-50 border-red-200"
    } else if (ma === 1) {
      rating = "Neutral"
      color = "text-yellow-600"
      bgColor = "bg-yellow-50 border-yellow-200"
    } else if (ma < 2) {
      rating = "Low Advantage"
      color = "text-blue-600"
      bgColor = "bg-blue-50 border-blue-200"
    } else if (ma < 5) {
      rating = "Good Advantage"
      color = "text-green-600"
      bgColor = "bg-green-50 border-green-200"
    } else {
      rating = "High Advantage"
      color = "text-emerald-600"
      bgColor = "bg-emerald-50 border-emerald-200"
    }

    const machineLabel = machineTypes.find((m) => m.value === machineType)?.label || "General"

    setResult({
      ma: Math.round(ma * 1000) / 1000,
      effectiveMA: Math.round(effectiveMA * 1000) / 1000,
      efficiency: effValue,
      machineType: machineLabel,
      rating,
      color,
      bgColor,
    })
  }

  const handleReset = () => {
    setInputForce("")
    setOutputForce("")
    setInputDistance("")
    setOutputDistance("")
    setEfficiency("100")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Mechanical Advantage: ${result.ma} (${result.rating})${result.efficiency < 100 ? ` | Effective MA: ${result.effectiveMA} at ${result.efficiency}% efficiency` : ""}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Mechanical Advantage Result",
          text: `I calculated a Mechanical Advantage of ${result.ma} (${result.rating}) using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const renderSteps = () => {
    if (!result) return null

    if (method === "force") {
      const fIn = Number.parseFloat(inputForce)
      const fOut = Number.parseFloat(outputForce)
      return (
        <div className="space-y-2 text-sm">
          <p>
            <strong>Step 1:</strong> Identify forces
          </p>
          <p className="ml-4">
            Input Force (F_in) = {fIn} {forceUnit}
          </p>
          <p className="ml-4">
            Output Force (F_out) = {fOut} {forceUnit}
          </p>
          <p>
            <strong>Step 2:</strong> Apply formula
          </p>
          <p className="ml-4">MA = F_out ÷ F_in</p>
          <p className="ml-4">
            MA = {fOut} ÷ {fIn} = {result.ma}
          </p>
          {result.efficiency < 100 && (
            <>
              <p>
                <strong>Step 3:</strong> Apply efficiency
              </p>
              <p className="ml-4">Effective MA = MA × (Efficiency / 100)</p>
              <p className="ml-4">
                Effective MA = {result.ma} × ({result.efficiency} / 100) = {result.effectiveMA}
              </p>
            </>
          )}
        </div>
      )
    } else {
      const dIn = Number.parseFloat(inputDistance)
      const dOut = Number.parseFloat(outputDistance)
      return (
        <div className="space-y-2 text-sm">
          <p>
            <strong>Step 1:</strong> Identify distances
          </p>
          <p className="ml-4">
            Input Distance (d_in) = {dIn} {distanceUnit}
          </p>
          <p className="ml-4">
            Output Distance (d_out) = {dOut} {distanceUnit}
          </p>
          <p>
            <strong>Step 2:</strong> Apply formula
          </p>
          <p className="ml-4">MA = d_in ÷ d_out</p>
          <p className="ml-4">
            MA = {dIn} ÷ {dOut} = {result.ma}
          </p>
          {result.efficiency < 100 && (
            <>
              <p>
                <strong>Step 3:</strong> Apply efficiency
              </p>
              <p className="ml-4">Effective MA = MA × (Efficiency / 100)</p>
              <p className="ml-4">
                Effective MA = {result.ma} × ({result.efficiency} / 100) = {result.effectiveMA}
              </p>
            </>
          )}
        </div>
      )
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Cog className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Mechanical Advantage Calculator</CardTitle>
                    <CardDescription>Calculate force amplification in mechanical systems</CardDescription>
                  </div>
                </div>

                {/* Method Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Method</span>
                  <button
                    onClick={() => {
                      setMethod(method === "force" ? "distance" : "force")
                      setResult(null)
                      setError("")
                    }}
                    className="relative inline-flex h-9 w-44 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        method === "distance" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "force" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Force
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "distance" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Distance
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Machine Type Selection */}
                <div className="space-y-2">
                  <Label>Machine Type (Optional)</Label>
                  <select
                    value={machineType}
                    onChange={(e) => setMachineType(e.target.value as MachineType)}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                  >
                    {machineTypes.map((type) => (
                      <option key={type.value} value={type.value}>
                        {type.label} - {type.description}
                      </option>
                    ))}
                  </select>
                </div>

                {method === "force" ? (
                  <>
                    {/* Force Unit Selection */}
                    <div className="space-y-2">
                      <Label>Force Unit</Label>
                      <select
                        value={forceUnit}
                        onChange={(e) => setForceUnit(e.target.value as ForceUnit)}
                        className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                      >
                        <option value="N">Newtons (N)</option>
                        <option value="kN">Kilonewtons (kN)</option>
                        <option value="lb">Pounds-force (lb)</option>
                        <option value="kgf">Kilogram-force (kgf)</option>
                      </select>
                    </div>

                    {/* Input Force */}
                    <div className="space-y-2">
                      <Label htmlFor="inputForce">Input Force (F_in) ({forceUnit})</Label>
                      <Input
                        id="inputForce"
                        type="number"
                        placeholder="Enter input/effort force"
                        value={inputForce}
                        onChange={(e) => setInputForce(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>

                    {/* Output Force */}
                    <div className="space-y-2">
                      <Label htmlFor="outputForce">Output Force (F_out) ({forceUnit})</Label>
                      <Input
                        id="outputForce"
                        type="number"
                        placeholder="Enter output/load force"
                        value={outputForce}
                        onChange={(e) => setOutputForce(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {/* Distance Unit Selection */}
                    <div className="space-y-2">
                      <Label>Distance Unit</Label>
                      <select
                        value={distanceUnit}
                        onChange={(e) => setDistanceUnit(e.target.value as DistanceUnit)}
                        className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                      >
                        <option value="m">Meters (m)</option>
                        <option value="cm">Centimeters (cm)</option>
                        <option value="mm">Millimeters (mm)</option>
                        <option value="ft">Feet (ft)</option>
                        <option value="in">Inches (in)</option>
                      </select>
                    </div>

                    {/* Input Distance */}
                    <div className="space-y-2">
                      <Label htmlFor="inputDistance">Input Distance (d_in) ({distanceUnit})</Label>
                      <Input
                        id="inputDistance"
                        type="number"
                        placeholder="Enter input/effort distance"
                        value={inputDistance}
                        onChange={(e) => setInputDistance(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>

                    {/* Output Distance */}
                    <div className="space-y-2">
                      <Label htmlFor="outputDistance">Output Distance (d_out) ({distanceUnit})</Label>
                      <Input
                        id="outputDistance"
                        type="number"
                        placeholder="Enter output/load distance"
                        value={outputDistance}
                        onChange={(e) => setOutputDistance(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Efficiency */}
                <div className="space-y-2">
                  <Label htmlFor="efficiency">Efficiency (%) - Optional</Label>
                  <Input
                    id="efficiency"
                    type="number"
                    placeholder="Enter efficiency (default: 100%)"
                    value={efficiency}
                    onChange={(e) => setEfficiency(e.target.value)}
                    min="0"
                    max="100"
                    step="1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateMA} className="w-full" size="lg">
                  Calculate Mechanical Advantage
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.bgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Mechanical Advantage</p>
                      <p className={`text-5xl font-bold ${result.color} mb-2`}>{result.ma}</p>
                      <p className={`text-lg font-semibold ${result.color}`}>{result.rating}</p>
                      {result.efficiency < 100 && (
                        <p className="text-sm text-muted-foreground mt-2">
                          Effective MA: <strong>{result.effectiveMA}</strong> at {result.efficiency}% efficiency
                        </p>
                      )}
                    </div>

                    {/* Step-by-Step Toggle */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      {showSteps ? "Hide" : "Show"} Step-by-Step Solution
                    </button>

                    {showSteps && (
                      <div className="mt-4 p-3 bg-white/50 rounded-lg border border-current/10">{renderSteps()}</div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">MA Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono text-sm font-semibold">Force-based: MA = F_out / F_in</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono text-sm font-semibold">Distance-based: MA = d_in / d_out</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="font-mono text-sm font-semibold">Effective MA = MA × Efficiency</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Simple Machines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Lever</span>
                      <span className="text-muted-foreground">effort arm / load arm</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Pulley</span>
                      <span className="text-muted-foreground">number of ropes</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Inclined Plane</span>
                      <span className="text-muted-foreground">length / height</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Wheel & Axle</span>
                      <span className="text-muted-foreground">wheel R / axle R</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted/50 rounded">
                      <span>Screw</span>
                      <span className="text-muted-foreground">2πr / pitch</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">MA Ratings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Disadvantage</span>
                      <span className="text-sm text-red-600">{"< 1"}</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Neutral</span>
                      <span className="text-sm text-yellow-600">= 1</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Low Advantage</span>
                      <span className="text-sm text-blue-600">1 – 2</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Good Advantage</span>
                      <span className="text-sm text-green-600">2 – 5</span>
                    </div>
                    <div className="flex items-center justify-between p-2 rounded bg-emerald-50 border border-emerald-200">
                      <span className="font-medium text-emerald-700">High Advantage</span>
                      <span className="text-sm text-emerald-600">{"> 5"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Mechanical Advantage?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mechanical advantage (MA) is a measure of the force amplification achieved by using a tool, mechanical
                  device, or machine system. It is defined as the ratio of output force to input force, or equivalently,
                  the ratio of input distance to output distance. A mechanical advantage greater than 1 means the
                  machine multiplies the input force, making it easier to move heavy loads.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The concept is fundamental to understanding simple machines like levers, pulleys, inclined planes,
                  wedges, screws, and wheel-and-axle systems. Engineers and physicists use mechanical advantage
                  calculations to design efficient mechanical systems, from simple hand tools to complex industrial
                  machinery.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Cog className="h-5 w-5 text-primary" />
                  <CardTitle>Ideal vs. Actual Mechanical Advantage</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The <strong>Ideal Mechanical Advantage (IMA)</strong> is calculated using the distance-based formula
                  (d_in / d_out) and assumes no energy losses due to friction or other factors. The{" "}
                  <strong>Actual Mechanical Advantage (AMA)</strong> is calculated using the force-based formula (F_out
                  / F_in) and reflects real-world performance.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The efficiency of a machine is defined as the ratio of AMA to IMA, expressed as a percentage. Real
                  machines always have efficiency less than 100% due to friction, deformation, and other energy losses.
                  When designing mechanical systems, engineers must account for these losses to ensure adequate
                  performance.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <Info className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-yellow-800">
                    <strong>Disclaimer:</strong> Mechanical advantage calculations are estimates. Actual performance may
                    vary due to friction, material properties, and real-world conditions. Consult engineering references
                    for precise measurements.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
