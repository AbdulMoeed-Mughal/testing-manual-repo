"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Ruler, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "m" | "ft"
type ConcreteGrade = "M10" | "M15" | "M20" | "M25" | "M30" | "M35" | "M40"
type StressType = "tension" | "compression"
type BarType = "plain" | "deformed"

interface LapLengthResult {
  lapLength: number
  factor: number
  notes: string[]
}

export function LapLengthCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("m")
  const [barDiameter, setBarDiameter] = useState("")
  const [concreteGrade, setConcreteGrade] = useState<ConcreteGrade>("M20")
  const [stressType, setStressType] = useState<StressType>("tension")
  const [barType, setBarType] = useState<BarType>("deformed")
  const [safetyFactor, setSafetyFactor] = useState("")
  const [result, setResult] = useState<LapLengthResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const getLapFactor = (grade: ConcreteGrade, stress: StressType, type: BarType): number => {
    if (stress === "tension") {
      if (type === "plain") {
        // Plain bars in tension
        return grade === "M10" || grade === "M15" ? 58 : grade === "M20" ? 50 : 40
      } else {
        // Deformed bars in tension
        return grade === "M10" || grade === "M15" ? 50 : grade === "M20" ? 45 : 40
      }
    } else {
      // Compression
      return grade === "M10" || grade === "M15" ? 35 : grade === "M20" ? 30 : 25
    }
  }

  const calculateLapLength = () => {
    setError("")
    setResult(null)

    const diameterNum = Number.parseFloat(barDiameter)

    if (isNaN(diameterNum) || diameterNum <= 0) {
      setError("Please enter a valid bar diameter greater than 0")
      return
    }

    // Get lap length factor based on conditions
    const baseFactor = getLapFactor(concreteGrade, stressType, barType)

    // Apply safety factor if provided
    let finalFactor = baseFactor
    if (safetyFactor && !isNaN(Number.parseFloat(safetyFactor))) {
      const sfNum = Number.parseFloat(safetyFactor)
      if (sfNum < 1) {
        setError("Safety factor must be at least 1.0")
        return
      }
      finalFactor = baseFactor * sfNum
    }

    // Calculate lap length in mm
    const lapLengthMm = diameterNum * finalFactor

    // Convert to desired unit
    let lapLength: number
    if (unitSystem === "m") {
      lapLength = lapLengthMm / 1000
    } else {
      lapLength = lapLengthMm / 304.8 // Convert mm to ft
    }

    // Generate notes
    const notes: string[] = []
    
    if (stressType === "tension") {
      notes.push("Lap should be staggered to avoid all bars lapping at the same location")
      notes.push("Provide adequate cover and spacing between lapped bars")
    } else {
      notes.push("Compression laps require shorter lengths than tension laps")
      notes.push("Ensure proper confinement with ties or stirrups")
    }

    if (barType === "deformed") {
      notes.push("Deformed bars provide better bond strength than plain bars")
    } else {
      notes.push("Plain bars require hooks at lap ends for better anchorage")
    }

    setResult({
      lapLength,
      factor: finalFactor,
      notes,
    })
  }

  const handleReset = () => {
    setBarDiameter("")
    setConcreteGrade("M20")
    setStressType("tension")
    setBarType("deformed")
    setSafetyFactor("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Lap Length: ${result.lapLength.toFixed(3)} ${unitSystem}\nFactor: ${result.factor.toFixed(1)}×d\nBar: ${barDiameter}mm ${barType}\nGrade: ${concreteGrade} (${stressType})`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Lap Length Result",
          text: `Lap Length calculated using CalcHub: ${result.lapLength.toFixed(3)} ${unitSystem} for ${barDiameter}mm ${barType} bar in ${concreteGrade} concrete`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "m" ? "ft" : "m"))
    setResult(null)
    setError("")
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Ruler className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Lap Length Calculator</CardTitle>
                    <CardDescription>Calculate reinforcement lap length for RCC</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-32 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "ft" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "m" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Meters
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "ft" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Feet
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Bar Diameter */}
                <div className="space-y-2">
                  <Label htmlFor="barDiameter">Bar Diameter (mm)</Label>
                  <Input
                    id="barDiameter"
                    type="number"
                    placeholder="e.g., 12, 16, 20"
                    value={barDiameter}
                    onChange={(e) => setBarDiameter(e.target.value)}
                    min="0"
                    step="1"
                  />
                </div>

                {/* Concrete Grade */}
                <div className="space-y-2">
                  <Label htmlFor="concreteGrade">Concrete Grade</Label>
                  <Select value={concreteGrade} onValueChange={(value: ConcreteGrade) => setConcreteGrade(value)}>
                    <SelectTrigger id="concreteGrade">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M10">M10 (10 MPa)</SelectItem>
                      <SelectItem value="M15">M15 (15 MPa)</SelectItem>
                      <SelectItem value="M20">M20 (20 MPa)</SelectItem>
                      <SelectItem value="M25">M25 (25 MPa)</SelectItem>
                      <SelectItem value="M30">M30 (30 MPa)</SelectItem>
                      <SelectItem value="M35">M35 (35 MPa)</SelectItem>
                      <SelectItem value="M40">M40 (40 MPa)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Stress Type */}
                <div className="space-y-2">
                  <Label htmlFor="stressType">Type of Stress</Label>
                  <Select value={stressType} onValueChange={(value: StressType) => setStressType(value)}>
                    <SelectTrigger id="stressType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tension">Tension</SelectItem>
                      <SelectItem value="compression">Compression</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Bar Type */}
                <div className="space-y-2">
                  <Label htmlFor="barType">Bar Type</Label>
                  <Select value={barType} onValueChange={(value: BarType) => setBarType(value)}>
                    <SelectTrigger id="barType">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="deformed">Deformed (HYSD)</SelectItem>
                      <SelectItem value="plain">Plain (Mild Steel)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Safety Factor (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="safetyFactor">
                    Safety Factor <span className="text-muted-foreground">(Optional)</span>
                  </Label>
                  <Input
                    id="safetyFactor"
                    type="number"
                    placeholder="e.g., 1.0, 1.2, 1.5"
                    value={safetyFactor}
                    onChange={(e) => setSafetyFactor(e.target.value)}
                    min="1"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-start gap-2">
                    <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateLapLength} className="w-full" size="lg">
                  Calculate Lap Length
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="space-y-3">
                      <div className="text-center pb-3 border-b border-amber-200">
                        <p className="text-sm text-muted-foreground mb-1">Required Lap Length</p>
                        <p className="text-4xl font-bold text-amber-600">{result.lapLength.toFixed(3)}</p>
                        <p className="text-sm font-medium text-amber-700">{unitSystem}</p>
                      </div>

                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Factor:</span>
                          <span className="font-semibold text-amber-700">{result.factor.toFixed(1)}×d</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Bar Diameter:</span>
                          <span className="font-semibold text-amber-700">{barDiameter} mm</span>
                        </div>
                      </div>

                      {/* Notes */}
                      <div className="pt-3 border-t border-amber-200 space-y-2">
                        <p className="text-xs font-semibold text-amber-900 uppercase">Important Notes:</p>
                        {result.notes.map((note, index) => (
                          <p key={index} className="text-xs text-amber-800 leading-relaxed">
                            • {note}
                          </p>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Lap Length Factors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="font-semibold text-amber-900 mb-1">Tension (Deformed)</div>
                      <div className="text-amber-700">40-50×d depending on grade</div>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="font-semibold text-amber-900 mb-1">Tension (Plain)</div>
                      <div className="text-amber-700">40-58×d depending on grade</div>
                    </div>
                    <div className="p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div className="font-semibold text-amber-900 mb-1">Compression</div>
                      <div className="text-amber-700">25-35×d depending on grade</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Concrete Grades</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong className="text-foreground">M10-M15:</strong> Non-structural, lean concrete
                  </p>
                  <p>
                    <strong className="text-foreground">M20:</strong> Standard grade for RCC structures
                  </p>
                  <p>
                    <strong className="text-foreground">M25-M30:</strong> Structural members, high-rise
                  </p>
                  <p>
                    <strong className="text-foreground">M35-M40:</strong> Heavy-duty structures, bridges
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-12 space-y-8">
            {/* What is Lap Length */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Lap Length in Reinforcement?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Lap length refers to the overlapping length required when two reinforcement bars are joined together to
                  transfer tensile or compressive forces from one bar to another through bond with the surrounding
                  concrete. Since reinforcement bars come in standard lengths (typically 12 meters), lapping becomes
                  necessary when longer continuous reinforcement is required in structural elements such as beams, columns,
                  slabs, and foundations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The lap length must be sufficient to develop the full strength of the bar and ensure proper load
                  transfer. Inadequate lap length can lead to structural failure, as the bars may slip within the
                  concrete, unable to carry the intended loads. The required lap length depends on several factors
                  including the type and diameter of reinforcement bars, concrete grade, type of stress (tension or
                  compression), and the presence of hooks or mechanical anchorages.
                </p>
              </CardContent>
            </Card>

            {/* How Lap Length is Calculated */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How is Lap Length Calculated?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Lap length is calculated as a multiple of the bar diameter (d), with the multiplier varying based on
                  concrete grade, stress type, and bar type. For deformed bars in tension with M20 concrete, the typical
                  lap length is 45-50 times the diameter. For example, a 16mm bar would require a lap length of 720-800mm.
                  Higher concrete grades allow for shorter lap lengths due to improved bond strength, while lower grades
                  require longer laps.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Compression laps are generally 25-35% shorter than tension laps because compressive forces help keep the
                  bars in contact with concrete, enhancing bond. Plain bars require longer lap lengths (about 20-30%
                  more) compared to deformed bars because they lack the mechanical interlock provided by ribs on deformed
                  bars. Design codes like IS 456, ACI 318, and BS 8110 provide detailed guidelines for calculating lap
                  lengths under various conditions, including provisions for different bar diameters, concrete strengths,
                  and loading scenarios.
                </p>
              </CardContent>
            </Card>

            {/* Best Practices */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Ruler className="h-5 w-5 text-primary" />
                  <CardTitle>Lap Length Best Practices</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  When detailing lap splices, it's important to stagger the laps so that not all bars in a section are
                  lapped at the same location. This prevents a potential weak plane in the structure. Typically, only 50%
                  of bars should be lapped at any given section. The center-to-center distance between adjacent lapped
                  bars should be at least 1.5 times the lap length to ensure proper stress distribution.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Laps should preferably be located in areas of low stress, away from maximum bending moment zones. For
                  beams, laps in bottom reinforcement should be near supports, while top bar laps should be near
                  mid-span. Adequate concrete cover must be maintained around lapped bars, and the spacing between bars
                  should allow proper concrete placement and compaction. For critical structures or seismic zones,
                  mechanical couplers or welded splices may be preferred over conventional lapping to ensure better
                  performance and reliability.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <p className="font-semibold text-amber-900">Important Note</p>
                    <p className="text-sm text-amber-800 leading-relaxed">
                      Lap length calculations provided by this calculator are indicative and based on general code
                      provisions. The final lap length must comply with structural design codes, project specifications,
                      and site conditions. Always consult with a qualified structural engineer and refer to relevant
                      standards (IS 456, ACI 318, BS 8110, etc.) for specific requirements. Special conditions such as
                      seismic zones, corrosive environments, or high-stress locations may require modified lap lengths.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
