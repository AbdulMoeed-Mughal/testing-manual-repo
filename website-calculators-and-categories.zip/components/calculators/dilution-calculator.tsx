"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  FlaskConical,
  Info,
  AlertTriangle,
  Beaker,
  Droplets,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "final-concentration" | "initial-concentration" | "final-volume" | "initial-volume"
type VolumeUnit = "L" | "mL"
type ConcentrationUnit = "M" | "mM"

interface DilutionResult {
  c1: number
  c2: number
  v1: number
  v2: number
  calculatedValue: number
  calculatedLabel: string
  unit: string
  steps: string[]
}

export function DilutionCalculator() {
  const [mode, setMode] = useState<CalculationMode>("final-concentration")
  const [c1, setC1] = useState("")
  const [c2, setC2] = useState("")
  const [v1, setV1] = useState("")
  const [v2, setV2] = useState("")
  const [c1Unit, setC1Unit] = useState<ConcentrationUnit>("M")
  const [c2Unit, setC2Unit] = useState<ConcentrationUnit>("M")
  const [v1Unit, setV1Unit] = useState<VolumeUnit>("mL")
  const [v2Unit, setV2Unit] = useState<VolumeUnit>("mL")
  const [result, setResult] = useState<DilutionResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(true)

  const convertToBase = (value: number, unit: VolumeUnit | ConcentrationUnit): number => {
    if (unit === "mL") return value / 1000 // mL to L
    if (unit === "mM") return value / 1000 // mM to M
    return value
  }

  const formatResult = (value: number, unit: VolumeUnit | ConcentrationUnit): number => {
    if (unit === "mL") return value * 1000
    if (unit === "mM") return value * 1000
    return value
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const steps: string[] = []
    let calculatedValue: number
    let calculatedLabel: string
    let resultUnit: string

    // Parse inputs based on mode
    const c1Val = c1 ? convertToBase(Number.parseFloat(c1), c1Unit) : null
    const c2Val = c2 ? convertToBase(Number.parseFloat(c2), c2Unit) : null
    const v1Val = v1 ? convertToBase(Number.parseFloat(v1), v1Unit) : null
    const v2Val = v2 ? convertToBase(Number.parseFloat(v2), v2Unit) : null

    steps.push("Using the dilution equation: C₁ × V₁ = C₂ × V₂")

    switch (mode) {
      case "final-concentration":
        if (c1Val === null || isNaN(c1Val) || c1Val <= 0) {
          setError("Please enter a valid initial concentration (C₁) greater than 0")
          return
        }
        if (v1Val === null || isNaN(v1Val) || v1Val <= 0) {
          setError("Please enter a valid initial volume (V₁) greater than 0")
          return
        }
        if (v2Val === null || isNaN(v2Val) || v2Val <= 0) {
          setError("Please enter a valid final volume (V₂) greater than 0")
          return
        }
        if (v2Val < v1Val) {
          setError("Final volume (V₂) must be greater than or equal to initial volume (V₁)")
          return
        }

        calculatedValue = (c1Val * v1Val) / v2Val
        calculatedLabel = "Final Concentration (C₂)"
        resultUnit = c2Unit

        steps.push(`Rearranging for C₂: C₂ = (C₁ × V₁) / V₂`)
        steps.push(`C₂ = (${c1} ${c1Unit} × ${v1} ${v1Unit}) / ${v2} ${v2Unit}`)
        steps.push(`C₂ = ${formatResult(calculatedValue, c2Unit).toFixed(6)} ${c2Unit}`)
        break

      case "initial-concentration":
        if (c2Val === null || isNaN(c2Val) || c2Val <= 0) {
          setError("Please enter a valid final concentration (C₂) greater than 0")
          return
        }
        if (v1Val === null || isNaN(v1Val) || v1Val <= 0) {
          setError("Please enter a valid initial volume (V₁) greater than 0")
          return
        }
        if (v2Val === null || isNaN(v2Val) || v2Val <= 0) {
          setError("Please enter a valid final volume (V₂) greater than 0")
          return
        }

        calculatedValue = (c2Val * v2Val) / v1Val
        calculatedLabel = "Initial Concentration (C₁)"
        resultUnit = c1Unit

        steps.push(`Rearranging for C₁: C₁ = (C₂ × V₂) / V₁`)
        steps.push(`C₁ = (${c2} ${c2Unit} × ${v2} ${v2Unit}) / ${v1} ${v1Unit}`)
        steps.push(`C₁ = ${formatResult(calculatedValue, c1Unit).toFixed(6)} ${c1Unit}`)
        break

      case "final-volume":
        if (c1Val === null || isNaN(c1Val) || c1Val <= 0) {
          setError("Please enter a valid initial concentration (C₁) greater than 0")
          return
        }
        if (c2Val === null || isNaN(c2Val) || c2Val <= 0) {
          setError("Please enter a valid final concentration (C₂) greater than 0")
          return
        }
        if (v1Val === null || isNaN(v1Val) || v1Val <= 0) {
          setError("Please enter a valid initial volume (V₁) greater than 0")
          return
        }
        if (c2Val > c1Val) {
          setError("Final concentration (C₂) cannot be greater than initial concentration (C₁) in a dilution")
          return
        }

        calculatedValue = (c1Val * v1Val) / c2Val
        calculatedLabel = "Final Volume (V₂)"
        resultUnit = v2Unit

        steps.push(`Rearranging for V₂: V₂ = (C₁ × V₁) / C₂`)
        steps.push(`V₂ = (${c1} ${c1Unit} × ${v1} ${v1Unit}) / ${c2} ${c2Unit}`)
        steps.push(`V₂ = ${formatResult(calculatedValue, v2Unit).toFixed(4)} ${v2Unit}`)
        break

      case "initial-volume":
        if (c1Val === null || isNaN(c1Val) || c1Val <= 0) {
          setError("Please enter a valid initial concentration (C₁) greater than 0")
          return
        }
        if (c2Val === null || isNaN(c2Val) || c2Val <= 0) {
          setError("Please enter a valid final concentration (C₂) greater than 0")
          return
        }
        if (v2Val === null || isNaN(v2Val) || v2Val <= 0) {
          setError("Please enter a valid final volume (V₂) greater than 0")
          return
        }
        if (c2Val > c1Val) {
          setError("Final concentration (C₂) cannot be greater than initial concentration (C₁) in a dilution")
          return
        }

        calculatedValue = (c2Val * v2Val) / c1Val
        calculatedLabel = "Initial Volume (V₁)"
        resultUnit = v1Unit

        steps.push(`Rearranging for V₁: V₁ = (C₂ × V₂) / C₁`)
        steps.push(`V₁ = (${c2} ${c2Unit} × ${v2} ${v2Unit}) / ${c1} ${c1Unit}`)
        steps.push(`V₁ = ${formatResult(calculatedValue, v1Unit).toFixed(4)} ${v1Unit}`)
        break

      default:
        return
    }

    // Calculate solvent to add
    if (mode === "final-volume" || mode === "initial-volume") {
      const v1Final = mode === "initial-volume" ? calculatedValue : v1Val!
      const v2Final = mode === "final-volume" ? calculatedValue : v2Val!
      const solventToAdd = v2Final - v1Final
      steps.push(``)
      steps.push(`Solvent to add: V₂ - V₁ = ${formatResult(solventToAdd, v2Unit).toFixed(4)} ${v2Unit}`)
    }

    setResult({
      c1: c1Val || 0,
      c2: c2Val || 0,
      v1: v1Val || 0,
      v2: v2Val || 0,
      calculatedValue: formatResult(calculatedValue, resultUnit as VolumeUnit | ConcentrationUnit),
      calculatedLabel,
      unit: resultUnit,
      steps,
    })
  }

  const handleReset = () => {
    setC1("")
    setC2("")
    setV1("")
    setV2("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `${result.calculatedLabel}: ${result.calculatedValue.toFixed(4)} ${result.unit}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Dilution Calculator Result",
          text: `I calculated ${result.calculatedLabel}: ${result.calculatedValue.toFixed(4)} ${result.unit} using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const modeOptions = [
    { value: "final-concentration", label: "Final Concentration (C₂)", description: "From C₁, V₁, V₂" },
    { value: "initial-concentration", label: "Initial Concentration (C₁)", description: "From C₂, V₁, V₂" },
    { value: "final-volume", label: "Final Volume (V₂)", description: "From C₁, C₂, V₁" },
    { value: "initial-volume", label: "Initial Volume (V₁)", description: "From C₁, C₂, V₂" },
  ]

  const getRequiredInputs = () => {
    switch (mode) {
      case "final-concentration":
        return { c1: true, c2: false, v1: true, v2: true }
      case "initial-concentration":
        return { c1: false, c2: true, v1: true, v2: true }
      case "final-volume":
        return { c1: true, c2: true, v1: true, v2: false }
      case "initial-volume":
        return { c1: true, c2: true, v1: false, v2: true }
    }
  }

  const required = getRequiredInputs()

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/chemistry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Chemistry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">
                    <FlaskConical className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Dilution Calculator</CardTitle>
                    <CardDescription>Calculate using C₁V₁ = C₂V₂</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Mode Selection */}
                <div className="space-y-2">
                  <Label>Calculate</Label>
                  <Select
                    value={mode}
                    onValueChange={(value: CalculationMode) => {
                      setMode(value)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {modeOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex flex-col">
                            <span>{option.label}</span>
                            <span className="text-xs text-muted-foreground">{option.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* C1 Input */}
                {required.c1 && (
                  <div className="space-y-2">
                    <Label htmlFor="c1">Initial Concentration (C₁)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="c1"
                        type="number"
                        placeholder="Enter concentration"
                        value={c1}
                        onChange={(e) => setC1(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={c1Unit} onValueChange={(value: ConcentrationUnit) => setC1Unit(value)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="M">M</SelectItem>
                          <SelectItem value="mM">mM</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* V1 Input */}
                {required.v1 && (
                  <div className="space-y-2">
                    <Label htmlFor="v1">Initial Volume (V₁)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="v1"
                        type="number"
                        placeholder="Enter volume"
                        value={v1}
                        onChange={(e) => setV1(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={v1Unit} onValueChange={(value: VolumeUnit) => setV1Unit(value)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="L">L</SelectItem>
                          <SelectItem value="mL">mL</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* C2 Input */}
                {required.c2 && (
                  <div className="space-y-2">
                    <Label htmlFor="c2">Final Concentration (C₂)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="c2"
                        type="number"
                        placeholder="Enter concentration"
                        value={c2}
                        onChange={(e) => setC2(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={c2Unit} onValueChange={(value: ConcentrationUnit) => setC2Unit(value)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="M">M</SelectItem>
                          <SelectItem value="mM">mM</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* V2 Input */}
                {required.v2 && (
                  <div className="space-y-2">
                    <Label htmlFor="v2">Final Volume (V₂)</Label>
                    <div className="flex gap-2">
                      <Input
                        id="v2"
                        type="number"
                        placeholder="Enter volume"
                        value={v2}
                        onChange={(e) => setV2(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={v2Unit} onValueChange={(value: VolumeUnit) => setV2Unit(value)}>
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="L">L</SelectItem>
                          <SelectItem value="mL">mL</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-purple-50 border-purple-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">{result.calculatedLabel}</p>
                      <p className="text-4xl font-bold text-purple-600 mb-1">{result.calculatedValue.toFixed(4)}</p>
                      <p className="text-lg font-medium text-purple-500">{result.unit}</p>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-purple-100">
                        <p className="text-sm font-medium text-purple-700 mb-2">Step-by-step Solution:</p>
                        <div className="space-y-1">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-sm text-muted-foreground font-mono">
                              {step}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dilution Equation</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-4 bg-purple-50 rounded-lg border border-purple-200 text-center">
                    <p className="text-2xl font-bold text-purple-700 font-mono">C₁V₁ = C₂V₂</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="p-2 bg-muted rounded-lg">
                      <p className="font-medium">C₁</p>
                      <p className="text-muted-foreground">Initial concentration</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg">
                      <p className="font-medium">V₁</p>
                      <p className="text-muted-foreground">Initial volume</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg">
                      <p className="font-medium">C₂</p>
                      <p className="text-muted-foreground">Final concentration</p>
                    </div>
                    <div className="p-2 bg-muted rounded-lg">
                      <p className="font-medium">V₂</p>
                      <p className="text-muted-foreground">Final volume</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula Rearrangements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p>
                      <strong>C₂</strong> = (C₁ × V₁) / V₂
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p>
                      <strong>C₁</strong> = (C₂ × V₂) / V₁
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p>
                      <strong>V₂</strong> = (C₁ × V₁) / C₂
                    </p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg font-mono text-sm">
                    <p>
                      <strong>V₁</strong> = (C₂ × V₂) / C₁
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Lab Safety Disclaimer</p>
                      <p>
                        Results assume ideal mixing and accurate laboratory measurements. Always verify calculations and
                        follow proper laboratory safety protocols when handling chemicals.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Dilution?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dilution is the process of decreasing the concentration of a solute in a solution, usually by adding
                  more solvent. In chemistry and biology laboratories, dilution is a fundamental technique used to
                  prepare solutions of desired concentrations from stock solutions. The process involves adding a
                  measured amount of solvent (typically water) to a known volume of a more concentrated solution.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The key principle behind dilution is that the total amount of solute remains constant before and after
                  dilution. This is expressed mathematically by the dilution equation: C₁V₁ = C₂V₂, where C represents
                  concentration and V represents volume. The subscripts 1 and 2 refer to the initial (concentrated) and
                  final (diluted) states, respectively.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Beaker className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Dilution Equation</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The dilution equation C₁V₁ = C₂V₂ is derived from the conservation of mass principle. The product of
                  concentration and volume gives the total amount of solute (in moles if concentration is in molarity).
                  Since no solute is added or removed during dilution, this quantity must remain constant.
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Key Variables</h4>
                    <ul className="text-purple-700 text-sm space-y-1">
                      <li>
                        <strong>C₁ (Initial Concentration):</strong> The concentration of the stock or starting solution
                      </li>
                      <li>
                        <strong>V₁ (Initial Volume):</strong> The volume of stock solution used
                      </li>
                      <li>
                        <strong>C₂ (Final Concentration):</strong> The desired concentration after dilution
                      </li>
                      <li>
                        <strong>V₂ (Final Volume):</strong> The total volume of the diluted solution
                      </li>
                    </ul>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Important Note</h4>
                    <p className="text-blue-700 text-sm">
                      The amount of solvent to add equals V₂ - V₁, not V₂. A common mistake is to add V₂ amount of
                      solvent instead of adding enough solvent to bring the total volume to V₂.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Droplets className="h-5 w-5 text-primary" />
                  <CardTitle>Practical Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Dilution calculations are essential in numerous scientific and everyday applications:
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Laboratory Research</h4>
                    <p className="text-green-700 text-sm">
                      Preparing reagents, buffer solutions, and media at specific concentrations for experiments.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Medical & Clinical</h4>
                    <p className="text-blue-700 text-sm">
                      Preparing medications, IV solutions, and diagnostic reagents at precise concentrations.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Industrial Applications</h4>
                    <p className="text-amber-700 text-sm">
                      Manufacturing cleaning products, food processing, and water treatment facilities.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Environmental Testing</h4>
                    <p className="text-purple-700 text-sm">
                      Preparing standard solutions for calibration and quality control in environmental analysis.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <FlaskConical className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Dilutions</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">1. Use Appropriate Glassware</h4>
                    <p className="text-muted-foreground text-sm">
                      Use volumetric flasks for final volume measurements and graduated pipettes or micropipettes for
                      transferring precise volumes of stock solution.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">2. Add Solvent to Solute</h4>
                    <p className="text-muted-foreground text-sm">
                      When diluting concentrated acids, always add acid to water, never water to acid. This prevents
                      dangerous exothermic reactions.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">3. Mix Thoroughly</h4>
                    <p className="text-muted-foreground text-sm">
                      Ensure complete mixing after adding solvent to achieve a uniform concentration throughout the
                      solution.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">4. Account for Temperature</h4>
                    <p className="text-muted-foreground text-sm">
                      Volume measurements should be made at a consistent temperature, as liquids expand and contract
                      with temperature changes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
