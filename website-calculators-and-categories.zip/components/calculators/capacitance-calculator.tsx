"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type CalculationMethod = "basic" | "parallel-plate"
type CapacitanceUnit = "F" | "mF" | "uF" | "nF" | "pF"

interface CapacitanceResult {
  capacitance: number
  displayCapacitance: string
  unit: string
  method: string
  steps: string[]
}

const EPSILON_0 = 8.854187817e-12 // Permittivity of free space (F/m)

const DIELECTRIC_MATERIALS: { name: string; value: number }[] = [
  { name: "Vacuum", value: 1.0 },
  { name: "Air", value: 1.0006 },
  { name: "Paper", value: 3.7 },
  { name: "Glass", value: 4.7 },
  { name: "Mica", value: 6.0 },
  { name: "Porcelain", value: 6.5 },
  { name: "Rubber", value: 7.0 },
  { name: "Bakelite", value: 4.9 },
  { name: "Polyethylene", value: 2.25 },
  { name: "Polystyrene", value: 2.6 },
  { name: "Ceramic (Type I)", value: 10 },
  { name: "Ceramic (Type II)", value: 1000 },
  { name: "Water (distilled)", value: 80 },
  { name: "Custom", value: 0 },
]

const UNIT_CONVERSIONS: Record<CapacitanceUnit, { multiplier: number; label: string }> = {
  F: { multiplier: 1, label: "Farads (F)" },
  mF: { multiplier: 1e-3, label: "Millifarads (mF)" },
  uF: { multiplier: 1e-6, label: "Microfarads (µF)" },
  nF: { multiplier: 1e-9, label: "Nanofarads (nF)" },
  pF: { multiplier: 1e-12, label: "Picofarads (pF)" },
}

export function CapacitanceCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("basic")
  const [charge, setCharge] = useState("")
  const [voltage, setVoltage] = useState("")
  const [plateArea, setPlateArea] = useState("")
  const [separation, setSeparation] = useState("")
  const [dielectricMaterial, setDielectricMaterial] = useState("Vacuum")
  const [customDielectric, setCustomDielectric] = useState("")
  const [outputUnit, setOutputUnit] = useState<CapacitanceUnit>("uF")
  const [result, setResult] = useState<CapacitanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const getDielectricConstant = (): number => {
    if (dielectricMaterial === "Custom") {
      return Number.parseFloat(customDielectric) || 1
    }
    const material = DIELECTRIC_MATERIALS.find((m) => m.name === dielectricMaterial)
    return material?.value || 1
  }

  const formatCapacitance = (farads: number, unit: CapacitanceUnit): string => {
    const converted = farads / UNIT_CONVERSIONS[unit].multiplier
    if (Math.abs(converted) >= 1000000) {
      return converted.toExponential(4)
    } else if (Math.abs(converted) >= 0.0001) {
      return converted.toPrecision(6)
    } else {
      return converted.toExponential(4)
    }
  }

  const calculateCapacitance = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    if (method === "basic") {
      const Q = Number.parseFloat(charge)
      const V = Number.parseFloat(voltage)

      if (isNaN(Q) || Q <= 0) {
        setError("Please enter a valid positive charge value")
        return
      }
      if (isNaN(V) || V <= 0) {
        setError("Please enter a valid positive voltage value")
        return
      }

      steps.push(`Given: Charge (Q) = ${Q} C, Voltage (V) = ${V} V`)
      steps.push(`Formula: C = Q / V`)
      steps.push(`Calculation: C = ${Q} / ${V}`)

      const capacitance = Q / V
      steps.push(`C = ${capacitance.toExponential(6)} F`)

      const displayCapacitance = formatCapacitance(capacitance, outputUnit)
      steps.push(`Converting to ${UNIT_CONVERSIONS[outputUnit].label}: ${displayCapacitance} ${outputUnit}`)

      setResult({
        capacitance,
        displayCapacitance,
        unit: outputUnit,
        method: "Basic Formula (C = Q/V)",
        steps,
      })
    } else {
      // Parallel plate capacitor
      const A = Number.parseFloat(plateArea)
      const d = Number.parseFloat(separation)
      const εr = getDielectricConstant()

      if (isNaN(A) || A <= 0) {
        setError("Please enter a valid positive plate area")
        return
      }
      if (isNaN(d) || d <= 0) {
        setError("Please enter a valid positive separation distance")
        return
      }
      if (isNaN(εr) || εr < 1) {
        setError("Please enter a valid dielectric constant (≥ 1)")
        return
      }

      // Convert area from cm² to m² and separation from mm to m
      const A_m2 = A * 1e-4
      const d_m = d * 1e-3

      steps.push(`Given: Plate Area (A) = ${A} cm² = ${A_m2.toExponential(4)} m²`)
      steps.push(`Separation Distance (d) = ${d} mm = ${d_m.toExponential(4)} m`)
      steps.push(`Dielectric Constant (εr) = ${εr} (${dielectricMaterial})`)
      steps.push(`Permittivity of Free Space (ε₀) = ${EPSILON_0.toExponential(4)} F/m`)
      steps.push(`Formula: C = (ε₀ × εr × A) / d`)
      steps.push(
        `Calculation: C = (${EPSILON_0.toExponential(4)} × ${εr} × ${A_m2.toExponential(4)}) / ${d_m.toExponential(4)}`,
      )

      const capacitance = (EPSILON_0 * εr * A_m2) / d_m
      steps.push(`C = ${capacitance.toExponential(6)} F`)

      const displayCapacitance = formatCapacitance(capacitance, outputUnit)
      steps.push(`Converting to ${UNIT_CONVERSIONS[outputUnit].label}: ${displayCapacitance} ${outputUnit}`)

      setResult({
        capacitance,
        displayCapacitance,
        unit: outputUnit,
        method: "Parallel Plate Formula",
        steps,
      })
    }
  }

  const handleReset = () => {
    setCharge("")
    setVoltage("")
    setPlateArea("")
    setSeparation("")
    setCustomDielectric("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Capacitance: ${result.displayCapacitance} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Capacitance Calculation",
          text: `Capacitance: ${result.displayCapacitance} ${result.unit} (${result.method})`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Capacitance Calculator</CardTitle>
                    <CardDescription>Calculate capacitance from charge/voltage or dimensions</CardDescription>
                  </div>
                </div>

                {/* Method Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Calculation Method</span>
                  <button
                    onClick={() => {
                      setMethod((prev) => (prev === "basic" ? "parallel-plate" : "basic"))
                      handleReset()
                    }}
                    className="relative inline-flex h-9 w-48 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        method === "parallel-plate" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "basic" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Basic (Q/V)
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        method === "parallel-plate" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Parallel Plate
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {method === "basic" ? (
                  <>
                    {/* Charge Input */}
                    <div className="space-y-2">
                      <Label htmlFor="charge">Charge (Q) in Coulombs</Label>
                      <Input
                        id="charge"
                        type="number"
                        placeholder="Enter charge in coulombs (e.g., 0.001)"
                        value={charge}
                        onChange={(e) => setCharge(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>

                    {/* Voltage Input */}
                    <div className="space-y-2">
                      <Label htmlFor="voltage">Voltage (V) in Volts</Label>
                      <Input
                        id="voltage"
                        type="number"
                        placeholder="Enter voltage in volts"
                        value={voltage}
                        onChange={(e) => setVoltage(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    {/* Plate Area Input */}
                    <div className="space-y-2">
                      <Label htmlFor="plateArea">Plate Area (A) in cm²</Label>
                      <Input
                        id="plateArea"
                        type="number"
                        placeholder="Enter plate area in cm²"
                        value={plateArea}
                        onChange={(e) => setPlateArea(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>

                    {/* Separation Distance Input */}
                    <div className="space-y-2">
                      <Label htmlFor="separation">Separation Distance (d) in mm</Label>
                      <Input
                        id="separation"
                        type="number"
                        placeholder="Enter separation in mm"
                        value={separation}
                        onChange={(e) => setSeparation(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>

                    {/* Dielectric Material Selection */}
                    <div className="space-y-2">
                      <Label htmlFor="dielectric">Dielectric Material</Label>
                      <Select value={dielectricMaterial} onValueChange={setDielectricMaterial}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select material" />
                        </SelectTrigger>
                        <SelectContent>
                          {DIELECTRIC_MATERIALS.map((material) => (
                            <SelectItem key={material.name} value={material.name}>
                              {material.name} {material.value > 0 ? `(εr = ${material.value})` : ""}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Custom Dielectric Input */}
                    {dielectricMaterial === "Custom" && (
                      <div className="space-y-2">
                        <Label htmlFor="customDielectric">Custom Dielectric Constant (εr)</Label>
                        <Input
                          id="customDielectric"
                          type="number"
                          placeholder="Enter dielectric constant (≥ 1)"
                          value={customDielectric}
                          onChange={(e) => setCustomDielectric(e.target.value)}
                          min="1"
                          step="any"
                        />
                      </div>
                    )}
                  </>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label htmlFor="outputUnit">Output Unit</Label>
                  <Select value={outputUnit} onValueChange={(v) => setOutputUnit(v as CapacitanceUnit)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select unit" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(UNIT_CONVERSIONS).map(([key, value]) => (
                        <SelectItem key={key} value={key}>
                          {value.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateCapacitance} className="w-full" size="lg">
                  Calculate Capacitance
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Capacitance</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">
                        {result.displayCapacitance} {result.unit}
                      </p>
                      <p className="text-sm text-muted-foreground">{result.method}</p>
                    </div>

                    {/* Step-by-Step Toggle */}
                    <Collapsible open={showSteps} onOpenChange={setShowSteps} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between">
                          <span>Step-by-Step Solution</span>
                          <ChevronDown className={`h-4 w-4 transition-transform ${showSteps ? "rotate-180" : ""}`} />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="p-3 bg-white rounded-lg border space-y-1 text-sm">
                          {result.steps.map((step, index) => (
                            <p key={index} className="text-muted-foreground">
                              {step}
                            </p>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Capacitance Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Basic Formula</p>
                    <p className="font-mono text-center text-lg">C = Q / V</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      C = Capacitance (F), Q = Charge (C), V = Voltage (V)
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="font-semibold text-foreground mb-2">Parallel Plate Formula</p>
                    <p className="font-mono text-center text-lg">C = (ε₀ × εr × A) / d</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      ε₀ = 8.854×10⁻¹² F/m, εr = Dielectric constant, A = Area (m²), d = Separation (m)
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dielectric Constants</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Vacuum / Air</span>
                      <span className="font-mono">~1.0</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Paper</span>
                      <span className="font-mono">3.7</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Glass</span>
                      <span className="font-mono">4.7</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Mica</span>
                      <span className="font-mono">6.0</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>Ceramic (Type II)</span>
                      <span className="font-mono">~1000</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Conversions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 F</span>
                      <span className="font-mono">10⁶ µF</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 µF</span>
                      <span className="font-mono">1000 nF</span>
                    </div>
                    <div className="flex justify-between p-2 bg-muted rounded">
                      <span>1 nF</span>
                      <span className="font-mono">1000 pF</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Capacitance?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Capacitance is a measure of a capacitor's ability to store electric charge. It is defined as the ratio
                  of the electric charge (Q) stored on each conductor to the potential difference (V) between them. The
                  SI unit of capacitance is the farad (F), named after the English physicist Michael Faraday. One farad
                  is defined as the capacitance that stores one coulomb of charge when one volt is applied across it.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In practical applications, capacitors typically have capacitances measured in microfarads (µF),
                  nanofarads (nF), or picofarads (pF), as one farad represents an extremely large capacitance.
                  Capacitors are essential components in electronic circuits, used for filtering, energy storage,
                  coupling, decoupling, and timing applications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Parallel Plate Capacitors</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A parallel plate capacitor consists of two conductive plates separated by a dielectric material. The
                  capacitance depends on the plate area, separation distance, and the dielectric constant of the
                  material between the plates. Increasing the plate area or dielectric constant increases capacitance,
                  while increasing the separation distance decreases it.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The dielectric material plays a crucial role in determining capacitance. Different materials have
                  different dielectric constants (relative permittivity), which represent how much better they are at
                  storing electric field energy compared to a vacuum. Common dielectric materials include air, paper,
                  glass, mica, and various ceramics, each offering different trade-offs between capacitance, breakdown
                  voltage, and stability.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-yellow-700 text-sm leading-relaxed">
                  Capacitance calculations are estimates based on ideal formulas. Actual capacitance may vary due to
                  manufacturing tolerances, temperature, or material properties. Consult component datasheets or an
                  electrical engineer for precise measurements.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
