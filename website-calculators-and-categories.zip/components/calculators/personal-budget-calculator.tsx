"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  Wallet,
  PiggyBank,
  Plus,
  Trash2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  TrendingUp,
  TrendingDown,
  Target,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface IncomeSource {
  id: string
  name: string
  amount: string
}

interface Expense {
  id: string
  name: string
  amount: string
  category: "fixed" | "variable"
}

interface BudgetResult {
  totalIncome: number
  totalExpenses: number
  fixedExpenses: number
  variableExpenses: number
  netSavings: number
  savingsRate: number
  expenseBreakdown: { category: string; amount: number; percentage: number }[]
  status: "surplus" | "balanced" | "deficit"
  projectedSavings: number
  savingsGoalMet: boolean
  suggestedAdjustments: string[]
}

export function PersonalBudgetCalculator() {
  const [incomes, setIncomes] = useState<IncomeSource[]>([{ id: "1", name: "", amount: "" }])
  const [expenses, setExpenses] = useState<Expense[]>([{ id: "1", name: "", amount: "", category: "fixed" }])
  const [savingsGoal, setSavingsGoal] = useState("")
  const [savingsGoalType, setSavingsGoalType] = useState<"percentage" | "amount">("percentage")
  const [timeframe, setTimeframe] = useState<"monthly" | "weekly">("monthly")
  const [result, setResult] = useState<BudgetResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const addIncome = () => {
    setIncomes([...incomes, { id: Date.now().toString(), name: "", amount: "" }])
  }

  const removeIncome = (id: string) => {
    if (incomes.length > 1) {
      setIncomes(incomes.filter((i) => i.id !== id))
    }
  }

  const updateIncome = (id: string, field: keyof IncomeSource, value: string) => {
    setIncomes(incomes.map((i) => (i.id === id ? { ...i, [field]: value } : i)))
  }

  const addExpense = () => {
    setExpenses([...expenses, { id: Date.now().toString(), name: "", amount: "", category: "fixed" }])
  }

  const removeExpense = (id: string) => {
    if (expenses.length > 1) {
      setExpenses(expenses.filter((e) => e.id !== id))
    }
  }

  const updateExpense = (id: string, field: keyof Expense, value: string) => {
    setExpenses(expenses.map((e) => (e.id === id ? { ...e, [field]: value } : e)))
  }

  const calculateBudget = () => {
    setError("")
    setResult(null)

    // Validate incomes
    const validIncomes = incomes.filter((i) => i.name && i.amount)
    if (validIncomes.length === 0) {
      setError("Please enter at least one income source")
      return
    }

    for (const income of validIncomes) {
      if (Number.parseFloat(income.amount) < 0) {
        setError("Income values must be non-negative")
        return
      }
    }

    // Validate expenses
    const validExpenses = expenses.filter((e) => e.name && e.amount)
    for (const expense of validExpenses) {
      if (Number.parseFloat(expense.amount) < 0) {
        setError("Expense values must be non-negative")
        return
      }
    }

    // Calculate totals
    const totalIncome = validIncomes.reduce((sum, i) => sum + Number.parseFloat(i.amount), 0)
    const fixedExpenses = validExpenses
      .filter((e) => e.category === "fixed")
      .reduce((sum, e) => sum + Number.parseFloat(e.amount), 0)
    const variableExpenses = validExpenses
      .filter((e) => e.category === "variable")
      .reduce((sum, e) => sum + Number.parseFloat(e.amount), 0)
    const totalExpenses = fixedExpenses + variableExpenses
    const netSavings = totalIncome - totalExpenses
    const savingsRate = totalIncome > 0 ? (netSavings / totalIncome) * 100 : 0

    // Determine savings goal
    let goalAmount = 0
    if (savingsGoal) {
      if (savingsGoalType === "percentage") {
        goalAmount = (Number.parseFloat(savingsGoal) / 100) * totalIncome
      } else {
        goalAmount = Number.parseFloat(savingsGoal)
      }
    }

    // Check if savings goal exceeds net income
    if (goalAmount > netSavings && savingsGoal) {
      // Don't error, just note it in suggestions
    }

    // Calculate expense breakdown
    const categories = [
      { category: "Fixed Expenses", amount: fixedExpenses },
      { category: "Variable Expenses", amount: variableExpenses },
      { category: "Savings", amount: Math.max(0, netSavings) },
    ]
    const expenseBreakdown = categories.map((c) => ({
      ...c,
      percentage: totalIncome > 0 ? (c.amount / totalIncome) * 100 : 0,
    }))

    // Determine status
    let status: "surplus" | "balanced" | "deficit" = "balanced"
    if (netSavings > totalIncome * 0.01) status = "surplus"
    else if (netSavings < -totalIncome * 0.01) status = "deficit"

    // Calculate projected savings
    const multiplier = timeframe === "weekly" ? 4.33 : 1
    const projectedSavings = Math.max(0, netSavings) * multiplier * 12

    // Generate suggestions
    const suggestedAdjustments: string[] = []
    if (savingsGoal && goalAmount > netSavings) {
      const shortfall = goalAmount - netSavings
      suggestedAdjustments.push(`To meet your savings goal, reduce expenses by $${shortfall.toFixed(2)}/month`)
      if (variableExpenses > 0) {
        const percentReduction = Math.min(100, (shortfall / variableExpenses) * 100)
        suggestedAdjustments.push(`Consider reducing variable expenses by ${percentReduction.toFixed(0)}%`)
      }
    }
    if (savingsRate < 20 && status !== "deficit") {
      suggestedAdjustments.push("Aim to save at least 20% of your income for financial security")
    }
    if (fixedExpenses > totalIncome * 0.5) {
      suggestedAdjustments.push("Fixed expenses exceed 50% of income - consider reducing housing or debt costs")
    }
    if (status === "deficit") {
      suggestedAdjustments.push("You are spending more than you earn - immediate action needed")
    }

    setResult({
      totalIncome,
      totalExpenses,
      fixedExpenses,
      variableExpenses,
      netSavings,
      savingsRate,
      expenseBreakdown,
      status,
      projectedSavings,
      savingsGoalMet: netSavings >= goalAmount,
      suggestedAdjustments,
    })
  }

  const handleReset = () => {
    setIncomes([{ id: "1", name: "", amount: "" }])
    setExpenses([{ id: "1", name: "", amount: "", category: "fixed" }])
    setSavingsGoal("")
    setSavingsGoalType("percentage")
    setTimeframe("monthly")
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Personal Budget Summary:\nTotal Income: $${result.totalIncome.toLocaleString()}\nTotal Expenses: $${result.totalExpenses.toLocaleString()}\nNet Savings: $${result.netSavings.toLocaleString()}\nSavings Rate: ${result.savingsRate.toFixed(1)}%`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "My Personal Budget",
          text: `I'm saving ${result.savingsRate.toFixed(1)}% of my income with a net savings of $${result.netSavings.toLocaleString()}/month!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "surplus":
        return "bg-green-50 border-green-200 text-green-700"
      case "deficit":
        return "bg-red-50 border-red-200 text-red-700"
      default:
        return "bg-yellow-50 border-yellow-200 text-yellow-700"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "surplus":
        return <TrendingUp className="h-5 w-5" />
      case "deficit":
        return <TrendingDown className="h-5 w-5" />
      default:
        return <Target className="h-5 w-5" />
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Wallet className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Personal Budget Calculator</CardTitle>
                    <CardDescription>Track income, expenses, and savings</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <Tabs defaultValue="income" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="income">Income</TabsTrigger>
                    <TabsTrigger value="expenses">Expenses</TabsTrigger>
                    <TabsTrigger value="goals">Goals</TabsTrigger>
                  </TabsList>

                  <TabsContent value="income" className="space-y-4 mt-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-base font-semibold">Income Sources</Label>
                      <Button variant="outline" size="sm" onClick={addIncome}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    </div>

                    {incomes.map((income, index) => (
                      <div key={income.id} className="p-3 border rounded-lg space-y-2 bg-muted/30">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-muted-foreground">Source #{index + 1}</span>
                          {incomes.length > 1 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeIncome(income.id)}
                              className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Input
                            placeholder="Source name"
                            value={income.name}
                            onChange={(e) => updateIncome(income.id, "name", e.target.value)}
                          />
                          <Input
                            type="number"
                            placeholder="Amount"
                            value={income.amount}
                            onChange={(e) => updateIncome(income.id, "amount", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                        </div>
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="expenses" className="space-y-4 mt-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-base font-semibold">Expenses</Label>
                      <Button variant="outline" size="sm" onClick={addExpense}>
                        <Plus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    </div>

                    {expenses.map((expense, index) => (
                      <div key={expense.id} className="p-3 border rounded-lg space-y-2 bg-muted/30">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-muted-foreground">Expense #{index + 1}</span>
                          {expenses.length > 1 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeExpense(expense.id)}
                              className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <Input
                            placeholder="Expense name"
                            value={expense.name}
                            onChange={(e) => updateExpense(expense.id, "name", e.target.value)}
                          />
                          <Input
                            type="number"
                            placeholder="Amount"
                            value={expense.amount}
                            onChange={(e) => updateExpense(expense.id, "amount", e.target.value)}
                            min="0"
                            step="0.01"
                          />
                          <Select
                            value={expense.category}
                            onValueChange={(value) => updateExpense(expense.id, "category", value)}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="fixed">Fixed</SelectItem>
                              <SelectItem value="variable">Variable</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="goals" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Savings Goal (Optional)</Label>
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder={savingsGoalType === "percentage" ? "20" : "500"}
                          value={savingsGoal}
                          onChange={(e) => setSavingsGoal(e.target.value)}
                          min="0"
                          step="0.01"
                          className="flex-1"
                        />
                        <Select
                          value={savingsGoalType}
                          onValueChange={(value: "percentage" | "amount") => setSavingsGoalType(value)}
                        >
                          <SelectTrigger className="w-28">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="percentage">%</SelectItem>
                            <SelectItem value="amount">$</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Timeframe</Label>
                      <Select value={timeframe} onValueChange={(value: "monthly" | "weekly") => setTimeframe(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </TabsContent>
                </Tabs>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBudget} className="w-full" size="lg">
                  Calculate Budget
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 transition-all duration-300 ${getStatusColor(result.status)}`}
                  >
                    <div className="text-center mb-4">
                      <div className="flex items-center justify-center gap-2 mb-1">
                        {getStatusIcon(result.status)}
                        <p className="text-sm font-medium capitalize">{result.status}</p>
                      </div>
                      <p className="text-3xl font-bold mb-1">{formatCurrency(result.netSavings)}</p>
                      <p className="text-sm opacity-80">Net Savings ({result.savingsRate.toFixed(1)}% of income)</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Income</p>
                        <p className="text-lg font-semibold text-green-600">{formatCurrency(result.totalIncome)}</p>
                      </div>
                      <div className="p-3 bg-white/80 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Expenses</p>
                        <p className="text-lg font-semibold text-red-600">{formatCurrency(result.totalExpenses)}</p>
                      </div>
                    </div>

                    {/* Expense Breakdown */}
                    <div className="mb-4">
                      <p className="text-sm font-semibold mb-2">Budget Breakdown:</p>
                      <div className="space-y-2">
                        {result.expenseBreakdown.map((item) => (
                          <div key={item.category} className="bg-white/80 rounded-lg p-2">
                            <div className="flex justify-between text-sm mb-1">
                              <span>{item.category}</span>
                              <span className="font-medium">
                                {formatCurrency(item.amount)} ({item.percentage.toFixed(1)}%)
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  item.category === "Savings"
                                    ? "bg-green-500"
                                    : item.category === "Fixed Expenses"
                                      ? "bg-blue-500"
                                      : "bg-orange-500"
                                }`}
                                style={{ width: `${Math.min(100, item.percentage)}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Projected Annual Savings */}
                    <div className="p-3 bg-white/80 rounded-lg text-center mb-4">
                      <p className="text-xs text-muted-foreground">Projected Annual Savings</p>
                      <p className="text-xl font-bold text-green-600">{formatCurrency(result.projectedSavings)}</p>
                    </div>

                    {/* Suggestions */}
                    {result.suggestedAdjustments.length > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowDetails(!showDetails)}
                        className="w-full mb-3 bg-white/80"
                      >
                        {showDetails ? (
                          <>
                            <ChevronUp className="h-4 w-4 mr-1" />
                            Hide Suggestions
                          </>
                        ) : (
                          <>
                            <ChevronDown className="h-4 w-4 mr-1" />
                            View Suggestions
                          </>
                        )}
                      </Button>
                    )}

                    {showDetails && result.suggestedAdjustments.length > 0 && (
                      <div className="space-y-2 mb-4">
                        {result.suggestedAdjustments.map((suggestion, index) => (
                          <div key={index} className="p-2 bg-white/80 rounded-lg text-sm flex items-start gap-2">
                            <Info className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                            <span>{suggestion}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={handleCopy} className="flex-1 bg-white/80">
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied!" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare} className="flex-1 bg-white/80">
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleReset} className="flex-1 bg-white/80">
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              {/* 50/30/20 Rule Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <PiggyBank className="h-5 w-5 text-green-600" />
                    The 50/30/20 Rule
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-3">
                    A simple budgeting guideline to allocate your after-tax income:
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 p-2 bg-blue-50 rounded-lg">
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-blue-700 text-sm font-bold">
                        50%
                      </span>
                      <div>
                        <p className="text-sm font-medium">Needs</p>
                        <p className="text-xs text-muted-foreground">Housing, utilities, groceries, insurance</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-orange-50 rounded-lg">
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-orange-100 text-orange-700 text-sm font-bold">
                        30%
                      </span>
                      <div>
                        <p className="text-sm font-medium">Wants</p>
                        <p className="text-xs text-muted-foreground">Entertainment, dining out, hobbies</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded-lg">
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100 text-green-700 text-sm font-bold">
                        20%
                      </span>
                      <div>
                        <p className="text-sm font-medium">Savings</p>
                        <p className="text-xs text-muted-foreground">Emergency fund, retirement, debt payoff</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Budget Categories Card */}
              <Card className="shadow-md border-0">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Info className="h-5 w-5 text-blue-600" />
                    Fixed vs Variable Expenses
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm font-semibold text-blue-800 mb-1">Fixed Expenses</p>
                    <p className="text-xs text-blue-700">
                      Consistent monthly costs: rent/mortgage, car payment, insurance, subscriptions, loan payments
                    </p>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <p className="text-sm font-semibold text-orange-800 mb-1">Variable Expenses</p>
                    <p className="text-xs text-orange-700">
                      Fluctuating costs: groceries, utilities, gas, entertainment, dining, shopping
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <Card className="shadow-md border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Info className="h-5 w-5 text-blue-600" />
                  What is Personal Budgeting?
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground space-y-2">
                <p>
                  Personal budgeting is the process of creating a plan for how to spend and save your money. It helps
                  you understand where your money goes and make informed financial decisions.
                </p>
                <p>
                  A good budget ensures you can cover essential expenses, save for future goals, and still enjoy life
                  without accumulating unnecessary debt.
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md border-0">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Target className="h-5 w-5 text-green-600" />
                  Tips for Successful Budgeting
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <ul className="space-y-1 list-disc list-inside">
                  <li>Track all income sources accurately</li>
                  <li>Categorize expenses as needs vs wants</li>
                  <li>Pay yourself first by automating savings</li>
                  <li>Review and adjust your budget monthly</li>
                  <li>Build an emergency fund of 3-6 months expenses</li>
                  <li>Use the 24-hour rule for non-essential purchases</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Disclaimer */}
          <Card className="mt-6 shadow-md border-0 bg-muted/50">
            <CardContent className="pt-6">
              <div className="flex gap-3">
                <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-muted-foreground">
                  <p className="font-medium text-foreground mb-1">Important Disclaimer</p>
                  <p>
                    Personal budget calculations are estimates based on user inputs. Consult a financial advisor for
                    personalized financial planning. This calculator does not account for taxes, irregular expenses, or
                    changes in income.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
