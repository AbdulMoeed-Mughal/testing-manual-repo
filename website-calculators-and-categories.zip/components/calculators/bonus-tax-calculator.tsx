"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  DollarSign,
  Info,
  AlertTriangle,
  TrendingDown,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { currencies, formatCurrency, type CurrencyCode } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

interface BonusTaxResult {
  grossBonus: number
  federalTax: number
  stateTax: number
  socialSecurity: number
  medicare: number
  additionalDeductions: number
  totalDeductions: number
  netBonus: number
  effectiveTaxRate: number
}

export function BonusTaxCalculator() {
  const [bonusAmount, setBonusAmount] = useState("")
  const [federalTaxRate, setFederalTaxRate] = useState("22")
  const [stateTaxRate, setStateTaxRate] = useState("")
  const [socialSecurityRate, setSocialSecurityRate] = useState("6.2")
  const [medicareRate, setMedicareRate] = useState("1.45")
  const [additionalDeductions, setAdditionalDeductions] = useState("")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<BonusTaxResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)
  const [currency, setCurrency] = useState<CurrencyCode>("USD")

  const calculateBonusTax = () => {
    setError("")
    setResult(null)

    const bonus = Number.parseFloat(bonusAmount)
    if (isNaN(bonus) || bonus <= 0) {
      setError("Please enter a valid bonus amount greater than 0")
      return
    }

    const federal = Number.parseFloat(federalTaxRate) || 0
    const state = Number.parseFloat(stateTaxRate) || 0
    const ss = Number.parseFloat(socialSecurityRate) || 0
    const med = Number.parseFloat(medicareRate) || 0
    const additional = Number.parseFloat(additionalDeductions) || 0

    if (federal < 0 || federal > 100 || state < 0 || state > 100 || ss < 0 || ss > 100 || med < 0 || med > 100) {
      setError("Tax rates must be between 0 and 100%")
      return
    }

    if (additional < 0) {
      setError("Additional deductions must be positive")
      return
    }

    const federalTax = bonus * (federal / 100)
    const stateTax = bonus * (state / 100)
    const socialSecurity = bonus * (ss / 100)
    const medicare = bonus * (med / 100)
    const totalDeductions = federalTax + stateTax + socialSecurity + medicare + additional
    const netBonus = bonus - totalDeductions
    const effectiveTaxRate = (totalDeductions / bonus) * 100

    setResult({
      grossBonus: bonus,
      federalTax,
      stateTax,
      socialSecurity,
      medicare,
      additionalDeductions: additional,
      totalDeductions,
      netBonus,
      effectiveTaxRate,
    })
  }

  const handleReset = () => {
    setBonusAmount("")
    setFederalTaxRate("22")
    setStateTaxRate("")
    setSocialSecurityRate("6.2")
    setMedicareRate("1.45")
    setAdditionalDeductions("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(
        `Bonus Tax Summary:\nGross Bonus: ${formatCurrency(result.grossBonus, currency)}\nTotal Deductions: ${formatCurrency(result.totalDeductions, currency)}\nNet Bonus: ${formatCurrency(result.netBonus, currency)}\nEffective Tax Rate: ${result.effectiveTaxRate.toFixed(1)}%`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Bonus Tax Calculation",
          text: `My bonus of ${formatCurrency(result.grossBonus, currency)} has ${formatCurrency(result.totalDeductions, currency)} in deductions, leaving me with ${formatCurrency(result.netBonus, currency)} (${result.effectiveTaxRate.toFixed(1)}% effective rate)`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getNetBonusColor = () => {
    if (!result) return ""
    const retentionRate = (result.netBonus / result.grossBonus) * 100
    if (retentionRate >= 70) return "text-green-600"
    if (retentionRate >= 50) return "text-yellow-600"
    return "text-red-600"
  }

  const getNetBonusBgColor = () => {
    if (!result) return ""
    const retentionRate = (result.netBonus / result.grossBonus) * 100
    if (retentionRate >= 70) return "bg-green-50 border-green-200"
    if (retentionRate >= 50) return "bg-yellow-50 border-yellow-200"
    return "bg-red-50 border-red-200"
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Bonus Tax Calculator</CardTitle>
                    <CardDescription>Estimate taxes on employee bonuses</CardDescription>
                  </div>
                </div>
                <CurrencySelector value={currency} onValueChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Bonus Amount Input */}
                <div className="space-y-2">
                  <Label htmlFor="bonus">Bonus Amount ({currencies[currency].symbol})</Label>
                  <Input
                    id="bonus"
                    type="number"
                    placeholder="Enter bonus amount"
                    value={bonusAmount}
                    onChange={(e) => setBonusAmount(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Federal Tax Rate */}
                <div className="space-y-2">
                  <Label htmlFor="federal">Federal Tax Rate (%)</Label>
                  <Input
                    id="federal"
                    type="number"
                    placeholder="22"
                    value={federalTaxRate}
                    onChange={(e) => setFederalTaxRate(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                  <p className="text-xs text-muted-foreground">Default 22% for supplemental income</p>
                </div>

                {/* State Tax Rate */}
                <div className="space-y-2">
                  <Label htmlFor="state">State Tax Rate (%) - Optional</Label>
                  <Input
                    id="state"
                    type="number"
                    placeholder="Enter state tax rate"
                    value={stateTaxRate}
                    onChange={(e) => setStateTaxRate(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto hover:bg-transparent">
                      <span className="text-sm font-medium">Advanced Options</span>
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    {/* Social Security Rate */}
                    <div className="space-y-2">
                      <Label htmlFor="ss">Social Security Rate (%)</Label>
                      <Input
                        id="ss"
                        type="number"
                        placeholder="6.2"
                        value={socialSecurityRate}
                        onChange={(e) => setSocialSecurityRate(e.target.value)}
                        min="0"
                        max="100"
                        step="0.01"
                      />
                    </div>

                    {/* Medicare Rate */}
                    <div className="space-y-2">
                      <Label htmlFor="medicare">Medicare Rate (%)</Label>
                      <Input
                        id="medicare"
                        type="number"
                        placeholder="1.45"
                        value={medicareRate}
                        onChange={(e) => setMedicareRate(e.target.value)}
                        min="0"
                        max="100"
                        step="0.01"
                      />
                    </div>

                    {/* Additional Deductions */}
                    <div className="space-y-2">
                      <Label htmlFor="additional">Additional Deductions ({currencies[currency].symbol})</Label>
                      <Input
                        id="additional"
                        type="number"
                        placeholder="401k, insurance, etc."
                        value={additionalDeductions}
                        onChange={(e) => setAdditionalDeductions(e.target.value)}
                        min="0"
                        step="10"
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBonusTax} className="w-full" size="lg">
                  Calculate Net Bonus
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${getNetBonusBgColor()} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Your Net Bonus</p>
                      <p className={`text-4xl font-bold ${getNetBonusColor()} mb-1`}>
                        {formatCurrency(result.netBonus, currency)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {result.effectiveTaxRate.toFixed(1)}% effective tax rate
                      </p>
                    </div>

                    {/* Gross vs Net Comparison */}
                    <div className="mt-4 p-3 bg-white/50 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Gross Bonus</span>
                        <span className="font-semibold">{formatCurrency(result.grossBonus, currency)}</span>
                      </div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-muted-foreground">Total Deductions</span>
                        <span className="font-semibold text-red-600">
                          -{formatCurrency(result.totalDeductions, currency)}
                        </span>
                      </div>
                      <div className="border-t pt-2 flex justify-between items-center">
                        <span className="text-sm font-medium">Net Bonus</span>
                        <span className={`font-bold ${getNetBonusColor()}`}>
                          {formatCurrency(result.netBonus, currency)}
                        </span>
                      </div>
                    </div>

                    {/* Detailed Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full mt-3">
                          {showBreakdown ? "Hide" : "Show"} Tax Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3 space-y-2">
                        <div className="p-3 bg-white/50 rounded-lg space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Federal Tax ({federalTaxRate}%)</span>
                            <span>{formatCurrency(result.federalTax, currency)}</span>
                          </div>
                          {result.stateTax > 0 && (
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">State Tax ({stateTaxRate}%)</span>
                              <span>{formatCurrency(result.stateTax, currency)}</span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Social Security ({socialSecurityRate}%)</span>
                            <span>{formatCurrency(result.socialSecurity, currency)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Medicare ({medicareRate}%)</span>
                            <span>{formatCurrency(result.medicare, currency)}</span>
                          </div>
                          {result.additionalDeductions > 0 && (
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">Additional Deductions</span>
                              <span>{formatCurrency(result.additionalDeductions, currency)}</span>
                            </div>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Federal Bonus Tax Rates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Flat Rate Method</span>
                      <span className="text-sm text-green-600">22%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Bonuses over $1M</span>
                      <span className="text-sm text-yellow-600">37%</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Aggregate Method</span>
                      <span className="text-sm text-blue-600">Varies</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    Most employers use the 22% flat rate for supplemental income under $1 million.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">FICA Taxes</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex justify-between mb-2">
                      <span>Social Security</span>
                      <span className="font-semibold text-foreground">6.2%</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span>Medicare</span>
                      <span className="font-semibold text-foreground">1.45%</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t">
                      <span>Total FICA</span>
                      <span className="font-semibold text-foreground">7.65%</span>
                    </div>
                  </div>
                  <p>
                    Social Security has a wage base limit of $168,600 (2024). Medicare has no limit, with an additional
                    0.9% on income over $200K.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>How Are Bonuses Taxed?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Bonuses are considered supplemental wages by the IRS, which means they are taxed differently than your
                  regular salary. Employers typically use one of two methods to calculate federal income tax withholding
                  on bonuses: the flat rate method or the aggregate method. Understanding how your bonus will be taxed
                  can help you plan your finances and avoid surprises come tax time.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The flat rate method applies a fixed 22% federal income tax rate to bonuses under $1 million. For
                  bonuses exceeding $1 million, the portion over $1 million is taxed at 37%. The aggregate method
                  combines your bonus with your regular pay and calculates withholding based on the total, which can
                  result in higher withholding if it pushes you into a higher bracket temporarily.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>Ways to Reduce Bonus Taxes</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="list-disc list-inside text-muted-foreground space-y-2">
                  <li>Increase 401(k) contributions to reduce taxable income</li>
                  <li>Contribute to a Health Savings Account (HSA) if eligible</li>
                  <li>Request your employer spread the bonus across pay periods</li>
                  <li>Maximize deductions through charitable contributions</li>
                  <li>Consider contributing to a traditional IRA</li>
                  <li>Time deductible expenses to offset bonus income</li>
                </ul>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Remember that while taxes are withheld at the flat 22% rate, your actual tax liability depends on your
                  complete financial situation, state of residence, and applicable deductions. If you're in a lower tax
                  bracket, you may get some of this withholding back as a refund when you file your taxes.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="bg-muted/50 border-dashed">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <p className="font-medium text-foreground mb-1">Important Disclaimer</p>
                    <p>
                      This calculator provides estimates based on standard tax withholding rates and should be used for
                      informational purposes only. Actual taxes may vary based on your complete financial situation,
                      state of residence, and applicable deductions. For personalized tax advice, please consult with a
                      qualified tax professional.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
