"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Hash, Info, Calculator, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type SequenceType = "arithmetic" | "geometric" | "custom"

interface NthTermResult {
  nthTerm: number
  sequence: number[]
  steps: string[]
  formula: string
  latex: string
}

export function NthTermCalculator() {
  const [sequenceType, setSequenceType] = useState<SequenceType>("arithmetic")
  const [firstTerm, setFirstTerm] = useState("")
  const [commonDiff, setCommonDiff] = useState("")
  const [commonRatio, setCommonRatio] = useState("")
  const [customFormula, setCustomFormula] = useState("")
  const [termNumber, setTermNumber] = useState("")
  const [showSteps, setShowSteps] = useState(true)
  const [showSequence, setShowSequence] = useState(true)
  const [result, setResult] = useState<NthTermResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [copiedLatex, setCopiedLatex] = useState(false)
  const [error, setError] = useState("")
  const [detailsOpen, setDetailsOpen] = useState(false)

  const calculateNthTerm = () => {
    setError("")
    setResult(null)

    const n = Number.parseInt(termNumber)
    if (isNaN(n) || n <= 0 || !Number.isInteger(n)) {
      setError("Term number must be a positive integer")
      return
    }

    if (n > 1000) {
      setError("Term number must be 1000 or less")
      return
    }

    let nthTerm: number
    const sequence: number[] = []
    let steps: string[] = []
    let formula: string
    let latex: string

    if (sequenceType === "arithmetic") {
      const a1 = Number.parseFloat(firstTerm)
      const d = Number.parseFloat(commonDiff)

      if (isNaN(a1)) {
        setError("Please enter a valid first term")
        return
      }
      if (isNaN(d)) {
        setError("Please enter a valid common difference")
        return
      }

      // Calculate nth term: aₙ = a₁ + (n - 1) × d
      nthTerm = a1 + (n - 1) * d

      // Generate sequence
      const maxTerms = Math.min(n, 50)
      for (let i = 1; i <= maxTerms; i++) {
        sequence.push(a1 + (i - 1) * d)
      }

      // Generate steps
      steps = [
        `Given: First term (a₁) = ${a1}, Common difference (d) = ${d}, Term number (n) = ${n}`,
        `Formula: aₙ = a₁ + (n − 1) × d`,
        `Substitute values: a${n} = ${a1} + (${n} − 1) × ${d}`,
        `Simplify: a${n} = ${a1} + ${n - 1} × ${d}`,
        `Calculate: a${n} = ${a1} + ${(n - 1) * d}`,
        `Result: a${n} = ${nthTerm}`,
      ]

      formula = `aₙ = ${a1} + (n − 1) × ${d}`
      latex = `a_n = ${a1} + (n - 1) \\times ${d}`
    } else if (sequenceType === "geometric") {
      const a1 = Number.parseFloat(firstTerm)
      const r = Number.parseFloat(commonRatio)

      if (isNaN(a1)) {
        setError("Please enter a valid first term")
        return
      }
      if (isNaN(r)) {
        setError("Please enter a valid common ratio")
        return
      }
      if (r === 0) {
        setError("Common ratio cannot be zero")
        return
      }

      // Calculate nth term: aₙ = a₁ × r^(n-1)
      nthTerm = a1 * Math.pow(r, n - 1)

      // Check for overflow
      if (!isFinite(nthTerm)) {
        setError("Result is too large to compute. Try smaller values.")
        return
      }

      // Generate sequence
      const maxTerms = Math.min(n, 50)
      for (let i = 1; i <= maxTerms; i++) {
        const term = a1 * Math.pow(r, i - 1)
        if (!isFinite(term)) break
        sequence.push(term)
      }

      // Generate steps
      steps = [
        `Given: First term (a₁) = ${a1}, Common ratio (r) = ${r}, Term number (n) = ${n}`,
        `Formula: aₙ = a₁ × r^(n−1)`,
        `Substitute values: a${n} = ${a1} × ${r}^(${n} − 1)`,
        `Simplify exponent: a${n} = ${a1} × ${r}^${n - 1}`,
        `Calculate power: ${r}^${n - 1} = ${Math.pow(r, n - 1)}`,
        `Multiply: a${n} = ${a1} × ${Math.pow(r, n - 1)}`,
        `Result: a${n} = ${nthTerm}`,
      ]

      formula = `aₙ = ${a1} × ${r}^(n−1)`
      latex = `a_n = ${a1} \\times ${r}^{n-1}`
    } else {
      // Custom formula
      if (!customFormula.trim()) {
        setError("Please enter a formula")
        return
      }

      try {
        // Parse and evaluate custom formula
        // Supported: n, +, -, *, /, ^, (, ), sqrt, abs, sin, cos, tan, log, ln, e, pi
        const evaluateFormula = (formula: string, nVal: number): number => {
          const expr = formula
            .toLowerCase()
            .replace(/\^/g, "**")
            .replace(/sqrt\(/g, "Math.sqrt(")
            .replace(/abs\(/g, "Math.abs(")
            .replace(/sin\(/g, "Math.sin(")
            .replace(/cos\(/g, "Math.cos(")
            .replace(/tan\(/g, "Math.tan(")
            .replace(/log\(/g, "Math.log10(")
            .replace(/ln\(/g, "Math.log(")
            .replace(/\be\b/g, "Math.E")
            .replace(/\bpi\b/g, "Math.PI")
            .replace(/\bn\b/g, `(${nVal})`)

          // Safety check - only allow math operations
          if (!/^[\d\s+\-*/().Math\w]+$/.test(expr)) {
            throw new Error("Invalid characters in formula")
          }

          // eslint-disable-next-line no-eval
          const result = eval(expr)
          if (typeof result !== "number" || !isFinite(result)) {
            throw new Error("Invalid result")
          }
          return result
        }

        nthTerm = evaluateFormula(customFormula, n)

        // Generate sequence
        const maxTerms = Math.min(n, 50)
        for (let i = 1; i <= maxTerms; i++) {
          try {
            const term = evaluateFormula(customFormula, i)
            if (!isFinite(term)) break
            sequence.push(term)
          } catch {
            break
          }
        }

        steps = [
          `Given: Formula = ${customFormula}, Term number (n) = ${n}`,
          `Substitute n = ${n} into the formula`,
          `Evaluate: ${customFormula.replace(/n/gi, `(${n})`)}`,
          `Result: a${n} = ${nthTerm}`,
        ]

        formula = customFormula
        latex = customFormula
          .replace(/\*/g, "\\times")
          .replace(/\^/g, "^{")
          .replace(/(\d+)$/g, "$1}")
      } catch (err) {
        setError(
          "Invalid formula. Use n as the variable. Supported: +, -, *, /, ^, sqrt(), abs(), sin(), cos(), tan(), log(), ln(), e, pi",
        )
        return
      }
    }

    setResult({ nthTerm, sequence, steps, formula, latex })
  }

  const handleReset = () => {
    setFirstTerm("")
    setCommonDiff("")
    setCommonRatio("")
    setCustomFormula("")
    setTermNumber("")
    setResult(null)
    setError("")
    setCopied(false)
    setCopiedLatex(false)
    setDetailsOpen(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `The ${termNumber}${getOrdinalSuffix(Number.parseInt(termNumber))} term is ${result.nthTerm}\nFormula: ${result.formula}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleCopyLatex = async () => {
    if (result) {
      await navigator.clipboard.writeText(`a_{${termNumber}} = ${result.nthTerm}`)
      setCopiedLatex(true)
      setTimeout(() => setCopiedLatex(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Nth Term Calculation",
          text: `The ${termNumber}${getOrdinalSuffix(Number.parseInt(termNumber))} term is ${result.nthTerm}`,
          url: window.location.href,
        })
      } catch {
        // User cancelled or share failed
      }
    }
  }

  const getOrdinalSuffix = (n: number): string => {
    const s = ["th", "st", "nd", "rd"]
    const v = n % 100
    return s[(v - 20) % 10] || s[v] || s[0]
  }

  const formatNumber = (num: number): string => {
    if (Number.isInteger(num)) {
      return num.toLocaleString()
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: 8 })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Nth Term Calculator</CardTitle>
                    <CardDescription>Calculate the n-th term of a sequence</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Sequence Type Selection */}
                <div className="space-y-2">
                  <Label>Sequence Type</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      type="button"
                      variant={sequenceType === "arithmetic" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSequenceType("arithmetic")}
                      className="w-full"
                    >
                      Arithmetic
                    </Button>
                    <Button
                      type="button"
                      variant={sequenceType === "geometric" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSequenceType("geometric")}
                      className="w-full"
                    >
                      Geometric
                    </Button>
                    <Button
                      type="button"
                      variant={sequenceType === "custom" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSequenceType("custom")}
                      className="w-full"
                    >
                      Custom
                    </Button>
                  </div>
                </div>

                {/* Arithmetic Inputs */}
                {sequenceType === "arithmetic" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="firstTerm">First Term (a₁)</Label>
                      <Input
                        id="firstTerm"
                        type="number"
                        placeholder="e.g., 2"
                        value={firstTerm}
                        onChange={(e) => setFirstTerm(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="commonDiff">Common Difference (d)</Label>
                      <Input
                        id="commonDiff"
                        type="number"
                        placeholder="e.g., 3"
                        value={commonDiff}
                        onChange={(e) => setCommonDiff(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Geometric Inputs */}
                {sequenceType === "geometric" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="firstTermGeo">First Term (a₁)</Label>
                      <Input
                        id="firstTermGeo"
                        type="number"
                        placeholder="e.g., 2"
                        value={firstTerm}
                        onChange={(e) => setFirstTerm(e.target.value)}
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="commonRatio">Common Ratio (r)</Label>
                      <Input
                        id="commonRatio"
                        type="number"
                        placeholder="e.g., 2"
                        value={commonRatio}
                        onChange={(e) => setCommonRatio(e.target.value)}
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Custom Formula Input */}
                {sequenceType === "custom" && (
                  <div className="space-y-2">
                    <Label htmlFor="customFormula">Formula (in terms of n)</Label>
                    <Input
                      id="customFormula"
                      type="text"
                      placeholder="e.g., n^2 + 2*n + 1"
                      value={customFormula}
                      onChange={(e) => setCustomFormula(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Use n as variable. Supported: +, -, *, /, ^, sqrt(), abs(), sin(), cos(), tan(), log(), ln(), e,
                      pi
                    </p>
                  </div>
                )}

                {/* Term Number Input */}
                <div className="space-y-2">
                  <Label htmlFor="termNumber">Term Number (n)</Label>
                  <Input
                    id="termNumber"
                    type="number"
                    placeholder="e.g., 10"
                    value={termNumber}
                    onChange={(e) => setTermNumber(e.target.value)}
                    min="1"
                    max="1000"
                  />
                </div>

                {/* Options */}
                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-2">
                    <Switch id="showSteps" checked={showSteps} onCheckedChange={setShowSteps} />
                    <Label htmlFor="showSteps" className="text-sm cursor-pointer">
                      Show Steps
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch id="showSequence" checked={showSequence} onCheckedChange={setShowSequence} />
                    <Label htmlFor="showSequence" className="text-sm cursor-pointer">
                      Show Sequence
                    </Label>
                  </div>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateNthTerm} className="w-full" size="lg">
                  Calculate Nth Term
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">
                        The {termNumber}
                        {getOrdinalSuffix(Number.parseInt(termNumber))} term is
                      </p>
                      <p className="text-4xl font-bold text-blue-600 mb-2">{formatNumber(result.nthTerm)}</p>
                      <p className="text-sm text-muted-foreground font-mono">Formula: {result.formula}</p>
                    </div>

                    {/* Step-by-step solution */}
                    {showSteps && (
                      <Collapsible open={detailsOpen} onOpenChange={setDetailsOpen} className="mt-4">
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            Step-by-Step Solution
                            <ChevronDown
                              className={`h-4 w-4 transition-transform ${detailsOpen ? "rotate-180" : ""}`}
                            />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="p-3 bg-white rounded-lg border space-y-2">
                            {result.steps.map((step, index) => (
                              <div key={index} className="flex gap-2 text-sm">
                                <span className="font-semibold text-blue-600 shrink-0">{index + 1}.</span>
                                <span className="text-muted-foreground">{step}</span>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}

                    {/* Sequence Display */}
                    {showSequence && result.sequence.length > 0 && (
                      <div className="mt-4 p-3 bg-white rounded-lg border">
                        <p className="text-sm font-medium mb-2">Sequence (first {result.sequence.length} terms):</p>
                        <p className="text-sm text-muted-foreground font-mono break-all">
                          {result.sequence.map(formatNumber).join(", ")}
                          {Number.parseInt(termNumber) > 50 && ", ..."}
                        </p>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopyLatex}>
                        {copiedLatex ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copiedLatex ? "Copied" : "LaTeX"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Nth Term Formulas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="font-semibold text-blue-800 mb-1">Arithmetic Sequence</p>
                      <p className="font-mono text-sm text-blue-700">aₙ = a₁ + (n − 1) × d</p>
                      <p className="text-xs text-blue-600 mt-1">Where d = common difference</p>
                    </div>
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="font-semibold text-green-800 mb-1">Geometric Sequence</p>
                      <p className="font-mono text-sm text-green-700">aₙ = a₁ × r^(n−1)</p>
                      <p className="text-xs text-green-600 mt-1">Where r = common ratio</p>
                    </div>
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                      <p className="font-semibold text-purple-800 mb-1">Custom Formula</p>
                      <p className="font-mono text-sm text-purple-700">aₙ = f(n)</p>
                      <p className="text-xs text-purple-600 mt-1">Any formula in terms of n</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Examples</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                      <span>Natural numbers</span>
                      <span className="font-mono text-xs">aₙ = n</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                      <span>Even numbers</span>
                      <span className="font-mono text-xs">aₙ = 2n</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                      <span>Odd numbers</span>
                      <span className="font-mono text-xs">aₙ = 2n − 1</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                      <span>Squares</span>
                      <span className="font-mono text-xs">aₙ = n²</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                      <span>Powers of 2</span>
                      <span className="font-mono text-xs">aₙ = 2^n</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-muted/50 rounded">
                      <span>Triangular numbers</span>
                      <span className="font-mono text-xs">aₙ = n(n+1)/2</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is the Nth Term?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The nth term of a sequence is a formula that allows you to find any term in the sequence without
                  having to list all the preceding terms. It provides a direct relationship between the position (n) in
                  the sequence and the value at that position. Understanding nth term formulas is fundamental in
                  algebra, calculus, and many areas of mathematics and science.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For arithmetic sequences, each term differs from the previous by a constant amount called the common
                  difference. For geometric sequences, each term is multiplied by a constant called the common ratio to
                  get the next term. Custom formulas can represent more complex sequences like quadratic sequences,
                  Fibonacci-related sequences, or any mathematical pattern.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ol className="text-muted-foreground leading-relaxed list-decimal list-inside space-y-2">
                  <li>
                    <strong>Select the sequence type:</strong> Choose Arithmetic, Geometric, or Custom formula.
                  </li>
                  <li>
                    <strong>Enter the parameters:</strong> For arithmetic sequences, enter the first term and common
                    difference. For geometric sequences, enter the first term and common ratio. For custom formulas,
                    enter an expression in terms of n.
                  </li>
                  <li>
                    <strong>Enter the term number:</strong> Specify which term (n) you want to find.
                  </li>
                  <li>
                    <strong>Click Calculate:</strong> The calculator will compute the nth term and optionally show the
                    step-by-step solution and sequence.
                  </li>
                </ol>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Nth term calculations follow standard mathematical formulas. Results depend on correct input values
                  and selected sequence type. For custom formulas, ensure the expression is mathematically valid. Very
                  large term numbers or ratios may result in numerical overflow.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
