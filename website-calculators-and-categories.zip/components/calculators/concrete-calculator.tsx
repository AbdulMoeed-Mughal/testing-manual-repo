"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Building2, Info, AlertTriangle, Layers } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UnitSystem = "metric" | "imperial"
type ShapeType = "slab" | "footing" | "column" | "wall"
type MixRatio = "1:2:4" | "1:1.5:3" | "1:2:3" | "custom"

interface ConcreteResult {
  volume: number
  volumeWithWaste: number
  volumeM3: number
  volumeFt3: number
  volumeYd3: number
  cement: number
  sand: number
  aggregate: number
  water: number
}

export function ConcreteCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [shape, setShape] = useState<ShapeType>("slab")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [thickness, setThickness] = useState("")
  const [diameter, setDiameter] = useState("")
  const [quantity, setQuantity] = useState("1")
  const [wastePercent, setWastePercent] = useState("10")
  const [mixRatio, setMixRatio] = useState<MixRatio>("1:2:4")
  const [showMaterials, setShowMaterials] = useState(true)
  const [result, setResult] = useState<ConcreteResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculateConcrete = () => {
    setError("")
    setResult(null)

    const lengthNum = Number.parseFloat(length)
    const widthNum = Number.parseFloat(width)
    const thicknessNum = Number.parseFloat(thickness)
    const diameterNum = Number.parseFloat(diameter)
    const quantityNum = Number.parseInt(quantity) || 1
    const wasteNum = Number.parseFloat(wastePercent) || 0

    // Validation based on shape
    if (shape === "column") {
      if (isNaN(diameterNum) || diameterNum <= 0) {
        setError("Please enter a valid diameter greater than 0")
        return
      }
      if (isNaN(thicknessNum) || thicknessNum <= 0) {
        setError("Please enter a valid height greater than 0")
        return
      }
    } else {
      if (isNaN(lengthNum) || lengthNum <= 0) {
        setError("Please enter a valid length greater than 0")
        return
      }
      if (isNaN(widthNum) || widthNum <= 0) {
        setError("Please enter a valid width greater than 0")
        return
      }
      if (isNaN(thicknessNum) || thicknessNum <= 0) {
        setError("Please enter a valid thickness/depth greater than 0")
        return
      }
    }

    if (wasteNum < 0 || wasteNum > 50) {
      setError("Waste percentage must be between 0% and 50%")
      return
    }

    // Convert to meters for calculation
    let lengthM: number, widthM: number, thicknessM: number, diameterM: number

    if (unitSystem === "metric") {
      lengthM = lengthNum
      widthM = widthNum
      thicknessM = thicknessNum
      diameterM = diameterNum
    } else {
      // Convert feet to meters
      lengthM = lengthNum * 0.3048
      widthM = widthNum * 0.3048
      thicknessM = thicknessNum * 0.3048
      diameterM = diameterNum * 0.3048
    }

    // Calculate volume based on shape
    let volumeM3: number

    if (shape === "column") {
      // Circular column: V = π × r² × h
      const radiusM = diameterM / 2
      volumeM3 = Math.PI * radiusM * radiusM * thicknessM
    } else {
      // Slab, footing, wall: V = L × W × T
      volumeM3 = lengthM * widthM * thicknessM
    }

    // Multiply by quantity
    volumeM3 = volumeM3 * quantityNum

    // Add waste percentage
    const volumeWithWasteM3 = volumeM3 * (1 + wasteNum / 100)

    // Convert to other units
    const volumeFt3 = volumeWithWasteM3 * 35.3147
    const volumeYd3 = volumeWithWasteM3 * 1.30795

    // Calculate materials based on mix ratio
    // Standard concrete density ~2400 kg/m³
    // Mix ratios are cement:sand:aggregate by volume
    let cementParts: number, sandParts: number, aggregateParts: number

    switch (mixRatio) {
      case "1:1.5:3":
        cementParts = 1
        sandParts = 1.5
        aggregateParts = 3
        break
      case "1:2:3":
        cementParts = 1
        sandParts = 2
        aggregateParts = 3
        break
      case "1:2:4":
      default:
        cementParts = 1
        sandParts = 2
        aggregateParts = 4
        break
    }

    const totalParts = cementParts + sandParts + aggregateParts

    // Dry volume is ~1.54 times wet volume (accounting for voids)
    const dryVolume = volumeWithWasteM3 * 1.54

    // Calculate individual material volumes
    const cementVolume = (dryVolume * cementParts) / totalParts
    const sandVolume = (dryVolume * sandParts) / totalParts
    const aggregateVolume = (dryVolume * aggregateParts) / totalParts

    // Convert to practical units
    // Cement: 1 bag = 50kg, density ~1440 kg/m³
    const cementKg = cementVolume * 1440
    const cementBags = Math.ceil(cementKg / 50)

    // Sand and aggregate in m³ or convert to tons (density ~1600 kg/m³)
    const sandM3 = sandVolume
    const aggregateM3 = aggregateVolume

    // Water: typically 0.45-0.5 of cement weight
    const waterLiters = cementKg * 0.5

    setResult({
      volume: volumeM3,
      volumeWithWaste: volumeWithWasteM3,
      volumeM3: volumeWithWasteM3,
      volumeFt3: volumeFt3,
      volumeYd3: volumeYd3,
      cement: cementBags,
      sand: sandM3,
      aggregate: aggregateM3,
      water: waterLiters,
    })
  }

  const handleReset = () => {
    setLength("")
    setWidth("")
    setThickness("")
    setDiameter("")
    setQuantity("1")
    setWastePercent("10")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Concrete Calculator Results:
Volume: ${result.volumeM3.toFixed(3)} m³ (${result.volumeFt3.toFixed(2)} ft³, ${result.volumeYd3.toFixed(2)} yd³)
Materials (${mixRatio} mix):
- Cement: ${result.cement} bags (50kg each)
- Sand: ${result.sand.toFixed(2)} m³
- Aggregate: ${result.aggregate.toFixed(2)} m³
- Water: ${result.water.toFixed(0)} liters`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setLength("")
    setWidth("")
    setThickness("")
    setDiameter("")
    setResult(null)
    setError("")
  }

  const getShapeLabel = () => {
    switch (shape) {
      case "slab":
        return "Slab"
      case "footing":
        return "Footing"
      case "column":
        return "Column"
      case "wall":
        return "Wall"
      default:
        return "Shape"
    }
  }

  const getThicknessLabel = () => {
    switch (shape) {
      case "slab":
        return "Thickness"
      case "footing":
        return "Depth"
      case "column":
        return "Height"
      case "wall":
        return "Thickness"
      default:
        return "Thickness"
    }
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Concrete Calculator</CardTitle>
                    <CardDescription>Calculate concrete volume and materials</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Shape Selector */}
                <div className="space-y-2">
                  <Label>Shape Type</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {(["slab", "footing", "column", "wall"] as ShapeType[]).map((s) => (
                      <button
                        key={s}
                        onClick={() => {
                          setShape(s)
                          setResult(null)
                          setError("")
                        }}
                        className={`p-2 text-sm rounded-lg border-2 transition-colors capitalize ${
                          shape === s
                            ? "border-amber-500 bg-amber-50 text-amber-700"
                            : "border-muted bg-background hover:border-amber-300"
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Dimension Inputs */}
                {shape === "column" ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="diameter">Diameter ({lengthUnit})</Label>
                      <Input
                        id="diameter"
                        type="number"
                        placeholder={`Enter diameter in ${unitSystem === "metric" ? "meters" : "feet"}`}
                        value={diameter}
                        onChange={(e) => setDiameter(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="thickness">
                        {getThicknessLabel()} ({lengthUnit})
                      </Label>
                      <Input
                        id="thickness"
                        type="number"
                        placeholder={`Enter height in ${unitSystem === "metric" ? "meters" : "feet"}`}
                        value={thickness}
                        onChange={(e) => setThickness(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="length">Length ({lengthUnit})</Label>
                        <Input
                          id="length"
                          type="number"
                          placeholder="Length"
                          value={length}
                          onChange={(e) => setLength(e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="width">Width ({lengthUnit})</Label>
                        <Input
                          id="width"
                          type="number"
                          placeholder="Width"
                          value={width}
                          onChange={(e) => setWidth(e.target.value)}
                          min="0"
                          step="0.01"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="thickness">
                        {getThicknessLabel()} ({lengthUnit})
                      </Label>
                      <Input
                        id="thickness"
                        type="number"
                        placeholder={`Enter ${getThicknessLabel().toLowerCase()}`}
                        value={thickness}
                        onChange={(e) => setThickness(e.target.value)}
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </>
                )}

                {/* Quantity and Waste */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Number of Units</Label>
                    <Input
                      id="quantity"
                      type="number"
                      placeholder="1"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      min="1"
                      step="1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="waste">Waste % (5-10% typical)</Label>
                    <Input
                      id="waste"
                      type="number"
                      placeholder="10"
                      value={wastePercent}
                      onChange={(e) => setWastePercent(e.target.value)}
                      min="0"
                      max="50"
                      step="1"
                    />
                  </div>
                </div>

                {/* Mix Ratio */}
                <div className="space-y-2">
                  <Label>Mix Ratio (Cement:Sand:Aggregate)</Label>
                  <Select value={mixRatio} onValueChange={(v) => setMixRatio(v as MixRatio)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select mix ratio" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1:2:4">1:2:4 (Standard - M15)</SelectItem>
                      <SelectItem value="1:1.5:3">1:1.5:3 (Strong - M20)</SelectItem>
                      <SelectItem value="1:2:3">1:2:3 (Medium - M17.5)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateConcrete} className="w-full" size="lg">
                  Calculate Concrete
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-amber-50 border-amber-200 transition-all duration-300">
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Total Concrete Volume</p>
                      <p className="text-4xl font-bold text-amber-600 mb-1">{result.volumeM3.toFixed(3)} m³</p>
                      <p className="text-sm text-muted-foreground">
                        {result.volumeFt3.toFixed(2)} ft³ • {result.volumeYd3.toFixed(2)} yd³
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">(includes {wastePercent}% waste allowance)</p>
                    </div>

                    {/* Material Breakdown */}
                    {showMaterials && (
                      <div className="mt-4 p-3 bg-white rounded-lg border border-amber-100">
                        <p className="text-sm font-semibold text-amber-800 mb-2 flex items-center gap-2">
                          <Layers className="h-4 w-4" />
                          Material Estimate ({mixRatio} mix)
                        </p>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="p-2 bg-amber-50 rounded">
                            <p className="text-muted-foreground">Cement</p>
                            <p className="font-semibold text-amber-700">{result.cement} bags</p>
                            <p className="text-xs text-muted-foreground">(50kg bags)</p>
                          </div>
                          <div className="p-2 bg-amber-50 rounded">
                            <p className="text-muted-foreground">Sand</p>
                            <p className="font-semibold text-amber-700">{result.sand.toFixed(2)} m³</p>
                            <p className="text-xs text-muted-foreground">({(result.sand * 1600).toFixed(0)} kg)</p>
                          </div>
                          <div className="p-2 bg-amber-50 rounded">
                            <p className="text-muted-foreground">Aggregate</p>
                            <p className="font-semibold text-amber-700">{result.aggregate.toFixed(2)} m³</p>
                            <p className="text-xs text-muted-foreground">({(result.aggregate * 1600).toFixed(0)} kg)</p>
                          </div>
                          <div className="p-2 bg-amber-50 rounded">
                            <p className="text-muted-foreground">Water</p>
                            <p className="font-semibold text-amber-700">{result.water.toFixed(0)} L</p>
                            <p className="text-xs text-muted-foreground">(approx.)</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setShowMaterials(!showMaterials)}>
                        <Layers className="h-4 w-4 mr-1" />
                        {showMaterials ? "Hide" : "Show"} Materials
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Volume Formula</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">Slab / Footing / Wall</p>
                    <p className="font-mono text-sm">V = Length × Width × Thickness</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">Circular Column</p>
                    <p className="font-mono text-sm">V = π × r² × Height</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm font-medium mb-1">With Waste</p>
                    <p className="font-mono text-sm">Total = V × (1 + Waste%)</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mix Ratio Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <div>
                        <span className="font-medium text-green-700">1:2:4 (M15)</span>
                        <p className="text-xs text-green-600">Standard / General</p>
                      </div>
                      <span className="text-sm text-green-600">15 MPa</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <div>
                        <span className="font-medium text-blue-700">1:1.5:3 (M20)</span>
                        <p className="text-xs text-blue-600">Strong / Structural</p>
                      </div>
                      <span className="text-sm text-blue-600">20 MPa</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-amber-50 border border-amber-200">
                      <div>
                        <span className="font-medium text-amber-700">1:2:3 (M17.5)</span>
                        <p className="text-xs text-amber-600">Medium Strength</p>
                      </div>
                      <span className="text-sm text-amber-600">17.5 MPa</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-amber-200 bg-amber-50/50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-semibold mb-1">Disclaimer</p>
                      <p>
                        Results are estimates. Actual material requirements may vary due to site conditions, mix design,
                        and aggregate properties. Always consult a structural engineer for critical applications.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Concrete?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Concrete is a composite material composed of cement, water, and aggregates (sand and gravel or crusite
                  stone). When mixed together, these ingredients form a paste that hardens over time through a chemical
                  process called hydration. Concrete is one of the most widely used construction materials in the world
                  due to its strength, durability, and versatility.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The strength of concrete depends on several factors including the water-to-cement ratio, the type and
                  quality of aggregates used, proper mixing and placement techniques, and adequate curing time. Modern
                  concrete can be enhanced with various admixtures to improve workability, set time, strength, and
                  durability.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Mix Ratios</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Mix ratios express the proportion of cement, sand, and aggregate by volume. The ratio 1:2:4 means 1
                  part cement, 2 parts sand, and 4 parts aggregate. Different ratios produce concrete with varying
                  strengths suitable for different applications.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">M15 (1:2:4) - Standard Mix</h4>
                    <p className="text-sm text-muted-foreground">
                      Suitable for general construction, floor slabs, pathways, and non-structural applications.
                      Achieves approximately 15 MPa compressive strength after 28 days.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">M20 (1:1.5:3) - Strong Mix</h4>
                    <p className="text-sm text-muted-foreground">
                      Used for structural elements like beams, columns, and foundations. Provides approximately 20 MPa
                      compressive strength, making it suitable for load-bearing applications.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  <CardTitle>Concrete Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Slabs</h4>
                    <p className="text-sm text-muted-foreground">
                      Flat horizontal surfaces like floors, driveways, and patios. Typically 100-150mm thick for
                      residential applications.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Footings</h4>
                    <p className="text-sm text-muted-foreground">
                      Foundation elements that transfer building loads to the ground. Size depends on soil conditions
                      and structural loads.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Columns</h4>
                    <p className="text-sm text-muted-foreground">
                      Vertical structural elements that support beams and slabs. Require higher strength concrete (M20
                      or above) and reinforcement.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Walls</h4>
                    <p className="text-sm text-muted-foreground">
                      Retaining walls, basement walls, and boundary walls. Thickness varies based on height and lateral
                      pressure.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Accurate Calculations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <ul className="text-muted-foreground space-y-2">
                  <li>
                    <strong>Add waste allowance:</strong> Always include 5-10% extra for spillage, uneven surfaces, and
                    over-excavation.
                  </li>
                  <li>
                    <strong>Measure accurately:</strong> Double-check all dimensions before ordering materials to avoid
                    shortages or excess.
                  </li>
                  <li>
                    <strong>Consider site conditions:</strong> Uneven ground, formwork variations, and reinforcement
                    displacement can affect actual volume needed.
                  </li>
                  <li>
                    <strong>Order slightly more:</strong> Running short during a pour is costly; excess concrete can
                    often be used for other small projects.
                  </li>
                  <li>
                    <strong>Consult professionals:</strong> For structural applications, always have designs reviewed by
                    a qualified engineer.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
