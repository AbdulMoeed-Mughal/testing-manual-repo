"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Gauge, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type CalculationMode = "pressure" | "force" | "area"

interface PressureResult {
  pressure: number
  pressureUnit: string
  force: number
  forceUnit: string
  area: number
  areaUnit: string
  category: string
  categoryColor: string
  steps: string[]
}

const forceUnits = [
  { value: "N", label: "Newton (N)", toNewton: 1 },
  { value: "kN", label: "Kilonewton (kN)", toNewton: 1000 },
  { value: "lbf", label: "Pound-force (lbf)", toNewton: 4.44822 },
]

const areaUnits = [
  { value: "m2", label: "Square meter (m²)", toM2: 1 },
  { value: "cm2", label: "Square centimeter (cm²)", toM2: 0.0001 },
  { value: "in2", label: "Square inch (in²)", toM2: 0.00064516 },
  { value: "ft2", label: "Square foot (ft²)", toM2: 0.092903 },
]

const pressureUnits = [
  { value: "Pa", label: "Pascal (Pa)", toPa: 1 },
  { value: "kPa", label: "Kilopascal (kPa)", toPa: 1000 },
  { value: "bar", label: "Bar", toPa: 100000 },
  { value: "psi", label: "PSI (lb/in²)", toPa: 6894.76 },
]

export function PressureCalculator() {
  const [mode, setMode] = useState<CalculationMode>("pressure")
  const [force, setForce] = useState("")
  const [forceUnit, setForceUnit] = useState("N")
  const [area, setArea] = useState("")
  const [areaUnit, setAreaUnit] = useState("m2")
  const [pressure, setPressure] = useState("")
  const [pressureUnit, setPressureUnit] = useState("Pa")
  const [result, setResult] = useState<PressureResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const calculate = () => {
    setError("")
    setResult(null)

    const steps: string[] = []

    if (mode === "pressure") {
      const forceNum = Number.parseFloat(force)
      const areaNum = Number.parseFloat(area)

      if (isNaN(forceNum) || forceNum < 0) {
        setError("Please enter a valid force value")
        return
      }
      if (isNaN(areaNum) || areaNum <= 0) {
        setError("Please enter a valid area greater than 0")
        return
      }

      const forceConv = forceUnits.find((u) => u.value === forceUnit)!
      const areaConv = areaUnits.find((u) => u.value === areaUnit)!
      const pressureConv = pressureUnits.find((u) => u.value === pressureUnit)!

      const forceInNewtons = forceNum * forceConv.toNewton
      const areaInM2 = areaNum * areaConv.toM2

      steps.push(`Convert force: ${forceNum} ${forceUnit} = ${forceInNewtons.toFixed(4)} N`)
      steps.push(`Convert area: ${areaNum} ${areaUnit} = ${areaInM2.toFixed(6)} m²`)

      const pressureInPa = forceInNewtons / areaInM2
      steps.push(
        `P = F ÷ A = ${forceInNewtons.toFixed(4)} N ÷ ${areaInM2.toFixed(6)} m² = ${pressureInPa.toFixed(2)} Pa`,
      )

      const pressureResult = pressureInPa / pressureConv.toPa
      steps.push(`Convert to ${pressureUnit}: ${pressureResult.toFixed(4)} ${pressureUnit}`)

      const { category, color } = getPressureCategory(pressureInPa)

      setResult({
        pressure: pressureResult,
        pressureUnit,
        force: forceNum,
        forceUnit,
        area: areaNum,
        areaUnit,
        category,
        categoryColor: color,
        steps,
      })
    } else if (mode === "force") {
      const pressureNum = Number.parseFloat(pressure)
      const areaNum = Number.parseFloat(area)

      if (isNaN(pressureNum) || pressureNum < 0) {
        setError("Please enter a valid pressure value")
        return
      }
      if (isNaN(areaNum) || areaNum <= 0) {
        setError("Please enter a valid area greater than 0")
        return
      }

      const pressureConv = pressureUnits.find((u) => u.value === pressureUnit)!
      const areaConv = areaUnits.find((u) => u.value === areaUnit)!
      const forceConv = forceUnits.find((u) => u.value === forceUnit)!

      const pressureInPa = pressureNum * pressureConv.toPa
      const areaInM2 = areaNum * areaConv.toM2

      steps.push(`Convert pressure: ${pressureNum} ${pressureUnit} = ${pressureInPa.toFixed(2)} Pa`)
      steps.push(`Convert area: ${areaNum} ${areaUnit} = ${areaInM2.toFixed(6)} m²`)

      const forceInNewtons = pressureInPa * areaInM2
      steps.push(
        `F = P × A = ${pressureInPa.toFixed(2)} Pa × ${areaInM2.toFixed(6)} m² = ${forceInNewtons.toFixed(4)} N`,
      )

      const forceResult = forceInNewtons / forceConv.toNewton
      steps.push(`Convert to ${forceUnit}: ${forceResult.toFixed(4)} ${forceUnit}`)

      const { category, color } = getPressureCategory(pressureInPa)

      setResult({
        pressure: pressureNum,
        pressureUnit,
        force: forceResult,
        forceUnit,
        area: areaNum,
        areaUnit,
        category,
        categoryColor: color,
        steps,
      })
    } else {
      const forceNum = Number.parseFloat(force)
      const pressureNum = Number.parseFloat(pressure)

      if (isNaN(forceNum) || forceNum < 0) {
        setError("Please enter a valid force value")
        return
      }
      if (isNaN(pressureNum) || pressureNum <= 0) {
        setError("Please enter a valid pressure greater than 0")
        return
      }

      const forceConv = forceUnits.find((u) => u.value === forceUnit)!
      const pressureConv = pressureUnits.find((u) => u.value === pressureUnit)!
      const areaConv = areaUnits.find((u) => u.value === areaUnit)!

      const forceInNewtons = forceNum * forceConv.toNewton
      const pressureInPa = pressureNum * pressureConv.toPa

      steps.push(`Convert force: ${forceNum} ${forceUnit} = ${forceInNewtons.toFixed(4)} N`)
      steps.push(`Convert pressure: ${pressureNum} ${pressureUnit} = ${pressureInPa.toFixed(2)} Pa`)

      const areaInM2 = forceInNewtons / pressureInPa
      steps.push(
        `A = F ÷ P = ${forceInNewtons.toFixed(4)} N ÷ ${pressureInPa.toFixed(2)} Pa = ${areaInM2.toFixed(6)} m²`,
      )

      const areaResult = areaInM2 / areaConv.toM2
      steps.push(`Convert to ${areaUnit}: ${areaResult.toFixed(4)} ${areaUnit}`)

      const { category, color } = getPressureCategory(pressureInPa)

      setResult({
        pressure: pressureNum,
        pressureUnit,
        force: forceNum,
        forceUnit,
        area: areaResult,
        areaUnit,
        category,
        categoryColor: color,
        steps,
      })
    }
  }

  const getPressureCategory = (pressureInPa: number): { category: string; color: string } => {
    if (pressureInPa < 101325 * 0.5) {
      return { category: "Low Pressure", color: "text-blue-600" }
    } else if (pressureInPa <= 101325 * 2) {
      return { category: "Normal Pressure", color: "text-green-600" }
    } else {
      return { category: "High Pressure", color: "text-red-600" }
    }
  }

  const handleReset = () => {
    setForce("")
    setArea("")
    setPressure("")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      let text = ""
      if (mode === "pressure") {
        text = `Pressure: ${result.pressure.toFixed(4)} ${result.pressureUnit}`
      } else if (mode === "force") {
        text = `Force: ${result.force.toFixed(4)} ${result.forceUnit}`
      } else {
        text = `Area: ${result.area.toFixed(4)} ${result.areaUnit}`
      }
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Pressure Calculator Result",
          text: `Pressure: ${result.pressure.toFixed(4)} ${result.pressureUnit}, Force: ${result.force.toFixed(4)} ${result.forceUnit}, Area: ${result.area.toFixed(4)} ${result.areaUnit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled
      }
    }
  }

  const formatNumber = (num: number): string => {
    if (Math.abs(num) >= 1e6 || (Math.abs(num) < 0.001 && num !== 0)) {
      return num.toExponential(4)
    }
    return num.toFixed(4)
  }

  const getUnitSymbol = (unit: string): string => {
    if (unit === "m2") return "m²"
    if (unit === "cm2") return "cm²"
    if (unit === "in2") return "in²"
    if (unit === "ft2") return "ft²"
    return unit
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics & Engineering
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-50 text-orange-600">
                    <Gauge className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Pressure Calculator</CardTitle>
                    <CardDescription>Calculate pressure, force, or area</CardDescription>
                  </div>
                </div>

                {/* Mode Selection */}
                <div className="pt-2">
                  <Label className="text-sm font-medium mb-2 block">Calculate</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { value: "pressure", label: "Pressure" },
                      { value: "force", label: "Force" },
                      { value: "area", label: "Area" },
                    ].map((m) => (
                      <button
                        key={m.value}
                        onClick={() => {
                          setMode(m.value as CalculationMode)
                          setResult(null)
                          setError("")
                        }}
                        className={`py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                          mode === m.value
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted hover:bg-muted/80 text-muted-foreground"
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Force Input */}
                {mode !== "force" && (
                  <div className="space-y-2">
                    <Label htmlFor="force">Force</Label>
                    <div className="flex gap-2">
                      <Input
                        id="force"
                        type="number"
                        placeholder="Enter force"
                        value={force}
                        onChange={(e) => setForce(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={forceUnit} onValueChange={setForceUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {forceUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {u.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Area Input */}
                {mode !== "area" && (
                  <div className="space-y-2">
                    <Label htmlFor="area">Area</Label>
                    <div className="flex gap-2">
                      <Input
                        id="area"
                        type="number"
                        placeholder="Enter area"
                        value={area}
                        onChange={(e) => setArea(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={areaUnit} onValueChange={setAreaUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {areaUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {getUnitSymbol(u.value)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Pressure Input */}
                {mode !== "pressure" && (
                  <div className="space-y-2">
                    <Label htmlFor="pressure">Pressure</Label>
                    <div className="flex gap-2">
                      <Input
                        id="pressure"
                        type="number"
                        placeholder="Enter pressure"
                        value={pressure}
                        onChange={(e) => setPressure(e.target.value)}
                        min="0"
                        step="any"
                        className="flex-1"
                      />
                      <Select value={pressureUnit} onValueChange={setPressureUnit}>
                        <SelectTrigger className="w-28">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {pressureUnits.map((u) => (
                            <SelectItem key={u.value} value={u.value}>
                              {u.value}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {/* Output Unit Selection */}
                {mode === "pressure" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={pressureUnit} onValueChange={setPressureUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {pressureUnits.map((u) => (
                          <SelectItem key={u.value} value={u.value}>
                            {u.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {mode === "force" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={forceUnit} onValueChange={setForceUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {forceUnits.map((u) => (
                          <SelectItem key={u.value} value={u.value}>
                            {u.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {mode === "area" && (
                  <div className="space-y-2">
                    <Label>Result Unit</Label>
                    <Select value={areaUnit} onValueChange={setAreaUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {areaUnits.map((u) => (
                          <SelectItem key={u.value} value={u.value}>
                            {u.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Error */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate {mode.charAt(0).toUpperCase() + mode.slice(1)}
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-orange-50 border-orange-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {mode === "pressure" ? "Pressure" : mode === "force" ? "Force" : "Area"}
                      </p>
                      <p className="text-4xl font-bold text-orange-600 mb-1">
                        {mode === "pressure"
                          ? formatNumber(result.pressure)
                          : mode === "force"
                            ? formatNumber(result.force)
                            : formatNumber(result.area)}
                      </p>
                      <p className="text-lg font-medium text-orange-600">
                        {mode === "pressure"
                          ? result.pressureUnit
                          : mode === "force"
                            ? result.forceUnit
                            : getUnitSymbol(result.areaUnit)}
                      </p>
                      <p className={`text-sm font-medium mt-2 ${result.categoryColor}`}>{result.category}</p>
                    </div>

                    {/* All Values */}
                    <div className="mt-4 pt-4 border-t border-orange-200 grid grid-cols-3 gap-2 text-center text-sm">
                      <div>
                        <p className="text-muted-foreground">Force</p>
                        <p className="font-semibold">
                          {formatNumber(result.force)} {result.forceUnit}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Area</p>
                        <p className="font-semibold">
                          {formatNumber(result.area)} {getUnitSymbol(result.areaUnit)}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Pressure</p>
                        <p className="font-semibold">
                          {formatNumber(result.pressure)} {result.pressureUnit}
                        </p>
                      </div>
                    </div>

                    {/* Steps */}
                    <div className="mt-4 pt-4 border-t border-orange-200">
                      <p className="text-sm font-medium text-muted-foreground mb-2">Calculation Steps:</p>
                      <div className="space-y-1">
                        {result.steps.map((step, i) => (
                          <p key={i} className="text-xs text-muted-foreground font-mono">
                            {step}
                          </p>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pressure Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-sm font-medium">Pressure</p>
                    <p className="font-mono text-lg">P = F ÷ A</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-sm font-medium">Force</p>
                    <p className="font-mono text-lg">F = P × A</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="text-sm font-medium">Area</p>
                    <p className="font-mono text-lg">A = F ÷ P</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Reference</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>1 bar</strong> = 100,000 Pa
                  </p>
                  <p>
                    <strong>1 psi</strong> = 6,894.76 Pa
                  </p>
                  <p>
                    <strong>1 atm</strong> = 101,325 Pa
                  </p>
                  <p>
                    <strong>1 kN</strong> = 1,000 N
                  </p>
                  <p>
                    <strong>1 lbf</strong> = 4.448 N
                  </p>
                </CardContent>
              </Card>

              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-yellow-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>Results are theoretical and assume uniform force distribution across the area.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Pressure?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pressure is a fundamental physical quantity that describes the force applied perpendicular to the
                  surface of an object per unit area over which that force is distributed. In simpler terms, pressure
                  measures how concentrated a force is when it acts on a surface. The same force applied over a smaller
                  area results in higher pressure, while spreading the force over a larger area reduces the pressure.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The SI unit of pressure is the Pascal (Pa), which equals one Newton per square meter (N/m²). However,
                  many other units are commonly used depending on the application: bar and kilopascals in meteorology
                  and industry, psi (pounds per square inch) in the United States for tire pressure and hydraulics, and
                  atmospheres (atm) for scientific applications involving gases.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding the Pressure Formula</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The relationship between pressure, force, and area is expressed by the simple formula: P = F ÷ A,
                  where P is pressure, F is the force applied perpendicular to the surface, and A is the area over which
                  the force is distributed. This relationship can be rearranged to solve for any of the three variables:
                  F = P × A when you know pressure and area, or A = F ÷ P when you know force and pressure.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This formula assumes that the force is uniformly distributed across the entire surface and applied
                  perpendicular to it. In real-world applications, force distribution may not be perfectly uniform,
                  which can lead to localized areas of higher or lower pressure. Engineers and physicists must consider
                  these variations when designing structures, hydraulic systems, or analyzing fluid dynamics.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Gauge className="h-5 w-5 text-primary" />
                  <CardTitle>Types of Pressure</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  There are several types of pressure measurements used in different contexts. Absolute pressure is
                  measured relative to a perfect vacuum (zero pressure). Gauge pressure is measured relative to
                  atmospheric pressure—for example, tire pressure is typically expressed as gauge pressure. Atmospheric
                  pressure is the pressure exerted by the weight of the atmosphere, approximately 101,325 Pa at sea
                  level.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In fluid mechanics, static pressure refers to the pressure exerted by a fluid at rest, while dynamic
                  pressure accounts for the fluid's motion. Hydrostatic pressure increases with depth in a fluid due to
                  the weight of the fluid above. Understanding these different types of pressure is essential for
                  applications ranging from weather forecasting to designing underwater structures and aircraft.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Real-World Applications</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Pressure calculations are essential in countless engineering and everyday applications. In hydraulic
                  systems, understanding pressure allows engineers to design brakes, lifts, and manufacturing equipment
                  that multiply force efficiently. Pneumatic systems use compressed air pressure to power tools and
                  automation equipment. In the medical field, blood pressure measurements help diagnose cardiovascular
                  health.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In construction and structural engineering, pressure calculations determine how loads are distributed
                  through foundations and structural elements. Tire pressure affects vehicle handling, fuel efficiency,
                  and safety. In aerospace, understanding pressure differentials is critical for aircraft design and
                  cabin pressurization. Even in cooking, pressure cookers use elevated pressure to increase boiling
                  temperatures and reduce cooking times.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
