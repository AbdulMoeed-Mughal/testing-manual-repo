"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calendar,
  Info,
  Briefcase,
  ChevronDown,
  ChevronUp,
  Plus,
  X,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

interface WorkingDaysResult {
  totalDays: number
  workingDays: number
  weekendDays: number
  holidayDays: number
  workingHours: number | null
}

export function WorkingDaysCalculator() {
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [includeStartDate, setIncludeStartDate] = useState(true)
  const [includeEndDate, setIncludeEndDate] = useState(true)
  const [excludeSaturday, setExcludeSaturday] = useState(true)
  const [excludeSunday, setExcludeSunday] = useState(true)
  const [holidays, setHolidays] = useState<string[]>([])
  const [newHoliday, setNewHoliday] = useState("")
  const [hoursPerDay, setHoursPerDay] = useState("8")
  const [calculateHours, setCalculateHours] = useState(false)
  const [result, setResult] = useState<WorkingDaysResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const addHoliday = () => {
    if (newHoliday && !holidays.includes(newHoliday)) {
      setHolidays([...holidays, newHoliday])
      setNewHoliday("")
    }
  }

  const removeHoliday = (holiday: string) => {
    setHolidays(holidays.filter((h) => h !== holiday))
  }

  const calculateWorkingDays = () => {
    setError("")
    setResult(null)

    if (!startDate || !endDate) {
      setError("Please select both start and end dates")
      return
    }

    const start = new Date(startDate)
    const end = new Date(endDate)

    if (start > end) {
      setError("Start date must be before or equal to end date")
      return
    }

    // Adjust dates based on inclusion settings
    const adjustedStart = new Date(start)
    const adjustedEnd = new Date(end)

    if (!includeStartDate) {
      adjustedStart.setDate(adjustedStart.getDate() + 1)
    }
    if (!includeEndDate) {
      adjustedEnd.setDate(adjustedEnd.getDate() - 1)
    }

    if (adjustedStart > adjustedEnd) {
      setResult({
        totalDays: 0,
        workingDays: 0,
        weekendDays: 0,
        holidayDays: 0,
        workingHours: calculateHours ? 0 : null,
      })
      return
    }

    let totalDays = 0
    let workingDays = 0
    let weekendDays = 0
    let holidayDays = 0

    const holidaySet = new Set(holidays)
    const currentDate = new Date(adjustedStart)

    while (currentDate <= adjustedEnd) {
      totalDays++
      const dayOfWeek = currentDate.getDay()
      const dateString = currentDate.toISOString().split("T")[0]

      const isSaturday = dayOfWeek === 6
      const isSunday = dayOfWeek === 0
      const isHoliday = holidaySet.has(dateString)

      const isWeekend = (excludeSaturday && isSaturday) || (excludeSunday && isSunday)

      if (isWeekend) {
        weekendDays++
      } else if (isHoliday) {
        holidayDays++
      } else {
        workingDays++
      }

      currentDate.setDate(currentDate.getDate() + 1)
    }

    const hours = Number.parseFloat(hoursPerDay) || 8

    setResult({
      totalDays,
      workingDays,
      weekendDays,
      holidayDays,
      workingHours: calculateHours ? workingDays * hours : null,
    })
  }

  const handleReset = () => {
    setStartDate("")
    setEndDate("")
    setIncludeStartDate(true)
    setIncludeEndDate(true)
    setExcludeSaturday(true)
    setExcludeSunday(true)
    setHolidays([])
    setNewHoliday("")
    setHoursPerDay("8")
    setCalculateHours(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Working Days: ${result.workingDays} days${result.workingHours ? ` (${result.workingHours} hours)` : ""}\nTotal Days: ${result.totalDays}\nWeekend Days: ${result.weekendDays}\nHolidays: ${result.holidayDays}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Working Days Calculation",
          text: `Working Days: ${result.workingDays} days${result.workingHours ? ` (${result.workingHours} hours)` : ""}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/time-date">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Time & Date
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-50 text-cyan-600">
                    <Briefcase className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Working Days Calculator</CardTitle>
                    <CardDescription>Calculate business days between dates</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Date Inputs */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">End Date</Label>
                    <Input id="endDate" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                  </div>
                </div>

                {/* Include Options */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <Label htmlFor="includeStart" className="text-sm cursor-pointer">
                      Include start date
                    </Label>
                    <Switch id="includeStart" checked={includeStartDate} onCheckedChange={setIncludeStartDate} />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <Label htmlFor="includeEnd" className="text-sm cursor-pointer">
                      Include end date
                    </Label>
                    <Switch id="includeEnd" checked={includeEndDate} onCheckedChange={setIncludeEndDate} />
                  </div>
                </div>

                {/* Weekend Selection */}
                <div className="space-y-2">
                  <Label>Exclude Weekends</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <Label htmlFor="excludeSaturday" className="text-sm cursor-pointer">
                        Saturday
                      </Label>
                      <Switch id="excludeSaturday" checked={excludeSaturday} onCheckedChange={setExcludeSaturday} />
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <Label htmlFor="excludeSunday" className="text-sm cursor-pointer">
                        Sunday
                      </Label>
                      <Switch id="excludeSunday" checked={excludeSunday} onCheckedChange={setExcludeSunday} />
                    </div>
                  </div>
                </div>

                {/* Holidays */}
                <div className="space-y-2">
                  <Label>Public Holidays (Optional)</Label>
                  <div className="flex gap-2">
                    <Input
                      type="date"
                      value={newHoliday}
                      onChange={(e) => setNewHoliday(e.target.value)}
                      min={startDate}
                      max={endDate}
                    />
                    <Button variant="outline" size="icon" onClick={addHoliday} disabled={!newHoliday}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  {holidays.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {holidays.map((holiday) => (
                        <div
                          key={holiday}
                          className="flex items-center gap-1 px-2 py-1 rounded-md bg-cyan-50 text-cyan-700 text-sm"
                        >
                          <span>{formatDate(holiday)}</span>
                          <button
                            onClick={() => removeHoliday(holiday)}
                            className="hover:text-cyan-900 transition-colors"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Working Hours */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <Label htmlFor="calculateHours" className="text-sm cursor-pointer">
                    Calculate working hours
                  </Label>
                  <Switch id="calculateHours" checked={calculateHours} onCheckedChange={setCalculateHours} />
                </div>

                {calculateHours && (
                  <div className="space-y-2">
                    <Label htmlFor="hoursPerDay">Hours per working day</Label>
                    <Input
                      id="hoursPerDay"
                      type="number"
                      placeholder="8"
                      value={hoursPerDay}
                      onChange={(e) => setHoursPerDay(e.target.value)}
                      min="1"
                      max="24"
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWorkingDays} className="w-full" size="lg">
                  Calculate Working Days
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-cyan-50 border-cyan-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Working Days</p>
                      <p className="text-5xl font-bold text-cyan-600 mb-2">{result.workingDays}</p>
                      <p className="text-lg font-semibold text-cyan-600">
                        {result.workingDays === 1 ? "business day" : "business days"}
                      </p>
                      {result.workingHours !== null && (
                        <p className="text-sm text-muted-foreground mt-1">({result.workingHours} working hours)</p>
                      )}
                    </div>

                    {/* Breakdown Toggle */}
                    <button
                      onClick={() => setShowBreakdown(!showBreakdown)}
                      className="w-full mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showBreakdown ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Breakdown
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Breakdown
                        </>
                      )}
                    </button>

                    {showBreakdown && (
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between p-2 rounded bg-white/60">
                          <span className="text-muted-foreground">Total calendar days:</span>
                          <span className="font-medium">{result.totalDays}</span>
                        </div>
                        <div className="flex justify-between p-2 rounded bg-white/60">
                          <span className="text-muted-foreground">Weekend days:</span>
                          <span className="font-medium text-orange-600">-{result.weekendDays}</span>
                        </div>
                        <div className="flex justify-between p-2 rounded bg-white/60">
                          <span className="text-muted-foreground">Holiday days:</span>
                          <span className="font-medium text-purple-600">-{result.holidayDays}</span>
                        </div>
                        <div className="flex justify-between p-2 rounded bg-cyan-100 font-semibold">
                          <span>Working days:</span>
                          <span className="text-cyan-700">{result.workingDays}</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Reference</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-cyan-50 border border-cyan-200">
                      <span className="font-medium text-cyan-700">Standard Work Week</span>
                      <span className="text-sm text-cyan-600">Mon-Fri (5 days)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">6-Day Work Week</span>
                      <span className="text-sm text-orange-600">Mon-Sat (6 days)</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Typical Year</span>
                      <span className="text-sm text-purple-600">~260 working days</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Average Month</span>
                      <span className="text-sm text-green-600">~22 working days</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">Working Days = Total Days - Weekends - Holidays</p>
                  </div>
                  <p>
                    Working hours can be calculated by multiplying working days by hours per day (default: 8 hours).
                  </p>
                </CardContent>
              </Card>

              {/* Disclaimer */}
              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <Info className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        Working day calculations depend on selected weekends and holidays and may vary by region and
                        organization. Always verify with your local calendar and company policies.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What Are Working Days?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Working days, also known as business days or weekdays, are the days of the week during which most
                  businesses and government offices operate. In most Western countries, this typically includes Monday
                  through Friday, excluding Saturday and Sunday. However, the definition of working days can vary
                  significantly depending on the country, culture, and industry.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, in many Middle Eastern countries, the weekend falls on Friday and Saturday, making Sunday
                  through Thursday the standard working days. Some industries, such as healthcare, retail, and
                  hospitality, operate seven days a week but may still observe certain days as official business days
                  for administrative purposes.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Why Calculate Working Days?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Calculating working days is essential for many personal and professional purposes:
                </p>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Project Planning</h4>
                    <p className="text-blue-700 text-sm">
                      Accurately estimate project timelines and delivery dates by accounting for weekends and holidays.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Payroll & HR</h4>
                    <p className="text-green-700 text-sm">
                      Calculate wages, vacation days, and leave entitlements based on actual working days.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Legal Deadlines</h4>
                    <p className="text-purple-700 text-sm">
                      Many legal and contractual deadlines are specified in business days rather than calendar days.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Shipping & Delivery</h4>
                    <p className="text-orange-700 text-sm">
                      Estimate delivery dates for shipments that only process on business days.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5 text-primary" />
                  <CardTitle>Public Holidays and Regional Variations</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Public holidays significantly impact working day calculations. Each country has its own set of
                  national holidays, and many regions have additional local or state holidays. Some common categories
                  include:
                </p>
                <ul className="mt-4 space-y-2 text-muted-foreground">
                  <li>
                    <strong>National holidays:</strong> Independence Day, Republic Day, National Day
                  </li>
                  <li>
                    <strong>Religious holidays:</strong> Christmas, Easter, Eid, Diwali, Hanukkah
                  </li>
                  <li>
                    <strong>Cultural observances:</strong> New Year's Day, Labor Day, Thanksgiving
                  </li>
                  <li>
                    <strong>Regional holidays:</strong> State foundation days, local festivals
                  </li>
                </ul>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For accurate calculations, it's important to include all relevant holidays for your specific location
                  and industry. Some businesses also observe additional company holidays or floating holidays that
                  employees can use at their discretion.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
