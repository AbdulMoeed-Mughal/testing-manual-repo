"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Info,
  AlertTriangle,
  TrendingDown,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { type Currency, formatCurrency, currencySymbols } from "@/lib/currency"
import { CurrencySelector } from "@/components/ui/currency-selector"

interface PurchasingPowerResult {
  currentAmount: number
  futureValue: number
  purchasingPowerLoss: number
  percentageLoss: number
  equivalentAmount: number
  yearlyBreakdown: YearlyBreakdown[]
}

interface YearlyBreakdown {
  year: number
  value: number
  cumulativeLoss: number
  percentageLoss: number
}

export function PurchasingPowerCalculator() {
  const [currency, setCurrency] = useState<Currency>("USD")
  const [currentAmount, setCurrentAmount] = useState("")
  const [inflationRate, setInflationRate] = useState("")
  const [timePeriod, setTimePeriod] = useState("")
  const [compoundingFrequency, setCompoundingFrequency] = useState("annual")
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [result, setResult] = useState<PurchasingPowerResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const getCompoundingPeriods = (frequency: string): number => {
    switch (frequency) {
      case "monthly":
        return 12
      case "quarterly":
        return 4
      case "semi-annual":
        return 2
      case "annual":
      default:
        return 1
    }
  }

  const calculatePurchasingPower = () => {
    setError("")
    setResult(null)

    const amount = Number.parseFloat(currentAmount)
    const inflation = Number.parseFloat(inflationRate)
    const years = Number.parseFloat(timePeriod)

    if (isNaN(amount) || amount <= 0) {
      setError("Please enter a valid amount greater than 0")
      return
    }
    if (isNaN(inflation) || inflation < 0 || inflation > 100) {
      setError("Please enter a valid inflation rate between 0 and 100")
      return
    }
    if (isNaN(years) || years <= 0 || years > 100) {
      setError("Please enter a valid time period between 1 and 100 years")
      return
    }

    const n = getCompoundingPeriods(compoundingFrequency)
    const rate = inflation / 100

    // Calculate future value in today's terms (purchasing power)
    // Future Value = Current Amount / (1 + r/n)^(n*t)
    const futureValue = amount / Math.pow(1 + rate / n, n * years)

    const purchasingPowerLoss = amount - futureValue
    const percentageLoss = (purchasingPowerLoss / amount) * 100

    // Calculate equivalent amount needed in the future to maintain purchasing power
    const equivalentAmount = amount * Math.pow(1 + rate / n, n * years)

    // Generate yearly breakdown
    const yearlyBreakdown: YearlyBreakdown[] = []
    for (let year = 1; year <= Math.min(years, 50); year++) {
      const value = amount / Math.pow(1 + rate / n, n * year)
      const cumulativeLoss = amount - value
      const yearPercentageLoss = (cumulativeLoss / amount) * 100
      yearlyBreakdown.push({
        year,
        value,
        cumulativeLoss,
        percentageLoss: yearPercentageLoss,
      })
    }

    setResult({
      currentAmount: amount,
      futureValue,
      purchasingPowerLoss,
      percentageLoss,
      equivalentAmount,
      yearlyBreakdown,
    })
  }

  const handleReset = () => {
    setCurrentAmount("")
    setInflationRate("")
    setTimePeriod("")
    setCompoundingFrequency("annual")
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Purchasing Power Analysis:
Current Amount: ${formatCurrency(result.currentAmount, currency)}
After ${timePeriod} years at ${inflationRate}% inflation:
- Purchasing Power: ${formatCurrency(result.futureValue, currency)}
- Value Lost: ${formatCurrency(result.purchasingPowerLoss, currency)} (${result.percentageLoss.toFixed(1)}%)
- Equivalent Needed: ${formatCurrency(result.equivalentAmount, currency)}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Purchasing Power Calculator Result",
          text: `${formatCurrency(result.currentAmount, currency)} today will have the purchasing power of ${formatCurrency(result.futureValue, currency)} in ${timePeriod} years at ${inflationRate}% inflation.`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const getImpactCategory = (percentageLoss: number) => {
    if (percentageLoss < 10)
      return { label: "Minimal Impact", color: "text-green-600", bgColor: "bg-green-50 border-green-200" }
    if (percentageLoss < 25)
      return { label: "Moderate Impact", color: "text-yellow-600", bgColor: "bg-yellow-50 border-yellow-200" }
    if (percentageLoss < 50)
      return { label: "Significant Impact", color: "text-orange-600", bgColor: "bg-orange-50 border-orange-200" }
    return { label: "Severe Impact", color: "text-red-600", bgColor: "bg-red-50 border-red-200" }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingDown className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Purchasing Power Calculator</CardTitle>
                    <CardDescription>Calculate how inflation erodes your money's value</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <CurrencySelector value={currency} onChange={setCurrency} />
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Amount */}
                <div className="space-y-2">
                  <Label htmlFor="currentAmount">Current Amount ({currencySymbols[currency]})</Label>
                  <Input
                    id="currentAmount"
                    type="number"
                    placeholder="Enter current amount"
                    value={currentAmount}
                    onChange={(e) => setCurrentAmount(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Inflation Rate */}
                <div className="space-y-2">
                  <Label htmlFor="inflationRate">Inflation Rate (%)</Label>
                  <Input
                    id="inflationRate"
                    type="number"
                    placeholder="Enter annual inflation rate"
                    value={inflationRate}
                    onChange={(e) => setInflationRate(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Time Period */}
                <div className="space-y-2">
                  <Label htmlFor="timePeriod">Time Period (Years)</Label>
                  <Input
                    id="timePeriod"
                    type="number"
                    placeholder="Enter number of years"
                    value={timePeriod}
                    onChange={(e) => setTimePeriod(e.target.value)}
                    min="1"
                    max="100"
                    step="1"
                  />
                </div>

                {/* Advanced Options */}
                <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="w-full justify-between">
                      Advanced Options
                      {showAdvanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="compoundingFrequency">Compounding Frequency</Label>
                      <Select value={compoundingFrequency} onValueChange={setCompoundingFrequency}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="annual">Annual</SelectItem>
                          <SelectItem value="semi-annual">Semi-Annual</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CollapsibleContent>
                </Collapsible>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculatePurchasingPower} className="w-full" size="lg">
                  Calculate Purchasing Power
                </Button>

                {/* Result */}
                {result && (
                  <div
                    className={`p-4 rounded-xl border-2 ${getImpactCategory(result.percentageLoss).bgColor} transition-all duration-300`}
                  >
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Future Purchasing Power</p>
                      <p className={`text-4xl font-bold ${getImpactCategory(result.percentageLoss).color} mb-1`}>
                        {formatCurrency(result.futureValue, currency)}
                      </p>
                      <p className={`text-lg font-semibold ${getImpactCategory(result.percentageLoss).color}`}>
                        {getImpactCategory(result.percentageLoss).label}
                      </p>
                    </div>

                    {/* Visual Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Retained Value</span>
                        <span>Lost Value</span>
                      </div>
                      <div className="h-4 rounded-full overflow-hidden flex bg-gray-200">
                        <div
                          className="bg-green-500 transition-all duration-500"
                          style={{ width: `${100 - result.percentageLoss}%` }}
                        />
                        <div
                          className="bg-red-400 transition-all duration-500"
                          style={{ width: `${result.percentageLoss}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs mt-1">
                        <span className="text-green-600">{(100 - result.percentageLoss).toFixed(1)}%</span>
                        <span className="text-red-600">{result.percentageLoss.toFixed(1)}%</span>
                      </div>
                    </div>

                    {/* Summary Stats */}
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white/60 rounded-lg">
                        <p className="text-xs text-muted-foreground">Value Lost</p>
                        <p className="text-lg font-bold text-red-600">
                          {formatCurrency(result.purchasingPowerLoss, currency)}
                        </p>
                      </div>
                      <div className="p-3 bg-white/60 rounded-lg">
                        <p className="text-xs text-muted-foreground">To Maintain Value</p>
                        <p className="text-lg font-bold text-blue-600">
                          {formatCurrency(result.equivalentAmount, currency)}
                        </p>
                      </div>
                    </div>

                    {/* Yearly Breakdown */}
                    <Collapsible open={showBreakdown} onOpenChange={setShowBreakdown}>
                      <CollapsibleTrigger asChild>
                        <Button variant="outline" size="sm" className="w-full bg-transparent">
                          {showBreakdown ? "Hide" : "Show"} Yearly Breakdown
                          {showBreakdown ? (
                            <ChevronUp className="ml-2 h-4 w-4" />
                          ) : (
                            <ChevronDown className="ml-2 h-4 w-4" />
                          )}
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-3">
                        <div className="max-h-64 overflow-y-auto rounded-lg border bg-white">
                          <table className="w-full text-sm">
                            <thead className="bg-muted sticky top-0">
                              <tr>
                                <th className="text-left p-2">Year</th>
                                <th className="text-right p-2">Value</th>
                                <th className="text-right p-2">Loss %</th>
                              </tr>
                            </thead>
                            <tbody>
                              {result.yearlyBreakdown.map((row) => (
                                <tr key={row.year} className="border-t">
                                  <td className="p-2">{row.year}</td>
                                  <td className="text-right p-2">{formatCurrency(row.value, currency)}</td>
                                  <td className="text-right p-2 text-red-600">-{row.percentageLoss.toFixed(1)}%</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Impact Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Minimal Impact</span>
                      <span className="text-sm text-green-600">{"< 10% loss"}</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate Impact</span>
                      <span className="text-sm text-yellow-600">10% – 25% loss</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <span className="font-medium text-orange-700">Significant Impact</span>
                      <span className="text-sm text-orange-600">25% – 50% loss</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Severe Impact</span>
                      <span className="text-sm text-red-600">{"≥ 50% loss"}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Purchasing Power Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground">PV = A ÷ (1 + r/n)^(n×t)</p>
                  </div>
                  <div className="space-y-2">
                    <p>
                      <strong>PV</strong> = Future purchasing power
                    </p>
                    <p>
                      <strong>A</strong> = Current amount
                    </p>
                    <p>
                      <strong>r</strong> = Annual inflation rate
                    </p>
                    <p>
                      <strong>n</strong> = Compounding periods per year
                    </p>
                    <p>
                      <strong>t</strong> = Time in years
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Purchasing Power?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Purchasing power refers to the quantity of goods and services that a unit of currency can buy. Over
                  time, inflation erodes purchasing power, meaning the same amount of money will buy fewer goods and
                  services in the future. Understanding how inflation affects your money is crucial for financial
                  planning, retirement savings, and investment decisions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, if you have $10,000 today and inflation averages 3% per year, in 20 years that money will
                  only have the purchasing power of approximately $5,537 in today's terms. This doesn't mean you'll have
                  less money, but what you can buy with it will be significantly reduced.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5 text-primary" />
                  <CardTitle>How to Use This Calculator</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  This calculator helps you understand how inflation will impact your savings or a specific amount of
                  money over time. Enter the current amount you want to analyze, the expected annual inflation rate
                  (historical average is around 2-3% for developed economies), and the time period you're planning for.
                </p>
                <div className="mt-4 space-y-3">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Planning for Retirement</h4>
                    <p className="text-blue-700 text-sm">
                      Use this calculator to understand how much your retirement savings will actually be worth when you
                      retire. This helps you set more realistic savings goals.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Investment Decisions</h4>
                    <p className="text-green-700 text-sm">
                      Compare the "equivalent needed" amount with your investment returns to ensure your investments are
                      beating inflation and actually growing your wealth.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-amber-800">Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 text-sm leading-relaxed">
                  Purchasing power calculations are estimates based on entered values and assumed inflation rates.
                  Actual purchasing power may vary due to changing economic conditions, regional price differences, and
                  sector-specific inflation rates (e.g., healthcare inflation often exceeds general inflation). Consult
                  a financial advisor for personalized guidance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
