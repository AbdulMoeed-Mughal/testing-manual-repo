"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Target,
  Info,
  TrendingUp,
  Calendar,
  PiggyBank,
  AlertTriangle,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type ContributionFrequency = "monthly" | "weekly"

interface SavingsResult {
  requiredSavings: number
  totalContributions: number
  investmentGrowth: number
  remainingAmount: number
  totalPeriods: number
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
]

export function SavingsGoalCalculator() {
  const [currency, setCurrency] = useState("USD")
  const [targetAmount, setTargetAmount] = useState("")
  const [currentSavings, setCurrentSavings] = useState("")
  const [years, setYears] = useState("")
  const [months, setMonths] = useState("")
  const [returnRate, setReturnRate] = useState("")
  const [frequency, setFrequency] = useState<ContributionFrequency>("monthly")
  const [result, setResult] = useState<SavingsResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")

  const currencySymbol = currencies.find((c) => c.code === currency)?.symbol || "$"

  const formatCurrency = (value: number) => {
    if (currency === "INR") {
      if (value >= 10000000) return `${currencySymbol}${(value / 10000000).toFixed(2)} Cr`
      if (value >= 100000) return `${currencySymbol}${(value / 100000).toFixed(2)} L`
      return `${currencySymbol}${value.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`
    }
    if (value >= 1000000000) return `${currencySymbol}${(value / 1000000000).toFixed(2)}B`
    if (value >= 1000000) return `${currencySymbol}${(value / 1000000).toFixed(2)}M`
    if (value >= 1000) return `${currencySymbol}${(value / 1000).toFixed(2)}K`
    return `${currencySymbol}${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`
  }

  const calculateSavings = () => {
    setError("")
    setResult(null)

    const target = Number.parseFloat(targetAmount)
    const current = Number.parseFloat(currentSavings) || 0
    const yearsNum = Number.parseFloat(years) || 0
    const monthsNum = Number.parseFloat(months) || 0
    const rate = Number.parseFloat(returnRate) || 0

    if (isNaN(target) || target <= 0) {
      setError("Please enter a valid target amount greater than 0")
      return
    }

    if (current >= target) {
      setError("Target amount must be greater than current savings")
      return
    }

    if (rate < 0) {
      setError("Return rate cannot be negative")
      return
    }

    const totalMonths = yearsNum * 12 + monthsNum
    if (totalMonths <= 0) {
      setError("Time period must be greater than 0")
      return
    }

    const remaining = target - current

    // Calculate based on frequency
    const periodsPerYear = frequency === "monthly" ? 12 : 52
    const totalPeriods = frequency === "monthly" ? totalMonths : totalMonths * (52 / 12)

    // Periodic interest rate
    const periodicRate = rate / 100 / periodsPerYear

    let requiredSavings: number

    if (rate === 0 || periodicRate === 0) {
      // No interest - simple division
      requiredSavings = remaining / totalPeriods
    } else {
      // PMT = R × r ÷ [ (1 + r)^n − 1 ]
      const factor = Math.pow(1 + periodicRate, totalPeriods) - 1
      requiredSavings = (remaining * periodicRate) / factor
    }

    // Calculate total contributions
    const totalContributions = requiredSavings * totalPeriods

    // Investment growth
    const investmentGrowth = target - current - totalContributions

    setResult({
      requiredSavings,
      totalContributions,
      investmentGrowth: Math.max(0, investmentGrowth),
      remainingAmount: remaining,
      totalPeriods: Math.round(totalPeriods),
    })
  }

  const handleReset = () => {
    setTargetAmount("")
    setCurrentSavings("")
    setYears("")
    setMonths("")
    setReturnRate("")
    setFrequency("monthly")
    setResult(null)
    setError("")
    setCopied(false)
  }

  const handleCopy = async () => {
    if (result) {
      const frequencyLabel = frequency === "monthly" ? "month" : "week"
      await navigator.clipboard.writeText(
        `Savings Goal: ${formatCurrency(Number.parseFloat(targetAmount))} | Required ${frequencyLabel}ly savings: ${formatCurrency(result.requiredSavings)} | Total contributions: ${formatCurrency(result.totalContributions)} | Investment growth: ${formatCurrency(result.investmentGrowth)}`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const frequencyLabel = frequency === "monthly" ? "month" : "week"
      try {
        await navigator.share({
          title: "Savings Goal Calculator Result",
          text: `To reach my savings goal of ${formatCurrency(Number.parseFloat(targetAmount))}, I need to save ${formatCurrency(result.requiredSavings)} per ${frequencyLabel}!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  // Calculate progress percentage
  const progressPercent = result
    ? Math.min(100, ((Number.parseFloat(currentSavings) || 0) / Number.parseFloat(targetAmount)) * 100)
    : 0

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/finance-money">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Finance & Money
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <Target className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Savings Goal Calculator</CardTitle>
                    <CardDescription>Calculate required savings to reach your goal</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    {currencies.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} ({c.symbol})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Frequency Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Contribution Frequency</span>
                  <button
                    onClick={() => setFrequency(frequency === "monthly" ? "weekly" : "monthly")}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        frequency === "weekly" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        frequency === "monthly" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Monthly
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        frequency === "weekly" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Weekly
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Target Amount */}
                <div className="space-y-2">
                  <Label htmlFor="target">Target Savings Amount ({currencySymbol})</Label>
                  <Input
                    id="target"
                    type="number"
                    placeholder="Enter your savings goal"
                    value={targetAmount}
                    onChange={(e) => setTargetAmount(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Current Savings */}
                <div className="space-y-2">
                  <Label htmlFor="current">Current Savings ({currencySymbol})</Label>
                  <Input
                    id="current"
                    type="number"
                    placeholder="Enter current savings (optional)"
                    value={currentSavings}
                    onChange={(e) => setCurrentSavings(e.target.value)}
                    min="0"
                    step="100"
                  />
                </div>

                {/* Time Period */}
                <div className="space-y-2">
                  <Label>Time Period</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Input
                        type="number"
                        placeholder="Years"
                        value={years}
                        onChange={(e) => setYears(e.target.value)}
                        min="0"
                      />
                    </div>
                    <div>
                      <Input
                        type="number"
                        placeholder="Months"
                        value={months}
                        onChange={(e) => setMonths(e.target.value)}
                        min="0"
                        max="11"
                      />
                    </div>
                  </div>
                </div>

                {/* Expected Return Rate */}
                <div className="space-y-2">
                  <Label htmlFor="rate">Expected Annual Return (%)</Label>
                  <Input
                    id="rate"
                    type="number"
                    placeholder="Enter expected return rate"
                    value={returnRate}
                    onChange={(e) => setReturnRate(e.target.value)}
                    min="0"
                    max="50"
                    step="0.1"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateSavings} className="w-full" size="lg">
                  Calculate Required Savings
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-green-50 border-green-200 transition-all duration-300">
                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Current Progress</span>
                        <span className="font-medium text-green-700">{progressPercent.toFixed(1)}%</span>
                      </div>
                      <div className="h-3 bg-green-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-500 rounded-full transition-all duration-500"
                          style={{ width: `${progressPercent}%` }}
                        />
                      </div>
                    </div>

                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        Required {frequency === "monthly" ? "Monthly" : "Weekly"} Savings
                      </p>
                      <p className="text-4xl font-bold text-green-600 mb-2">{formatCurrency(result.requiredSavings)}</p>
                      <p className="text-sm text-green-700">
                        for {result.totalPeriods} {frequency === "monthly" ? "months" : "weeks"}
                      </p>
                    </div>

                    {/* Breakdown */}
                    <div className="grid grid-cols-2 gap-3 mt-4">
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Total Contributions</p>
                        <p className="font-semibold text-foreground">{formatCurrency(result.totalContributions)}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Investment Growth</p>
                        <p className="font-semibold text-green-600">{formatCurrency(result.investmentGrowth)}</p>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold">
                      1
                    </div>
                    <p>Enter your target savings goal and current savings</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold">
                      2
                    </div>
                    <p>Set your time frame and expected return rate</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-green-100 text-green-600 text-xs font-bold">
                      3
                    </div>
                    <p>Get your required periodic savings amount</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Formula Used</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs">PMT = R × r ÷ [(1 + r)ⁿ − 1]</p>
                  </div>
                  <p>
                    <strong>R</strong> = Remaining amount (Target - Current)
                    <br />
                    <strong>r</strong> = Periodic interest rate
                    <br />
                    <strong>n</strong> = Number of periods
                  </p>
                  <p className="text-xs text-muted-foreground">
                    When return rate is 0, simple division is used: PMT = R ÷ n
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="text-sm text-amber-800">
                      <p className="font-medium mb-1">Disclaimer</p>
                      <p>
                        This calculator provides estimates only; actual returns may vary based on market conditions and
                        investment choices.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Savings Goal?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A savings goal is a specific financial target that you want to achieve within a defined timeframe.
                  Whether you're saving for a down payment on a house, building an emergency fund, planning a vacation,
                  or preparing for retirement, having a clear savings goal gives your financial planning direction and
                  purpose. Setting concrete goals transforms abstract desires into actionable plans with measurable
                  milestones.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The savings goal calculator helps you determine exactly how much you need to set aside
                  regularly—whether monthly or weekly—to reach your target amount. By factoring in your current savings,
                  expected investment returns, and time horizon, it provides a realistic roadmap to achieve your
                  financial objectives. Understanding these numbers empowers you to make informed decisions about your
                  spending and saving habits.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <CardTitle>The Power of Compound Growth</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  One of the most powerful concepts in personal finance is compound growth—the phenomenon where your
                  investment returns generate their own returns over time. When you invest your savings in
                  interest-bearing accounts, stocks, bonds, or mutual funds, the returns you earn are reinvested,
                  creating a snowball effect that accelerates your wealth accumulation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  This calculator accounts for compound growth by using the expected annual return rate you provide.
                  Even a modest return of 5-7% annually can significantly reduce the amount you need to save each month
                  compared to simply stashing cash under your mattress. For example, to save $100,000 in 10 years with
                  0% return, you'd need to save about $833 monthly. With a 7% annual return, that drops to approximately
                  $580 monthly—a difference of over $250 per month or $30,000 in total contributions.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  The longer your time horizon, the more compound growth works in your favor. Starting early, even with
                  smaller amounts, often yields better results than starting late with larger contributions. This is why
                  financial advisors consistently emphasize the importance of beginning your savings journey as soon as
                  possible.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <CardTitle>Choosing the Right Time Frame</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  The time frame you select for your savings goal dramatically impacts how much you need to save
                  regularly. Shorter time frames require larger periodic contributions, while longer horizons allow
                  smaller amounts to grow into substantial sums. When setting your timeline, consider both your goal's
                  urgency and your capacity to save consistently.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For short-term goals (less than 3 years), such as building an emergency fund or saving for a vacation,
                  it's wise to use conservative return assumptions (1-3%) since you'll likely keep funds in safer, more
                  liquid investments like high-yield savings accounts or money market funds. For medium-term goals (3-10
                  years), like a home down payment or a child's education fund, you might assume moderate returns (4-6%)
                  with a balanced investment approach.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Long-term goals (10+ years), such as retirement savings, can potentially benefit from higher-return
                  investments like diversified stock portfolios, where historical average returns have been around 7-10%
                  annually. However, always remember that past performance doesn't guarantee future results, and higher
                  potential returns come with higher volatility and risk.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PiggyBank className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Reaching Your Savings Goals</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Successfully reaching your savings goals requires more than just knowing how much to save—it demands
                  consistent action and smart strategies. Here are proven approaches to help you stay on track:
                </p>
                <div className="mt-6 space-y-4">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Automate Your Savings</h4>
                    <p className="text-green-700 text-sm">
                      Set up automatic transfers from your checking account to your savings or investment account on
                      payday. This "pay yourself first" approach ensures you save before you have a chance to spend,
                      making saving effortless and consistent.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Start Small, Scale Up</h4>
                    <p className="text-blue-700 text-sm">
                      If the calculated amount feels overwhelming, start with what you can afford and gradually increase
                      your contributions. Even small increases of 1% every few months can make a significant difference
                      over time without straining your budget.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Review and Adjust Regularly</h4>
                    <p className="text-purple-700 text-sm">
                      Life circumstances change—income increases, expenses fluctuate, and priorities shift. Review your
                      savings goals quarterly and adjust your contributions accordingly. Windfalls like bonuses, tax
                      refunds, or gifts can accelerate your progress significantly.
                    </p>
                  </div>
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <h4 className="font-semibold text-amber-800 mb-2">Track Your Progress</h4>
                    <p className="text-amber-700 text-sm">
                      Monitoring your progress provides motivation and helps identify when adjustments are needed. Use
                      budgeting apps, spreadsheets, or your bank's tools to visualize how close you are to your goal.
                      Celebrating milestones keeps you engaged and committed.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
