"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Calculator,
  Info,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

interface PartialDerivativeResult {
  derivative: string
  variable: string
  order: number
  steps: string[]
  gradient?: string[]
}

export function PartialDerivativeCalculator() {
  const [functionInput, setFunctionInput] = useState("")
  const [variable, setVariable] = useState("x")
  const [order, setOrder] = useState("1")
  const [showSteps, setShowSteps] = useState(true)
  const [showGradient, setShowGradient] = useState(false)
  const [result, setResult] = useState<PartialDerivativeResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  // Parse and tokenize function
  const tokenize = (expr: string): string[] => {
    const tokens: string[] = []
    let i = 0
    while (i < expr.length) {
      if (/\s/.test(expr[i])) {
        i++
        continue
      }
      if (/[a-zA-Z]/.test(expr[i])) {
        let name = ""
        while (i < expr.length && /[a-zA-Z0-9]/.test(expr[i])) {
          name += expr[i++]
        }
        tokens.push(name)
      } else if (/[0-9.]/.test(expr[i])) {
        let num = ""
        while (i < expr.length && /[0-9.]/.test(expr[i])) {
          num += expr[i++]
        }
        tokens.push(num)
      } else {
        tokens.push(expr[i++])
      }
    }
    return tokens
  }

  // Simple symbolic differentiation for common patterns
  const differentiateSymbolic = (
    func: string,
    varName: string,
    orderNum: number,
  ): { derivative: string; steps: string[] } => {
    const steps: string[] = []
    let currentExpr = func.trim()

    for (let o = 1; o <= orderNum; o++) {
      steps.push(`Order ${o} differentiation with respect to ${varName}:`)

      // Normalize the expression
      const normalized = currentExpr.replace(/\s+/g, "").replace(/\*\*/g, "^")

      // Split by + and - while keeping the operators
      const terms: { sign: string; term: string }[] = []
      let currentTerm = ""
      let currentSign = "+"
      let depth = 0

      for (let i = 0; i < normalized.length; i++) {
        const char = normalized[i]
        if (char === "(") depth++
        if (char === ")") depth--

        if (depth === 0 && (char === "+" || char === "-") && i > 0) {
          if (currentTerm) {
            terms.push({ sign: currentSign, term: currentTerm })
          }
          currentSign = char
          currentTerm = ""
        } else {
          currentTerm += char
        }
      }
      if (currentTerm) {
        terms.push({ sign: currentSign, term: currentTerm })
      }

      const derivedTerms: string[] = []

      for (const { sign, term } of terms) {
        const derived = differentiateTerm(term, varName, steps)
        if (derived !== "0") {
          derivedTerms.push(sign === "-" ? `-${derived}` : derived)
        }
      }

      if (derivedTerms.length === 0) {
        currentExpr = "0"
      } else {
        currentExpr = derivedTerms.join(" + ").replace(/\+ -/g, "- ")
      }

      steps.push(`Result after order ${o}: ${currentExpr}`)
    }

    return { derivative: currentExpr, steps }
  }

  const differentiateTerm = (term: string, varName: string, steps: string[]): string => {
    // Check if term contains the variable
    if (!term.includes(varName)) {
      steps.push(`  d/d${varName}(${term}) = 0 (constant with respect to ${varName})`)
      return "0"
    }

    // Handle x^n pattern
    const powerMatch = term.match(new RegExp(`^([\\d.]*)?\\*?${varName}\\^([\\d.]+)$`))
    if (powerMatch) {
      const coef = powerMatch[1] ? Number.parseFloat(powerMatch[1]) : 1
      const exp = Number.parseFloat(powerMatch[2])
      const newCoef = coef * exp
      const newExp = exp - 1

      if (newExp === 0) {
        steps.push(`  d/d${varName}(${term}) = ${newCoef} (power rule)`)
        return `${newCoef}`
      } else if (newExp === 1) {
        steps.push(`  d/d${varName}(${term}) = ${newCoef}${varName} (power rule)`)
        return `${newCoef}${varName}`
      } else {
        steps.push(`  d/d${varName}(${term}) = ${newCoef}${varName}^${newExp} (power rule)`)
        return `${newCoef}${varName}^${newExp}`
      }
    }

    // Handle coefficient * variable pattern (ax)
    const linearMatch = term.match(new RegExp(`^([\\d.]+)?\\*?${varName}$`))
    if (linearMatch) {
      const coef = linearMatch[1] ? Number.parseFloat(linearMatch[1]) : 1
      steps.push(`  d/d${varName}(${term}) = ${coef} (linear rule)`)
      return `${coef}`
    }

    // Handle just the variable
    if (term === varName) {
      steps.push(`  d/d${varName}(${varName}) = 1`)
      return "1"
    }

    // Handle sin(x) pattern
    const sinMatch = term.match(/^([\d.]*)?\*?sin\$$([^)]+)\$$$/)
    if (sinMatch) {
      const coef = sinMatch[1] ? Number.parseFloat(sinMatch[1]) : 1
      const inner = sinMatch[2]
      if (inner === varName) {
        steps.push(`  d/d${varName}(${term}) = ${coef === 1 ? "" : coef}cos(${varName}) (trig rule)`)
        return `${coef === 1 ? "" : coef}cos(${varName})`
      }
    }

    // Handle cos(x) pattern
    const cosMatch = term.match(/^([\d.]*)?\*?cos\$$([^)]+)\$$$/)
    if (cosMatch) {
      const coef = cosMatch[1] ? Number.parseFloat(cosMatch[1]) : 1
      const inner = cosMatch[2]
      if (inner === varName) {
        steps.push(`  d/d${varName}(${term}) = ${coef === 1 ? "-" : -coef}sin(${varName}) (trig rule)`)
        return `${coef === 1 ? "-" : -coef}sin(${varName})`
      }
    }

    // Handle e^x pattern
    const expMatch = term.match(new RegExp(`^([\\d.]*)?\\*?e\\^${varName}$`))
    if (expMatch) {
      const coef = expMatch[1] ? Number.parseFloat(expMatch[1]) : 1
      steps.push(`  d/d${varName}(${term}) = ${coef === 1 ? "" : coef}e^${varName} (exponential rule)`)
      return `${coef === 1 ? "" : coef}e^${varName}`
    }

    // Handle ln(x) pattern
    const lnMatch = term.match(new RegExp(`^([\\d.]*)?\\*?ln\$$${varName}\$$$`))
    if (lnMatch) {
      const coef = lnMatch[1] ? Number.parseFloat(lnMatch[1]) : 1
      steps.push(`  d/d${varName}(${term}) = ${coef === 1 ? "" : coef}/${varName} (logarithm rule)`)
      return `${coef === 1 ? "" : `${coef}/`}${varName}`
    }

    // Handle xy, xz, yz type products (partial derivative treats other vars as constants)
    const otherVars = ["x", "y", "z", "t", "u", "v", "w"].filter((v) => v !== varName)
    for (const otherVar of otherVars) {
      // Pattern: coefficient * var * otherVar
      const prodMatch =
        term.match(new RegExp(`^([\\d.]*)?\\*?${varName}\\*?${otherVar}$`)) ||
        term.match(new RegExp(`^([\\d.]*)?\\*?${otherVar}\\*?${varName}$`))
      if (prodMatch) {
        const coef = prodMatch[1] ? Number.parseFloat(prodMatch[1]) : 1
        steps.push(
          `  d/d${varName}(${term}) = ${coef === 1 ? "" : coef}${otherVar} (product with constant ${otherVar})`,
        )
        return `${coef === 1 ? "" : coef}${otherVar}`
      }

      // Pattern: var^n * otherVar
      const prodPowMatch = term.match(new RegExp(`^([\\d.]*)?\\*?${varName}\\^([\\d.]+)\\*?${otherVar}$`))
      if (prodPowMatch) {
        const coef = prodPowMatch[1] ? Number.parseFloat(prodPowMatch[1]) : 1
        const exp = Number.parseFloat(prodPowMatch[2])
        const newCoef = coef * exp
        const newExp = exp - 1

        if (newExp === 0) {
          steps.push(`  d/d${varName}(${term}) = ${newCoef}${otherVar} (power rule with constant)`)
          return `${newCoef}${otherVar}`
        } else if (newExp === 1) {
          steps.push(`  d/d${varName}(${term}) = ${newCoef}${varName}${otherVar} (power rule with constant)`)
          return `${newCoef}${varName}${otherVar}`
        } else {
          steps.push(`  d/d${varName}(${term}) = ${newCoef}${varName}^${newExp}${otherVar} (power rule with constant)`)
          return `${newCoef}${varName}^${newExp}${otherVar}`
        }
      }
    }

    // Handle x^2y, xy^2, xyz patterns
    const multiVarMatch = term.match(/^(\d*\.?\d*)?([xyz])(\^(\d+))?([xyz])(\^(\d+))?([xyz])?(\^(\d+))?$/)
    if (multiVarMatch) {
      steps.push(`  Differentiating multivariate term: ${term}`)
      // This is complex, return simplified form
      return `∂/∂${varName}(${term})`
    }

    // Default: return symbolic derivative notation
    steps.push(`  d/d${varName}(${term}) = ∂/∂${varName}(${term})`)
    return `∂/∂${varName}(${term})`
  }

  // Calculate gradient (all partial derivatives)
  const calculateGradient = (func: string): string[] => {
    const variables = ["x", "y", "z"].filter((v) => func.includes(v))
    return variables.map((v) => {
      const { derivative } = differentiateSymbolic(func, v, 1)
      return `∂f/∂${v} = ${derivative}`
    })
  }

  const calculate = () => {
    setError("")
    setResult(null)

    if (!functionInput.trim()) {
      setError("Please enter a function")
      return
    }

    try {
      const orderNum = Number.parseInt(order)
      const { derivative, steps } = differentiateSymbolic(functionInput, variable, orderNum)

      const gradient = showGradient ? calculateGradient(functionInput) : undefined

      setResult({
        derivative,
        variable,
        order: orderNum,
        steps,
        gradient,
      })
    } catch (err) {
      setError("Could not differentiate the function. Please check the syntax.")
    }
  }

  const handleReset = () => {
    setFunctionInput("")
    setVariable("x")
    setOrder("1")
    setShowGradient(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const orderStr = result.order === 1 ? "" : `^${result.order}`
      const text = `∂${orderStr}f/∂${result.variable}${orderStr} = ${result.derivative}`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        const orderStr = result.order === 1 ? "" : `^${result.order}`
        await navigator.share({
          title: "Partial Derivative Result",
          text: `f(${variable}) = ${functionInput}\n∂${orderStr}f/∂${result.variable}${orderStr} = ${result.derivative}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const formatOrderLabel = (orderNum: number): string => {
    if (orderNum === 1) return "∂f/∂" + variable
    return `∂^${orderNum}f/∂${variable}^${orderNum}`
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/math-geometry">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Math & Geometry
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                    <Calculator className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Partial Derivative Calculator</CardTitle>
                    <CardDescription>Calculate partial derivatives of multivariable functions</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Function Input */}
                <div className="space-y-2">
                  <Label htmlFor="function">Function f(x, y, z, ...)</Label>
                  <Input
                    id="function"
                    type="text"
                    placeholder="e.g., x^2 + 2xy + y^2 or sin(x) + cos(y)"
                    value={functionInput}
                    onChange={(e) => setFunctionInput(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Use ^ for powers, e.g., x^2. Supported: +, -, *, /, ^, sin, cos, tan, ln, e^x
                  </p>
                </div>

                {/* Variable Selection */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="variable">Variable</Label>
                    <Select value={variable} onValueChange={setVariable}>
                      <SelectTrigger id="variable">
                        <SelectValue placeholder="Select variable" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="x">x</SelectItem>
                        <SelectItem value="y">y</SelectItem>
                        <SelectItem value="z">z</SelectItem>
                        <SelectItem value="t">t</SelectItem>
                        <SelectItem value="u">u</SelectItem>
                        <SelectItem value="v">v</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="order">Derivative Order</Label>
                    <Select value={order} onValueChange={setOrder}>
                      <SelectTrigger id="order">
                        <SelectValue placeholder="Select order" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1st Order</SelectItem>
                        <SelectItem value="2">2nd Order</SelectItem>
                        <SelectItem value="3">3rd Order</SelectItem>
                        <SelectItem value="4">4th Order</SelectItem>
                        <SelectItem value="5">5th Order</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Options */}
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <Label htmlFor="gradient" className="cursor-pointer">
                    Calculate Gradient Vector
                  </Label>
                  <Switch id="gradient" checked={showGradient} onCheckedChange={setShowGradient} />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Partial Derivative
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-blue-50 border-blue-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">
                        {result.order === 1
                          ? "First"
                          : result.order === 2
                            ? "Second"
                            : result.order === 3
                              ? "Third"
                              : `${result.order}th`}{" "}
                        Partial Derivative
                      </p>
                      <p className="text-lg font-semibold text-blue-600 mb-2">{formatOrderLabel(result.order)} =</p>
                      <p className="text-3xl font-bold text-blue-700 font-mono break-all">{result.derivative}</p>
                    </div>

                    {/* Gradient Vector */}
                    {result.gradient && result.gradient.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-blue-200">
                        <p className="text-sm font-medium text-blue-700 mb-2">Gradient Vector ∇f:</p>
                        <div className="space-y-1">
                          {result.gradient.map((g, i) => (
                            <p key={i} className="text-sm font-mono text-blue-600">
                              {g}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Step-by-step Solution */}
                    {showSteps && result.steps.length > 0 && (
                      <div className="mt-4">
                        <button
                          onClick={() => setShowDetails(!showDetails)}
                          className="flex items-center gap-2 text-sm font-medium text-blue-700 hover:text-blue-800 transition-colors"
                        >
                          {showDetails ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                          {showDetails ? "Hide" : "Show"} Step-by-Step Solution
                        </button>

                        {showDetails && (
                          <div className="mt-3 p-3 bg-white/80 rounded-lg">
                            <div className="space-y-2">
                              {result.steps.map((step, index) => (
                                <p key={index} className="text-sm font-mono text-gray-700">
                                  {step}
                                </p>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Partial Derivative Rules</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold">Power Rule</p>
                      <p className="font-mono text-muted-foreground">∂/∂x(x^n) = n·x^(n-1)</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold">Constant Multiple Rule</p>
                      <p className="font-mono text-muted-foreground">∂/∂x(c·f) = c·∂f/∂x</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold">Sum Rule</p>
                      <p className="font-mono text-muted-foreground">∂/∂x(f+g) = ∂f/∂x + ∂g/∂x</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted">
                      <p className="font-semibold">Product Rule</p>
                      <p className="font-mono text-muted-foreground">∂/∂x(f·g) = f·∂g/∂x + g·∂f/∂x</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Derivatives</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm font-mono">
                    <div className="p-2 bg-muted rounded">∂/∂x(sin x) = cos x</div>
                    <div className="p-2 bg-muted rounded">∂/∂x(cos x) = -sin x</div>
                    <div className="p-2 bg-muted rounded">∂/∂x(e^x) = e^x</div>
                    <div className="p-2 bg-muted rounded">∂/∂x(ln x) = 1/x</div>
                    <div className="p-2 bg-muted rounded">∂/∂x(xy) = y</div>
                    <div className="p-2 bg-muted rounded">∂/∂y(xy) = x</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Input Format</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>
                    <strong>Powers:</strong> Use ^ for exponents (x^2, y^3)
                  </p>
                  <p>
                    <strong>Products:</strong> Use * or implicit (2x, x*y, 3xy)
                  </p>
                  <p>
                    <strong>Functions:</strong> sin(x), cos(y), ln(x), e^x
                  </p>
                  <p>
                    <strong>Examples:</strong>
                  </p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>x^2 + y^2</li>
                    <li>3x^2y + 2xy^2</li>
                    <li>sin(x) + cos(y)</li>
                    <li>e^x + ln(y)</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is a Partial Derivative?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  A partial derivative is a derivative of a function of multiple variables with respect to one variable,
                  treating all other variables as constants. It measures the rate of change of the function along one
                  axis while holding other variables fixed. Partial derivatives are fundamental in multivariable
                  calculus and are essential for optimization, physics, engineering, and machine learning applications.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For a function f(x, y), the partial derivative with respect to x, denoted ∂f/∂x, is found by
                  differentiating f treating y as a constant. Similarly, ∂f/∂y is found by treating x as a constant. The
                  collection of all first-order partial derivatives forms the gradient vector ∇f, which points in the
                  direction of steepest ascent of the function.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Applications of Partial Derivatives</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Optimization</h4>
                    <p className="text-blue-700 text-sm">
                      Finding maximum and minimum values of functions by setting partial derivatives to zero (critical
                      points). Used in economics, machine learning, and engineering design.
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Physics</h4>
                    <p className="text-green-700 text-sm">
                      Describing physical phenomena like heat flow, wave propagation, and electromagnetic fields through
                      partial differential equations.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Machine Learning</h4>
                    <p className="text-purple-700 text-sm">
                      Gradient descent algorithms use partial derivatives to minimize loss functions and train neural
                      networks by computing gradients efficiently.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Economics</h4>
                    <p className="text-orange-700 text-sm">
                      Marginal analysis in economics uses partial derivatives to understand how changes in one variable
                      affect outcomes while holding others constant.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle className="text-base text-yellow-800">Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700">
                  Partial derivative calculations follow standard multivariable calculus rules. Results depend on
                  correct function input and selected variable. This calculator handles common algebraic and
                  trigonometric functions. For complex expressions or advanced applications, verify results with
                  additional tools or manual calculation.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
