"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  TrendingUp,
  Info,
  Target,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

type UnitSystem = "metric" | "imperial"

interface WeightGainResult {
  totalWeightToGain: number
  weeksRequired: number
  daysRequired: number
  targetDate: Date
  dailyGain: number
  weeklyGain: number
  monthsRequired: number
  safetyStatus: "safe" | "moderate" | "aggressive"
  safetyColor: string
  safetyBgColor: string
}

export function WeightGainCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("metric")
  const [currentWeight, setCurrentWeight] = useState("")
  const [targetWeight, setTargetWeight] = useState("")
  const [weeklyGain, setWeeklyGain] = useState("")
  const [startDate, setStartDate] = useState(new Date().toISOString().split("T")[0])
  const [useCustomDate, setUseCustomDate] = useState(false)
  const [result, setResult] = useState<WeightGainResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showDetails, setShowDetails] = useState(false)

  const calculateWeightGain = () => {
    setError("")
    setResult(null)

    const currentWeightNum = Number.parseFloat(currentWeight)
    const targetWeightNum = Number.parseFloat(targetWeight)
    const weeklyGainNum = Number.parseFloat(weeklyGain)

    if (isNaN(currentWeightNum) || currentWeightNum <= 0) {
      setError("Please enter a valid current weight greater than 0")
      return
    }

    if (isNaN(targetWeightNum) || targetWeightNum <= 0) {
      setError("Please enter a valid target weight greater than 0")
      return
    }

    if (targetWeightNum <= currentWeightNum) {
      setError("Target weight must be greater than current weight for weight gain")
      return
    }

    if (isNaN(weeklyGainNum) || weeklyGainNum <= 0) {
      setError("Please enter a valid weekly weight gain greater than 0")
      return
    }

    // Convert to metric for calculations if imperial
    const currentWeightKg = unitSystem === "imperial" ? currentWeightNum * 0.453592 : currentWeightNum
    const targetWeightKg = unitSystem === "imperial" ? targetWeightNum * 0.453592 : targetWeightNum
    const weeklyGainKg = unitSystem === "imperial" ? weeklyGainNum * 0.453592 : weeklyGainNum

    // Safe weekly gain limits (in kg)
    const safeMinKg = 0.25
    const safeMaxKg = 0.5
    const moderateMaxKg = 0.75

    // Determine safety status
    let safetyStatus: "safe" | "moderate" | "aggressive"
    let safetyColor: string
    let safetyBgColor: string

    if (weeklyGainKg <= safeMaxKg) {
      safetyStatus = "safe"
      safetyColor = "text-green-600"
      safetyBgColor = "bg-green-50 border-green-200"
    } else if (weeklyGainKg <= moderateMaxKg) {
      safetyStatus = "moderate"
      safetyColor = "text-yellow-600"
      safetyBgColor = "bg-yellow-50 border-yellow-200"
    } else {
      safetyStatus = "aggressive"
      safetyColor = "text-red-600"
      safetyBgColor = "bg-red-50 border-red-200"
    }

    const totalWeightToGain = targetWeightNum - currentWeightNum
    const totalWeightToGainKg = targetWeightKg - currentWeightKg
    const weeksRequired = Math.ceil(totalWeightToGainKg / weeklyGainKg)
    const daysRequired = weeksRequired * 7
    const monthsRequired = weeksRequired / 4.33

    const start = useCustomDate ? new Date(startDate) : new Date()
    const targetDate = new Date(start)
    targetDate.setDate(targetDate.getDate() + daysRequired)

    const dailyGain = weeklyGainNum / 7

    setResult({
      totalWeightToGain,
      weeksRequired,
      daysRequired,
      targetDate,
      dailyGain,
      weeklyGain: weeklyGainNum,
      monthsRequired,
      safetyStatus,
      safetyColor,
      safetyBgColor,
    })
  }

  const handleReset = () => {
    setCurrentWeight("")
    setTargetWeight("")
    setWeeklyGain("")
    setStartDate(new Date().toISOString().split("T")[0])
    setUseCustomDate(false)
    setResult(null)
    setError("")
    setCopied(false)
    setShowDetails(false)
  }

  const handleCopy = async () => {
    if (result) {
      const unit = unitSystem === "metric" ? "kg" : "lb"
      await navigator.clipboard.writeText(
        `Weight Gain Plan: ${result.totalWeightToGain.toFixed(1)} ${unit} in ${result.weeksRequired} weeks (Target: ${result.targetDate.toLocaleDateString()})`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const unit = unitSystem === "metric" ? "kg" : "lb"
      try {
        await navigator.share({
          title: "My Weight Gain Plan",
          text: `I'm planning to gain ${result.totalWeightToGain.toFixed(1)} ${unit} in ${result.weeksRequired} weeks using CalcHub!`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setCurrentWeight("")
    setTargetWeight("")
    setWeeklyGain("")
    setResult(null)
    setError("")
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const getSafetyLabel = (status: "safe" | "moderate" | "aggressive") => {
    switch (status) {
      case "safe":
        return "Safe & Sustainable"
      case "moderate":
        return "Moderately Aggressive"
      case "aggressive":
        return "Aggressive (Not Recommended)"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/health-fitness">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Health & Fitness
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-50 text-green-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Weight Gain Calculator</CardTitle>
                    <CardDescription>Estimate time to reach your target weight</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Current Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="currentWeight">Current Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="currentWeight"
                    type="number"
                    placeholder={`Enter current weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={currentWeight}
                    onChange={(e) => setCurrentWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Target Weight Input */}
                <div className="space-y-2">
                  <Label htmlFor="targetWeight">Target Weight ({unitSystem === "metric" ? "kg" : "lb"})</Label>
                  <Input
                    id="targetWeight"
                    type="number"
                    placeholder={`Enter target weight in ${unitSystem === "metric" ? "kilograms" : "pounds"}`}
                    value={targetWeight}
                    onChange={(e) => setTargetWeight(e.target.value)}
                    min="0"
                    step="0.1"
                  />
                </div>

                {/* Weekly Gain Input */}
                <div className="space-y-2">
                  <Label htmlFor="weeklyGain">Weekly Weight Gain ({unitSystem === "metric" ? "kg" : "lb"}/week)</Label>
                  <Input
                    id="weeklyGain"
                    type="number"
                    placeholder={unitSystem === "metric" ? "e.g., 0.25 - 0.5 kg" : "e.g., 0.5 - 1 lb"}
                    value={weeklyGain}
                    onChange={(e) => setWeeklyGain(e.target.value)}
                    min="0"
                    step="0.05"
                  />
                  <p className="text-xs text-muted-foreground">
                    Safe range: {unitSystem === "metric" ? "0.25 - 0.5 kg" : "0.5 - 1 lb"} per week
                  </p>
                </div>

                {/* Custom Start Date Toggle */}
                <div className="flex items-center justify-between">
                  <Label htmlFor="customDate" className="cursor-pointer">
                    Custom start date
                  </Label>
                  <Switch id="customDate" checked={useCustomDate} onCheckedChange={setUseCustomDate} />
                </div>

                {useCustomDate && (
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                )}

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateWeightGain} className="w-full" size="lg">
                  Calculate Weight Gain Plan
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.safetyBgColor} transition-all duration-300`}>
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Target Date</p>
                      <p className={`text-2xl sm:text-3xl font-bold ${result.safetyColor} mb-1`}>
                        {formatDate(result.targetDate)}
                      </p>
                      <p className={`text-lg font-semibold ${result.safetyColor}`}>
                        {result.weeksRequired} weeks ({Math.round(result.monthsRequired * 10) / 10} months)
                      </p>
                    </div>

                    {/* Safety Status */}
                    <div className="mt-3 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${result.safetyBgColor} ${result.safetyColor}`}
                      >
                        {result.safetyStatus === "aggressive" && <AlertTriangle className="h-3.5 w-3.5" />}
                        {getSafetyLabel(result.safetyStatus)}
                      </span>
                    </div>

                    {/* Expandable Details */}
                    <button
                      onClick={() => setShowDetails(!showDetails)}
                      className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {showDetails ? (
                        <>
                          <ChevronUp className="h-4 w-4" />
                          Hide Details
                        </>
                      ) : (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          Show Details
                        </>
                      )}
                    </button>

                    {showDetails && (
                      <div className="mt-4 pt-4 border-t border-current/10 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Weight to Gain</span>
                          <span className="font-medium">
                            {result.totalWeightToGain.toFixed(1)} {unitSystem === "metric" ? "kg" : "lb"}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Weekly Gain Rate</span>
                          <span className="font-medium">
                            {result.weeklyGain.toFixed(2)} {unitSystem === "metric" ? "kg" : "lb"}/week
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Daily Gain Average</span>
                          <span className="font-medium">
                            {result.dailyGain.toFixed(3)} {unitSystem === "metric" ? "kg" : "lb"}/day
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Days</span>
                          <span className="font-medium">{result.daysRequired} days</span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Safe Weekly Weight Gain</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-50 border border-green-200">
                      <span className="font-medium text-green-700">Safe</span>
                      <span className="text-sm text-green-600">
                        {unitSystem === "metric" ? "0.25 - 0.5 kg" : "0.5 - 1 lb"}/week
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Moderate</span>
                      <span className="text-sm text-yellow-600">
                        {unitSystem === "metric" ? "0.5 - 0.75 kg" : "1 - 1.5 lb"}/week
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-red-50 border border-red-200">
                      <span className="font-medium text-red-700">Aggressive</span>
                      <span className="text-sm text-red-600">
                        {unitSystem === "metric" ? "> 0.75 kg" : "> 1.5 lb"}/week
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Calculation Formula</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="p-4 bg-muted rounded-lg font-mono text-center">
                    <p className="font-semibold text-foreground text-xs sm:text-sm">
                      Weeks = (Target − Current) ÷ Weekly Gain
                    </p>
                  </div>
                  <p>
                    The calculator divides your total weight goal by your weekly gain rate to estimate the number of
                    weeks needed, then adds that to your start date.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Healthy Weight Gain</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Gaining weight in a healthy, sustainable manner requires a strategic approach that focuses on building
                  lean muscle mass rather than simply adding body fat. While it may seem straightforward, healthy weight
                  gain involves careful attention to nutrition, exercise, and overall lifestyle factors. The goal should
                  be to gain weight gradually while supporting your body's nutritional needs and maintaining overall
                  health.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  A safe rate of weight gain is typically 0.25 to 0.5 kg (0.5 to 1 lb) per week. This rate allows your
                  body to build muscle tissue effectively while minimizing excessive fat gain. Faster weight gain often
                  results in a higher proportion of fat tissue and can be harder to maintain long-term. Individual
                  factors such as metabolism, activity level, and body composition will influence your actual results.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  <CardTitle>Tips for Healthy Weight Gain</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Nutrition</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Eat calorie-dense, nutrient-rich foods</li>
                      <li>Include protein with every meal</li>
                      <li>Eat more frequently (5-6 smaller meals)</li>
                      <li>Add healthy fats (nuts, avocados, oils)</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Exercise</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Focus on strength training</li>
                      <li>Limit excessive cardio</li>
                      <li>Allow adequate rest between workouts</li>
                      <li>Progressive overload for muscle growth</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Lifestyle</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Get 7-9 hours of quality sleep</li>
                      <li>Manage stress levels</li>
                      <li>Stay consistent with your routine</li>
                      <li>Track your progress weekly</li>
                    </ul>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Calorie Surplus</h4>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>Aim for 300-500 calories above maintenance</li>
                      <li>Adjust based on weekly progress</li>
                      <li>Focus on quality over quantity</li>
                      <li>Use a food tracking app</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                  <CardTitle>Important Disclaimer</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  Weight gain predictions are estimates and may vary based on individual metabolism, genetics, nutrition
                  quality, exercise habits, and activity levels. This calculator provides a general guideline and should
                  not replace professional medical or nutritional advice. Consult a healthcare professional, registered
                  dietitian, or certified fitness expert before starting any weight gain program, especially if you have
                  underlying health conditions or concerns about your weight.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
