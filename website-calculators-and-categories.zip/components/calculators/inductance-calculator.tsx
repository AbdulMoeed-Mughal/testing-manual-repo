"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Share2, Check, Zap, Info, AlertTriangle, Calculator } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown } from "lucide-react"

type CalculationMethod = "voltage" | "flux" | "solenoid"
type InductanceUnit = "H" | "mH" | "µH" | "nH"

interface InductanceResult {
  inductance: number
  unit: InductanceUnit
  method: string
  steps: string[]
}

const coreMaterials = [
  { name: "Air / Vacuum", permeability: 1 },
  { name: "Ferrite (typical)", permeability: 2000 },
  { name: "Iron (pure)", permeability: 5000 },
  { name: "Silicon Steel", permeability: 4000 },
  { name: "Nickel", permeability: 600 },
  { name: "Cobalt", permeability: 250 },
  { name: "Permalloy", permeability: 100000 },
  { name: "Mu-metal", permeability: 50000 },
  { name: "Custom", permeability: 0 },
]

export function InductanceCalculator() {
  const [method, setMethod] = useState<CalculationMethod>("voltage")
  const [voltage, setVoltage] = useState("")
  const [diDt, setDiDt] = useState("")
  const [numTurns, setNumTurns] = useState("")
  const [fluxLinkage, setFluxLinkage] = useState("")
  const [current, setCurrent] = useState("")
  const [coilLength, setCoilLength] = useState("")
  const [coilRadius, setCoilRadius] = useState("")
  const [coreMaterial, setCoreMaterial] = useState("Air / Vacuum")
  const [customPermeability, setCustomPermeability] = useState("")
  const [outputUnit, setOutputUnit] = useState<InductanceUnit>("mH")
  const [result, setResult] = useState<InductanceResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const µ0 = 4 * Math.PI * 1e-7 // Permeability of free space

  const convertToBaseUnit = (value: number, unit: InductanceUnit): number => {
    switch (unit) {
      case "H":
        return value
      case "mH":
        return value * 1e-3
      case "µH":
        return value * 1e-6
      case "nH":
        return value * 1e-9
      default:
        return value
    }
  }

  const convertFromBaseUnit = (value: number, unit: InductanceUnit): number => {
    switch (unit) {
      case "H":
        return value
      case "mH":
        return value * 1e3
      case "µH":
        return value * 1e6
      case "nH":
        return value * 1e9
      default:
        return value
    }
  }

  const formatNumber = (num: number, decimals = 6): string => {
    if (Math.abs(num) < 0.000001 || Math.abs(num) >= 1000000) {
      return num.toExponential(decimals)
    }
    return num.toFixed(decimals).replace(/\.?0+$/, "")
  }

  const calculate = () => {
    setError("")
    setResult(null)

    const steps: string[] = []
    let inductanceH = 0

    try {
      if (method === "voltage") {
        const V = Number.parseFloat(voltage)
        const didt = Number.parseFloat(diDt)

        if (isNaN(V) || V <= 0) {
          setError("Please enter a valid voltage greater than 0")
          return
        }
        if (isNaN(didt) || didt <= 0) {
          setError("Please enter a valid rate of current change greater than 0")
          return
        }

        steps.push(`Using formula: L = V / (dI/dt)`)
        steps.push(`L = ${V} V / ${didt} A/s`)
        inductanceH = V / didt
        steps.push(`L = ${formatNumber(inductanceH)} H`)
      } else if (method === "flux") {
        const N = Number.parseFloat(numTurns)
        const phi = Number.parseFloat(fluxLinkage)
        const I = Number.parseFloat(current)

        if (isNaN(N) || N <= 0 || !Number.isInteger(N)) {
          setError("Please enter a valid number of turns (positive integer)")
          return
        }
        if (isNaN(phi) || phi <= 0) {
          setError("Please enter a valid flux linkage greater than 0")
          return
        }
        if (isNaN(I) || I <= 0) {
          setError("Please enter a valid current greater than 0")
          return
        }

        steps.push(`Using formula: L = N × Φ / I`)
        steps.push(`L = ${N} × ${phi} Wb / ${I} A`)
        inductanceH = (N * phi) / I
        steps.push(`L = ${formatNumber(inductanceH)} H`)
      } else if (method === "solenoid") {
        const N = Number.parseFloat(numTurns)
        const l = Number.parseFloat(coilLength) / 100 // Convert cm to m
        const r = Number.parseFloat(coilRadius) / 100 // Convert cm to m

        if (isNaN(N) || N <= 0 || !Number.isInteger(N)) {
          setError("Please enter a valid number of turns (positive integer)")
          return
        }
        if (isNaN(l) || l <= 0) {
          setError("Please enter a valid coil length greater than 0")
          return
        }
        if (isNaN(r) || r <= 0) {
          setError("Please enter a valid coil radius greater than 0")
          return
        }

        let µr = coreMaterials.find((m) => m.name === coreMaterial)?.permeability || 1
        if (coreMaterial === "Custom") {
          µr = Number.parseFloat(customPermeability)
          if (isNaN(µr) || µr <= 0) {
            setError("Please enter a valid custom permeability greater than 0")
            return
          }
        }

        const A = Math.PI * r * r // Cross-sectional area
        const µ = µ0 * µr // Total permeability

        steps.push(`Using formula: L = (μ × N² × A) / l`)
        steps.push(`Where: μ = μ₀ × μᵣ = ${µ0.toExponential(4)} × ${µr} = ${µ.toExponential(4)} H/m`)
        steps.push(
          `A = π × r² = π × ${(r * 100).toFixed(2)}² cm² = ${(A * 10000).toFixed(6)} cm² = ${A.toExponential(4)} m²`,
        )
        steps.push(`L = (${µ.toExponential(4)} × ${N}² × ${A.toExponential(4)}) / ${l.toFixed(4)}`)
        inductanceH = (µ * N * N * A) / l
        steps.push(`L = ${formatNumber(inductanceH)} H`)
      }

      const convertedValue = convertFromBaseUnit(inductanceH, outputUnit)
      steps.push(`Converting to ${outputUnit}: ${formatNumber(convertedValue)} ${outputUnit}`)

      setResult({
        inductance: convertedValue,
        unit: outputUnit,
        method:
          method === "voltage" ? "Voltage Method" : method === "flux" ? "Flux Linkage Method" : "Solenoid Formula",
        steps,
      })
    } catch (err) {
      setError("An error occurred during calculation. Please check your inputs.")
    }
  }

  const handleReset = () => {
    setVoltage("")
    setDiDt("")
    setNumTurns("")
    setFluxLinkage("")
    setCurrent("")
    setCoilLength("")
    setCoilRadius("")
    setCoreMaterial("Air / Vacuum")
    setCustomPermeability("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      await navigator.clipboard.writeText(`Inductance: ${formatNumber(result.inductance)} ${result.unit}`)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      try {
        await navigator.share({
          title: "Inductance Calculation",
          text: `I calculated inductance using CalcHub! Inductance: ${formatNumber(result.inductance)} ${result.unit}`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/physics-engineering">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Physics
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Inductance Calculator</CardTitle>
                    <CardDescription>Calculate inductance of coils and inductors</CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Method Selection */}
                <div className="space-y-2">
                  <Label>Calculation Method</Label>
                  <Select
                    value={method}
                    onValueChange={(v: CalculationMethod) => {
                      setMethod(v)
                      setResult(null)
                      setError("")
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="voltage">Voltage Method (L = V / (dI/dt))</SelectItem>
                      <SelectItem value="flux">Flux Linkage (L = NΦ / I)</SelectItem>
                      <SelectItem value="solenoid">Solenoid Formula (L = μN²A / l)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Voltage Method Inputs */}
                {method === "voltage" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="voltage">Voltage (V)</Label>
                      <Input
                        id="voltage"
                        type="number"
                        placeholder="Enter voltage across inductor"
                        value={voltage}
                        onChange={(e) => setVoltage(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="diDt">Rate of Current Change (dI/dt) (A/s)</Label>
                      <Input
                        id="diDt"
                        type="number"
                        placeholder="Enter rate of current change"
                        value={diDt}
                        onChange={(e) => setDiDt(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Flux Linkage Method Inputs */}
                {method === "flux" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="numTurns">Number of Turns (N)</Label>
                      <Input
                        id="numTurns"
                        type="number"
                        placeholder="Enter number of coil turns"
                        value={numTurns}
                        onChange={(e) => setNumTurns(e.target.value)}
                        min="1"
                        step="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fluxLinkage">Magnetic Flux (Φ) (Wb)</Label>
                      <Input
                        id="fluxLinkage"
                        type="number"
                        placeholder="Enter magnetic flux in Webers"
                        value={fluxLinkage}
                        onChange={(e) => setFluxLinkage(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="current">Current (I) (A)</Label>
                      <Input
                        id="current"
                        type="number"
                        placeholder="Enter current in Amperes"
                        value={current}
                        onChange={(e) => setCurrent(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                  </>
                )}

                {/* Solenoid Method Inputs */}
                {method === "solenoid" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="numTurnsSol">Number of Turns (N)</Label>
                      <Input
                        id="numTurnsSol"
                        type="number"
                        placeholder="Enter number of coil turns"
                        value={numTurns}
                        onChange={(e) => setNumTurns(e.target.value)}
                        min="1"
                        step="1"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="coilLength">Coil Length (cm)</Label>
                      <Input
                        id="coilLength"
                        type="number"
                        placeholder="Enter coil length in cm"
                        value={coilLength}
                        onChange={(e) => setCoilLength(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="coilRadius">Coil Radius (cm)</Label>
                      <Input
                        id="coilRadius"
                        type="number"
                        placeholder="Enter coil radius in cm"
                        value={coilRadius}
                        onChange={(e) => setCoilRadius(e.target.value)}
                        min="0"
                        step="any"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Core Material</Label>
                      <Select value={coreMaterial} onValueChange={setCoreMaterial}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {coreMaterials.map((mat) => (
                            <SelectItem key={mat.name} value={mat.name}>
                              {mat.name} {mat.permeability > 0 ? `(μᵣ = ${mat.permeability.toLocaleString()})` : ""}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {coreMaterial === "Custom" && (
                      <div className="space-y-2">
                        <Label htmlFor="customPerm">Custom Relative Permeability (μᵣ)</Label>
                        <Input
                          id="customPerm"
                          type="number"
                          placeholder="Enter relative permeability"
                          value={customPermeability}
                          onChange={(e) => setCustomPermeability(e.target.value)}
                          min="1"
                          step="any"
                        />
                      </div>
                    )}
                  </>
                )}

                {/* Output Unit Selection */}
                <div className="space-y-2">
                  <Label>Output Unit</Label>
                  <Select value={outputUnit} onValueChange={(v: InductanceUnit) => setOutputUnit(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="H">Henrys (H)</SelectItem>
                      <SelectItem value="mH">Millihenrys (mH)</SelectItem>
                      <SelectItem value="µH">Microhenrys (µH)</SelectItem>
                      <SelectItem value="nH">Nanohenrys (nH)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculate} className="w-full" size="lg">
                  Calculate Inductance
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Inductance ({result.method})</p>
                      <p className="text-4xl font-bold text-yellow-600 mb-2">
                        {formatNumber(result.inductance)} {result.unit}
                      </p>
                    </div>

                    {/* Step-by-step Solution */}
                    <Collapsible open={showSteps} onOpenChange={setShowSteps} className="mt-4">
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-between">
                          <span>Step-by-Step Solution</span>
                          <ChevronDown className={`h-4 w-4 transition-transform ${showSteps ? "rotate-180" : ""}`} />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2">
                        <div className="p-3 bg-white rounded-lg border border-yellow-200 space-y-1">
                          {result.steps.map((step, idx) => (
                            <p key={idx} className="text-sm font-mono text-muted-foreground">
                              {step}
                            </p>
                          ))}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Inductance Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-semibold text-sm mb-1">Voltage Method</p>
                    <p className="font-mono text-center text-foreground">L = V / (dI/dt)</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-semibold text-sm mb-1">Flux Linkage Method</p>
                    <p className="font-mono text-center text-foreground">L = N × Φ / I</p>
                  </div>
                  <div className="p-3 rounded-lg bg-muted">
                    <p className="font-semibold text-sm mb-1">Solenoid Formula</p>
                    <p className="font-mono text-center text-foreground">L = (μ₀ × μᵣ × N² × A) / l</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Core Material Permeability</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    {coreMaterials
                      .filter((m) => m.permeability > 0)
                      .slice(0, 6)
                      .map((mat) => (
                        <div key={mat.name} className="flex justify-between p-2 rounded bg-muted/50">
                          <span>{mat.name}</span>
                          <span className="font-mono">μᵣ = {mat.permeability.toLocaleString()}</span>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Unit Conversions</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-2">
                  <p>1 H = 1,000 mH = 1,000,000 µH = 1,000,000,000 nH</p>
                  <p>μ₀ (vacuum permeability) = 4π × 10⁻⁷ H/m</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Inductance?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Inductance is a property of an electrical conductor that opposes changes in current. When current
                  flows through a conductor, it creates a magnetic field around it. If the current changes, the magnetic
                  field also changes, which induces a voltage (electromotive force) that opposes the change in current.
                  This property is known as self-inductance, measured in Henrys (H).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Inductors are fundamental components in electronic circuits, used in filters, transformers, energy
                  storage, and power conversion applications. The inductance of a coil depends on its physical
                  dimensions, the number of turns, and the magnetic properties of its core material.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <CardTitle>Calculation Methods Explained</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Voltage Method:</strong> Uses the fundamental relationship V = L × (dI/dt), rearranged to find
                  inductance. This method is useful when you can measure the voltage across an inductor and the rate of
                  current change.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Flux Linkage Method:</strong> Based on the definition L = NΦ/I, where N is the number of
                  turns, Φ is the magnetic flux through each turn, and I is the current. This method is useful for
                  theoretical calculations.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Solenoid Formula:</strong> Calculates inductance from physical dimensions using L = μN²A/l.
                  This is the most practical method for designing inductors, as it relates inductance directly to coil
                  geometry and core material properties.
                </p>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Inductance calculations are estimates based on ideal formulas. Actual inductance may vary due to
                      coil construction, core material, winding density, and environmental factors. Consult component
                      datasheets or an electrical engineer for precise measurements.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
