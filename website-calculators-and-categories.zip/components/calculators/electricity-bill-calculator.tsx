"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  RotateCcw,
  Copy,
  Share2,
  Check,
  Zap,
  Info,
  ChevronDown,
  ChevronUp,
  DollarSign,
  AlertTriangle,
  Plus,
  Trash2,
} from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"

type Currency = "USD" | "EUR" | "GBP" | "INR" | "AUD" | "CAD" | "JPY" | "CNY"

interface TieredRate {
  id: string
  upTo: string
  rate: string
}

interface ElectricityResult {
  consumptionCost: number
  fixedCharges: number
  subtotal: number
  taxAmount: number
  previousBalance: number
  totalBill: number
  costPerKwh: number
  tieredBreakdown?: { tier: number; units: number; rate: number; cost: number }[]
}

const currencySymbols: Record<Currency, string> = {
  USD: "$",
  EUR: "€",
  GBP: "£",
  INR: "₹",
  AUD: "A$",
  CAD: "C$",
  JPY: "¥",
  CNY: "¥",
}

export function ElectricityBillCalculator() {
  const [consumption, setConsumption] = useState("")
  const [rate, setRate] = useState("")
  const [fixedCharges, setFixedCharges] = useState("")
  const [taxPercent, setTaxPercent] = useState("")
  const [previousBalance, setPreviousBalance] = useState("")
  const [currency, setCurrency] = useState<Currency>("USD")
  const [useTieredRates, setUseTieredRates] = useState(false)
  const [tieredRates, setTieredRates] = useState<TieredRate[]>([
    { id: "1", upTo: "100", rate: "0.08" },
    { id: "2", upTo: "300", rate: "0.10" },
    { id: "3", upTo: "", rate: "0.12" },
  ])
  const [result, setResult] = useState<ElectricityResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showBreakdown, setShowBreakdown] = useState(false)

  const calculateBill = () => {
    setError("")
    setResult(null)

    const consumptionNum = Number.parseFloat(consumption)
    if (isNaN(consumptionNum) || consumptionNum < 0) {
      setError("Please enter a valid consumption value (0 or greater)")
      return
    }

    let consumptionCost = 0
    const tieredBreakdown: { tier: number; units: number; rate: number; cost: number }[] = []

    if (useTieredRates) {
      // Calculate tiered rates
      let remainingUnits = consumptionNum
      let previousLimit = 0

      for (let i = 0; i < tieredRates.length; i++) {
        const tier = tieredRates[i]
        const tierRate = Number.parseFloat(tier.rate) || 0
        const tierLimit = tier.upTo ? Number.parseFloat(tier.upTo) : Number.POSITIVE_INFINITY

        if (remainingUnits <= 0) break

        const tierUnits = Math.min(remainingUnits, tierLimit - previousLimit)
        if (tierUnits > 0) {
          const tierCost = tierUnits * tierRate
          consumptionCost += tierCost
          tieredBreakdown.push({
            tier: i + 1,
            units: tierUnits,
            rate: tierRate,
            cost: tierCost,
          })
          remainingUnits -= tierUnits
        }
        previousLimit = tierLimit
      }
    } else {
      const rateNum = Number.parseFloat(rate)
      if (isNaN(rateNum) || rateNum < 0) {
        setError("Please enter a valid rate per unit (0 or greater)")
        return
      }
      consumptionCost = consumptionNum * rateNum
    }

    const fixedChargesNum = Number.parseFloat(fixedCharges) || 0
    const taxPercentNum = Number.parseFloat(taxPercent) || 0
    const previousBalanceNum = Number.parseFloat(previousBalance) || 0

    if (fixedChargesNum < 0 || taxPercentNum < 0) {
      setError("Fixed charges and tax percentage must be non-negative")
      return
    }

    const subtotal = consumptionCost + fixedChargesNum
    const taxAmount = subtotal * (taxPercentNum / 100)
    const totalBill = subtotal + taxAmount + previousBalanceNum
    const costPerKwh = consumptionNum > 0 ? totalBill / consumptionNum : 0

    if (totalBill < 0) {
      setError("Total bill cannot be negative. Please check your inputs.")
      return
    }

    setResult({
      consumptionCost,
      fixedCharges: fixedChargesNum,
      subtotal,
      taxAmount,
      previousBalance: previousBalanceNum,
      totalBill,
      costPerKwh,
      tieredBreakdown: useTieredRates ? tieredBreakdown : undefined,
    })
  }

  const handleReset = () => {
    setConsumption("")
    setRate("")
    setFixedCharges("")
    setTaxPercent("")
    setPreviousBalance("")
    setUseTieredRates(false)
    setTieredRates([
      { id: "1", upTo: "100", rate: "0.08" },
      { id: "2", upTo: "300", rate: "0.10" },
      { id: "3", upTo: "", rate: "0.12" },
    ])
    setResult(null)
    setError("")
    setCopied(false)
    setShowBreakdown(false)
  }

  const handleCopy = async () => {
    if (result) {
      const symbol = currencySymbols[currency]
      await navigator.clipboard.writeText(
        `Electricity Bill: ${symbol}${result.totalBill.toFixed(2)} (${consumption} kWh)`,
      )
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleShare = async () => {
    if (result && navigator.share) {
      const symbol = currencySymbols[currency]
      try {
        await navigator.share({
          title: "My Electricity Bill",
          text: `I calculated my electricity bill using CalcHub! Total: ${symbol}${result.totalBill.toFixed(2)} for ${consumption} kWh`,
          url: window.location.href,
        })
      } catch (err) {
        // User cancelled or share failed
      }
    }
  }

  const addTier = () => {
    setTieredRates([...tieredRates, { id: Date.now().toString(), upTo: "", rate: "" }])
  }

  const removeTier = (id: string) => {
    if (tieredRates.length > 1) {
      setTieredRates(tieredRates.filter((t) => t.id !== id))
    }
  }

  const updateTier = (id: string, field: "upTo" | "rate", value: string) => {
    setTieredRates(tieredRates.map((t) => (t.id === id ? { ...t, [field]: value } : t)))
  }

  const symbol = currencySymbols[currency]

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/lifestyle-daily">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Lifestyle & Daily Use
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-50 text-yellow-600">
                    <Zap className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Electricity Bill Calculator</CardTitle>
                    <CardDescription>Calculate your total electricity bill</CardDescription>
                  </div>
                </div>

                {/* Currency Selector */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Currency</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as Currency)}
                    className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="INR">INR (₹)</option>
                    <option value="AUD">AUD (A$)</option>
                    <option value="CAD">CAD (C$)</option>
                    <option value="JPY">JPY (¥)</option>
                    <option value="CNY">CNY (¥)</option>
                  </select>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Consumption Input */}
                <div className="space-y-2">
                  <Label htmlFor="consumption">Total Consumption (kWh)</Label>
                  <div className="relative">
                    <Zap className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="consumption"
                      type="number"
                      placeholder="Enter units consumed"
                      value={consumption}
                      onChange={(e) => setConsumption(e.target.value)}
                      className="pl-10"
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>

                {/* Tiered Rates Toggle */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div>
                    <p className="text-sm font-medium">Use Tiered Rates</p>
                    <p className="text-xs text-muted-foreground">Different rates for consumption slabs</p>
                  </div>
                  <Switch checked={useTieredRates} onCheckedChange={setUseTieredRates} />
                </div>

                {/* Rate Input (Simple) or Tiered Rates */}
                {!useTieredRates ? (
                  <div className="space-y-2">
                    <Label htmlFor="rate">Rate per Unit ({symbol}/kWh)</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="rate"
                        type="number"
                        placeholder="Enter rate per kWh"
                        value={rate}
                        onChange={(e) => setRate(e.target.value)}
                        className="pl-10"
                        min="0"
                        step="0.001"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <Label>Tiered Rate Structure</Label>
                    <div className="space-y-2">
                      {tieredRates.map((tier, index) => (
                        <div key={tier.id} className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground w-16">Tier {index + 1}</span>
                          <Input
                            type="number"
                            placeholder={index === tieredRates.length - 1 ? "∞" : "Up to kWh"}
                            value={tier.upTo}
                            onChange={(e) => updateTier(tier.id, "upTo", e.target.value)}
                            className="flex-1"
                            min="0"
                            disabled={index === tieredRates.length - 1}
                          />
                          <Input
                            type="number"
                            placeholder={`${symbol}/kWh`}
                            value={tier.rate}
                            onChange={(e) => updateTier(tier.id, "rate", e.target.value)}
                            className="flex-1"
                            min="0"
                            step="0.001"
                          />
                          {tieredRates.length > 1 && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-9 w-9 text-red-500"
                              onClick={() => removeTier(tier.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                    <Button variant="outline" size="sm" onClick={addTier} className="w-full bg-transparent">
                      <Plus className="h-4 w-4 mr-1" />
                      Add Tier
                    </Button>
                  </div>
                )}

                {/* Fixed Charges */}
                <div className="space-y-2">
                  <Label htmlFor="fixedCharges">Fixed Charges ({symbol}) (Optional)</Label>
                  <Input
                    id="fixedCharges"
                    type="number"
                    placeholder="Meter rent, service fees, etc."
                    value={fixedCharges}
                    onChange={(e) => setFixedCharges(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Tax Percentage */}
                <div className="space-y-2">
                  <Label htmlFor="taxPercent">Tax Percentage (%) (Optional)</Label>
                  <Input
                    id="taxPercent"
                    type="number"
                    placeholder="VAT, service tax, etc."
                    value={taxPercent}
                    onChange={(e) => setTaxPercent(e.target.value)}
                    min="0"
                    max="100"
                    step="0.1"
                  />
                </div>

                {/* Previous Balance */}
                <div className="space-y-2">
                  <Label htmlFor="previousBalance">Previous Balance / Adjustments ({symbol}) (Optional)</Label>
                  <Input
                    id="previousBalance"
                    type="number"
                    placeholder="Arrears or credits (use negative for credits)"
                    value={previousBalance}
                    onChange={(e) => setPreviousBalance(e.target.value)}
                    step="0.01"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateBill} className="w-full" size="lg">
                  Calculate Bill
                </Button>

                {/* Result */}
                {result && (
                  <div className="p-4 rounded-xl border-2 bg-yellow-50 border-yellow-200 transition-all duration-300">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Electricity Bill</p>
                      <p className="text-5xl font-bold text-yellow-600 mb-2">
                        {symbol}
                        {result.totalBill.toFixed(2)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Cost per kWh: {symbol}
                        {result.costPerKwh.toFixed(4)}
                      </p>
                    </div>

                    {/* Breakdown Toggle */}
                    <button
                      onClick={() => setShowBreakdown(!showBreakdown)}
                      className="w-full flex items-center justify-center gap-1 mt-4 text-sm text-yellow-700 hover:text-yellow-800"
                    >
                      {showBreakdown ? (
                        <>
                          Hide Breakdown <ChevronUp className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Show Breakdown <ChevronDown className="h-4 w-4" />
                        </>
                      )}
                    </button>

                    {showBreakdown && (
                      <div className="mt-4 pt-4 border-t border-yellow-200 space-y-2 text-sm">
                        {result.tieredBreakdown && result.tieredBreakdown.length > 0 && (
                          <div className="mb-3 p-3 bg-yellow-100 rounded-lg">
                            <p className="font-medium mb-2 text-yellow-800">Tiered Consumption:</p>
                            {result.tieredBreakdown.map((tier) => (
                              <div key={tier.tier} className="flex justify-between text-yellow-700">
                                <span>
                                  Tier {tier.tier}: {tier.units.toFixed(2)} kWh × {symbol}
                                  {tier.rate.toFixed(4)}
                                </span>
                                <span>
                                  {symbol}
                                  {tier.cost.toFixed(2)}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Consumption Cost:</span>
                          <span className="font-medium">
                            {symbol}
                            {result.consumptionCost.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Fixed Charges:</span>
                          <span className="font-medium">
                            {symbol}
                            {result.fixedCharges.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between border-t border-yellow-200 pt-2">
                          <span className="text-muted-foreground">Subtotal:</span>
                          <span className="font-medium">
                            {symbol}
                            {result.subtotal.toFixed(2)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Tax ({taxPercent || 0}%):</span>
                          <span className="font-medium">
                            {symbol}
                            {result.taxAmount.toFixed(2)}
                          </span>
                        </div>
                        {result.previousBalance !== 0 && (
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Previous Balance:</span>
                            <span className={`font-medium ${result.previousBalance < 0 ? "text-green-600" : ""}`}>
                              {result.previousBalance < 0 ? "-" : ""}
                              {symbol}
                              {Math.abs(result.previousBalance).toFixed(2)}
                            </span>
                          </div>
                        )}
                        <div className="flex justify-between border-t border-yellow-200 pt-2 text-base">
                          <span className="font-semibold">Total Bill:</span>
                          <span className="font-bold text-yellow-600">
                            {symbol}
                            {result.totalBill.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="h-4 w-4 mr-1" />
                        Share
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Card */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bill Components</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-50 border border-yellow-200">
                      <span className="font-medium text-yellow-700">Consumption Cost</span>
                      <span className="text-sm text-yellow-600">kWh × Rate</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-blue-50 border border-blue-200">
                      <span className="font-medium text-blue-700">Fixed Charges</span>
                      <span className="text-sm text-blue-600">Meter, Service</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-purple-50 border border-purple-200">
                      <span className="font-medium text-purple-700">Taxes</span>
                      <span className="text-sm text-purple-600">VAT, Service Tax</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50 border border-gray-200">
                      <span className="font-medium text-gray-700">Adjustments</span>
                      <span className="text-sm text-gray-600">Arrears/Credits</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Typical Usage Reference</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground">Small Apartment</p>
                      <p>150-300 kWh/month</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground">Medium Home</p>
                      <p>500-900 kWh/month</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground">Large Home</p>
                      <p>1000-2000 kWh/month</p>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <p className="font-semibold text-foreground">With AC/Heating</p>
                      <p>+200-500 kWh/month</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Your Electricity Bill</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Your electricity bill is composed of several components that together determine the total amount you
                  owe. The primary component is the consumption charge, calculated by multiplying the number of
                  kilowatt-hours (kWh) you used by the rate per unit. This rate can be a flat rate or a tiered structure
                  where the price per kWh increases as consumption rises, encouraging energy conservation.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  In addition to consumption charges, utility companies often include fixed charges such as meter rent,
                  service fees, and maintenance costs. These charges remain constant regardless of how much electricity
                  you use. Taxes like VAT or service tax are typically applied as a percentage of the subtotal, adding
                  to your final bill.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-primary" />
                  <CardTitle>Tiered Rate Structures</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Many utility providers use tiered or slab-based pricing to encourage energy conservation. In this
                  system, the first block of consumption (e.g., 0-100 kWh) is charged at a lower rate, while subsequent
                  blocks are progressively more expensive. This means that heavy consumers pay more per unit as their
                  usage increases.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For example, a utility might charge $0.08/kWh for the first 100 units, $0.10/kWh for units 101-300,
                  and $0.12/kWh for anything above 300 units. Understanding your utility's rate structure can help you
                  identify opportunities to reduce your bill by shifting usage to lower-tier periods or reducing overall
                  consumption.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <CardTitle>Tips to Reduce Your Bill</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Use Energy-Efficient Appliances</h4>
                    <p className="text-green-700 text-sm">
                      Look for ENERGY STAR rated appliances that consume less electricity while providing the same
                      functionality.
                    </p>
                  </div>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Switch to LED Lighting</h4>
                    <p className="text-blue-700 text-sm">
                      LED bulbs use up to 75% less energy than incandescent bulbs and last much longer.
                    </p>
                  </div>
                  <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Optimize AC/Heating Usage</h4>
                    <p className="text-purple-700 text-sm">
                      Set thermostats to moderate temperatures and use programmable settings to reduce runtime.
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <h4 className="font-semibold text-orange-800 mb-2">Unplug Standby Devices</h4>
                    <p className="text-orange-700 text-sm">
                      Devices on standby still consume power. Unplug chargers and electronics when not in use.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimer */}
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="pt-6">
                <div className="flex gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Disclaimer</p>
                    <p>
                      Electricity bill estimates may vary depending on meter readings, tariff structure, and additional
                      fees applied by your utility provider. This calculator provides estimates based on the inputs you
                      provide and may not reflect your actual bill. Always refer to your official utility statement for
                      accurate billing information.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
