"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, RotateCcw, Copy, Check, Home, Info, ChevronDown, ChevronUp, AlertTriangle } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

type UnitSystem = "metric" | "imperial"

interface RoofPitchResult {
  ratio: string
  ratioDecimal: number
  angleInDegrees: number
  percentage: number
  pitchCategory: string
  categoryColor: string
  categoryBg: string
}

export function RoofPitchCalculator() {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>("imperial")
  const [rise, setRise] = useState("")
  const [run, setRun] = useState("")
  const [result, setResult] = useState<RoofPitchResult | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState("")
  const [showSteps, setShowSteps] = useState(false)

  const calculateRoofPitch = () => {
    setError("")
    setResult(null)

    const riseNum = Number.parseFloat(rise)
    const runNum = Number.parseFloat(run)

    if (isNaN(riseNum) || riseNum < 0) {
      setError("Please enter a valid rise value (0 or greater)")
      return
    }

    if (isNaN(runNum) || runNum <= 0) {
      setError("Please enter a valid run value greater than 0")
      return
    }

    // Calculate pitch ratio (rise per 12 units of run for imperial, or per 1 meter for metric)
    const ratioDecimal = riseNum / runNum
    const ratio = unitSystem === "imperial" ? `${(ratioDecimal * 12).toFixed(2)}:12` : `${ratioDecimal.toFixed(3)}:1`

    // Calculate angle in degrees
    const angleInRadians = Math.atan(ratioDecimal)
    const angleInDegrees = angleInRadians * (180 / Math.PI)

    // Calculate percentage
    const percentage = ratioDecimal * 100

    // Determine pitch category
    let pitchCategory: string
    let categoryColor: string
    let categoryBg: string

    if (angleInDegrees < 10) {
      pitchCategory = "Flat/Low Slope"
      categoryColor = "text-blue-600"
      categoryBg = "bg-blue-50 border-blue-200"
    } else if (angleInDegrees < 20) {
      pitchCategory = "Low Pitch"
      categoryColor = "text-green-600"
      categoryBg = "bg-green-50 border-green-200"
    } else if (angleInDegrees < 35) {
      pitchCategory = "Conventional Pitch"
      categoryColor = "text-emerald-600"
      categoryBg = "bg-emerald-50 border-emerald-200"
    } else if (angleInDegrees < 45) {
      pitchCategory = "Medium Pitch"
      categoryColor = "text-yellow-600"
      categoryBg = "bg-yellow-50 border-yellow-200"
    } else if (angleInDegrees < 60) {
      pitchCategory = "Steep Pitch"
      categoryColor = "text-orange-600"
      categoryBg = "bg-orange-50 border-orange-200"
    } else {
      pitchCategory = "Very Steep"
      categoryColor = "text-red-600"
      categoryBg = "bg-red-50 border-red-200"
    }

    setResult({
      ratio,
      ratioDecimal,
      angleInDegrees,
      percentage,
      pitchCategory,
      categoryColor,
      categoryBg,
    })
  }

  const handleReset = () => {
    setRise("")
    setRun("")
    setResult(null)
    setError("")
    setCopied(false)
    setShowSteps(false)
  }

  const handleCopy = async () => {
    if (result) {
      const text = `Roof Pitch: ${result.ratio} | Angle: ${result.angleInDegrees.toFixed(2)}° | Percentage: ${result.percentage.toFixed(1)}%`
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const toggleUnitSystem = () => {
    setUnitSystem((prev) => (prev === "metric" ? "imperial" : "metric"))
    setRise("")
    setRun("")
    setResult(null)
    setError("")
  }

  const lengthUnit = unitSystem === "metric" ? "m" : "ft"

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />

      <main className="flex-1 py-6 sm:py-8 lg:py-12">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2">
            <Link href="/category/construction">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Construction
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Calculator Card */}
            <Card className="shadow-lg border-0">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Home className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Roof Pitch Calculator</CardTitle>
                    <CardDescription>Calculate roof slope angle and ratio</CardDescription>
                  </div>
                </div>

                {/* Unit Toggle */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-medium">Unit System</span>
                  <button
                    onClick={toggleUnitSystem}
                    className="relative inline-flex h-9 w-40 items-center rounded-full bg-muted p-1 transition-colors"
                  >
                    <span
                      className={`absolute h-7 w-[calc(50%-4px)] rounded-full bg-primary shadow-sm transition-transform duration-200 ${
                        unitSystem === "imperial" ? "translate-x-[calc(100%+4px)]" : "translate-x-0"
                      }`}
                    />
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "metric" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Metric
                    </span>
                    <span
                      className={`relative z-10 flex-1 text-center text-sm font-medium transition-colors ${
                        unitSystem === "imperial" ? "text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      Imperial
                    </span>
                  </button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Rise Input */}
                <div className="space-y-2">
                  <Label htmlFor="rise">Rise (Vertical Height) ({lengthUnit})</Label>
                  <Input
                    id="rise"
                    type="number"
                    placeholder={`Enter rise in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={rise}
                    onChange={(e) => setRise(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Run Input */}
                <div className="space-y-2">
                  <Label htmlFor="run">Run (Horizontal Length) ({lengthUnit})</Label>
                  <Input
                    id="run"
                    type="number"
                    placeholder={`Enter run in ${unitSystem === "metric" ? "meters" : "feet"}`}
                    value={run}
                    onChange={(e) => setRun(e.target.value)}
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Roof Diagram */}
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-2 text-center">Roof Pitch Diagram</p>
                  <svg viewBox="0 0 200 120" className="w-full h-24">
                    {/* Run (horizontal) */}
                    <line
                      x1="30"
                      y1="90"
                      x2="170"
                      y2="90"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-blue-500"
                    />
                    {/* Rise (vertical) */}
                    <line
                      x1="170"
                      y1="90"
                      x2="170"
                      y2="30"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-green-500"
                    />
                    {/* Roof slope */}
                    <line
                      x1="30"
                      y1="90"
                      x2="170"
                      y2="30"
                      stroke="currentColor"
                      strokeWidth="3"
                      className="text-amber-600"
                    />
                    {/* Angle arc */}
                    <path
                      d="M 50 90 A 20 20 0 0 0 45 75"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      className="text-amber-500"
                    />
                    {/* Labels */}
                    <text x="100" y="105" textAnchor="middle" className="text-xs fill-blue-600 font-medium">
                      Run
                    </text>
                    <text x="185" y="60" textAnchor="middle" className="text-xs fill-green-600 font-medium">
                      Rise
                    </text>
                    <text x="90" y="55" textAnchor="middle" className="text-xs fill-amber-600 font-medium">
                      Slope
                    </text>
                    <text x="60" y="82" textAnchor="middle" className="text-[10px] fill-amber-500">
                      θ
                    </text>
                  </svg>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{error}</div>
                )}

                {/* Calculate Button */}
                <Button onClick={calculateRoofPitch} className="w-full" size="lg">
                  Calculate Roof Pitch
                </Button>

                {/* Result */}
                {result && (
                  <div className={`p-4 rounded-xl border-2 ${result.categoryBg} transition-all duration-300`}>
                    <div className="text-center mb-4">
                      <p className="text-sm text-muted-foreground mb-1">Pitch Ratio</p>
                      <p className={`text-4xl font-bold ${result.categoryColor}`}>{result.ratio}</p>
                      <p className={`text-lg font-semibold ${result.categoryColor} mt-1`}>{result.pitchCategory}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="text-center p-3 bg-background/60 rounded-lg">
                        <p className="text-xs text-muted-foreground">Angle</p>
                        <p className="text-xl font-bold text-foreground">{result.angleInDegrees.toFixed(2)}°</p>
                      </div>
                      <div className="text-center p-3 bg-background/60 rounded-lg">
                        <p className="text-xs text-muted-foreground">Percentage</p>
                        <p className="text-xl font-bold text-foreground">{result.percentage.toFixed(1)}%</p>
                      </div>
                    </div>

                    {/* Step-by-step calculation */}
                    <button
                      onClick={() => setShowSteps(!showSteps)}
                      className="w-full flex items-center justify-between p-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <span>Step-by-step calculation</span>
                      {showSteps ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                    </button>

                    {showSteps && (
                      <div className="mt-2 p-3 bg-background/60 rounded-lg text-sm space-y-2">
                        <div>
                          <p className="font-medium">1. Pitch Ratio:</p>
                          <p className="text-muted-foreground font-mono text-xs">
                            Ratio = Rise ÷ Run = {rise} ÷ {run} = {result.ratioDecimal.toFixed(4)}
                          </p>
                          {unitSystem === "imperial" && (
                            <p className="text-muted-foreground font-mono text-xs">
                              = {(result.ratioDecimal * 12).toFixed(2)} : 12
                            </p>
                          )}
                        </div>
                        <div>
                          <p className="font-medium">2. Angle in Degrees:</p>
                          <p className="text-muted-foreground font-mono text-xs">θ = arctan(Rise ÷ Run) × (180 ÷ π)</p>
                          <p className="text-muted-foreground font-mono text-xs">
                            θ = arctan({result.ratioDecimal.toFixed(4)}) × 57.2958 = {result.angleInDegrees.toFixed(2)}°
                          </p>
                        </div>
                        <div>
                          <p className="font-medium">3. Percentage:</p>
                          <p className="text-muted-foreground font-mono text-xs">
                            Percentage = (Rise ÷ Run) × 100 = {result.ratioDecimal.toFixed(4)} × 100 ={" "}
                            {result.percentage.toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Action Buttons */}
                    <div className="flex items-center justify-center gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={handleReset}>
                        <RotateCcw className="h-4 w-4 mr-1" />
                        Reset
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleCopy}>
                        {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
                        {copied ? "Copied" : "Copy"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Info Cards */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Roof Pitch Formulas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Pitch Ratio</p>
                    <p className="font-mono text-sm font-semibold">Ratio = Rise ÷ Run</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Angle (Degrees)</p>
                    <p className="font-mono text-sm font-semibold">θ = arctan(Rise ÷ Run) × (180/π)</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Percentage</p>
                    <p className="font-mono text-sm font-semibold">% = (Rise ÷ Run) × 100</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pitch Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between p-2 bg-blue-50 border border-blue-200 rounded">
                      <span className="text-blue-700">Flat/Low Slope</span>
                      <span className="text-blue-600">&lt; 10°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-green-50 border border-green-200 rounded">
                      <span className="text-green-700">Low Pitch</span>
                      <span className="text-green-600">10° - 20°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-emerald-50 border border-emerald-200 rounded">
                      <span className="text-emerald-700">Conventional</span>
                      <span className="text-emerald-600">20° - 35°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-yellow-50 border border-yellow-200 rounded">
                      <span className="text-yellow-700">Medium Pitch</span>
                      <span className="text-yellow-600">35° - 45°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-orange-50 border border-orange-200 rounded">
                      <span className="text-orange-700">Steep Pitch</span>
                      <span className="text-orange-600">45° - 60°</span>
                    </div>
                    <div className="flex justify-between p-2 bg-red-50 border border-red-200 rounded">
                      <span className="text-red-700">Very Steep</span>
                      <span className="text-red-600">&gt; 60°</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Common Roof Pitches</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2 font-medium">Ratio</th>
                          <th className="text-left py-2 font-medium">Angle</th>
                          <th className="text-left py-2 font-medium">Use</th>
                        </tr>
                      </thead>
                      <tbody className="text-muted-foreground">
                        <tr className="border-b">
                          <td className="py-2">4:12</td>
                          <td className="py-2">18.4°</td>
                          <td className="py-2">Minimum for shingles</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">6:12</td>
                          <td className="py-2">26.6°</td>
                          <td className="py-2">Standard residential</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">8:12</td>
                          <td className="py-2">33.7°</td>
                          <td className="py-2">Traditional look</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">10:12</td>
                          <td className="py-2">39.8°</td>
                          <td className="py-2">Victorian style</td>
                        </tr>
                        <tr>
                          <td className="py-2">12:12</td>
                          <td className="py-2">45.0°</td>
                          <td className="py-2">A-frame/steep</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800">
                <p className="font-medium">Disclaimer</p>
                <p>
                  Results are estimates. Actual roof pitch may vary due to construction tolerances and design
                  adjustments. Always verify measurements on-site and consult with a professional roofer or engineer for
                  construction projects.
                </p>
              </div>
            </div>
          </div>

          {/* Educational Content */}
          <div className="mt-12 space-y-8">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Info className="h-5 w-5 text-primary" />
                  <CardTitle>What is Roof Pitch?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  Roof pitch, also known as roof slope, is a measure of how steep a roof is. It describes the vertical
                  rise of the roof relative to its horizontal run. Understanding roof pitch is essential for roofing
                  projects as it affects material selection, drainage, structural requirements, and overall aesthetics
                  of a building.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  Roof pitch is commonly expressed in three ways: as a ratio (e.g., 6:12, meaning 6 inches of rise for
                  every 12 inches of run), as an angle in degrees, or as a percentage. The ratio format is most commonly
                  used in the United States construction industry, while degrees and percentages are more universal and
                  often used in engineering and international contexts.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Home className="h-5 w-5 text-primary" />
                  <CardTitle>Understanding Rise and Run</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <p className="text-muted-foreground leading-relaxed">
                  <strong>Rise</strong> is the vertical distance from the top of the roof to the bottom edge (eave). It
                  represents how much the roof climbs vertically. The rise is measured perpendicular to the ground,
                  straight up and down.
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  <strong>Run</strong> is the horizontal distance from the edge of the roof to the point directly below
                  the peak (or the point where rise is measured). It's important to note that run is not the same as the
                  actual length of the roof surface (which is longer due to the slope).
                </p>
                <p className="text-muted-foreground leading-relaxed mt-4">
                  For a standard gable roof, the total span (width of the building) equals twice the run, as the run is
                  measured from the center peak to the edge on one side only.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-primary" />
                  <CardTitle>Why Roof Pitch Matters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="prose prose-gray max-w-none">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Material Selection</h4>
                    <p className="text-sm text-muted-foreground">
                      Different roofing materials have minimum pitch requirements. Asphalt shingles typically require at
                      least 4:12 pitch, while metal roofing can work on lower slopes. Flat roofs need special membrane
                      materials.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Water Drainage</h4>
                    <p className="text-sm text-muted-foreground">
                      Steeper roofs shed water and snow more effectively. In areas with heavy rainfall or snowfall,
                      adequate pitch is crucial to prevent water pooling, leaks, and structural damage.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Structural Requirements</h4>
                    <p className="text-sm text-muted-foreground">
                      Steeper roofs require stronger framing to resist wind uplift and support workers during
                      installation. They also create more attic space but require more roofing materials.
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold text-foreground mb-2">Aesthetics & Style</h4>
                    <p className="text-sm text-muted-foreground">
                      Roof pitch significantly impacts a building's appearance. Colonial and Victorian homes typically
                      have steeper pitches, while modern and ranch-style homes often feature lower slopes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
