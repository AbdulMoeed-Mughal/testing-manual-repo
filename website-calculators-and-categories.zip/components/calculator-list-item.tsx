import Link from "next/link"
import { ArrowRight } from "lucide-react"
import type { CalculatorItem } from "@/lib/categories"

interface CalculatorListItemProps {
  calculator: CalculatorItem
  categorySlug: string
}

export function CalculatorListItem({ calculator, categorySlug }: CalculatorListItemProps) {
  return (
    <Link href={`/calculator/${calculator.slug}`} className="group block">
      <div className="flex items-center justify-between p-3 sm:p-4 rounded-lg border border-border bg-card hover:border-primary/20 hover:shadow-sm transition-all duration-200 active:scale-[0.98]">
        <div className="min-w-0 flex-1">
          <h4 className="font-medium text-sm sm:text-base group-hover:text-primary transition-colors truncate">
            {calculator.name}
          </h4>
          <p className="text-xs sm:text-sm text-muted-foreground mt-0.5 sm:mt-1 line-clamp-1">
            {calculator.description}
          </p>
        </div>
        <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all shrink-0 ml-3 sm:ml-4" />
      </div>
    </Link>
  )
}
