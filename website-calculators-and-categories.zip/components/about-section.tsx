import { CheckCircle2 } from "lucide-react"

const features = [
  "Accurate calculations powered by proven formulas",
  "Clean, easy-to-use interface on any device",
  "No registration or sign-up required",
  "100% free with no hidden costs",
  "Privacy-focused - no personal data collected",
  "Regular updates with new calculators",
]

export function AboutSection() {
  return (
    <section id="about" className="py-10 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-3 sm:mb-4">Why Choose CalcHub?</h2>
            <p className="text-sm sm:text-base text-muted-foreground mb-6 sm:mb-8 leading-relaxed">
              CalcHub is your trusted destination for free online calculators. Whether you&apos;re a student,
              professional, or just need quick calculations for everyday tasks, we&apos;ve got you covered with over 160
              specialized calculators across 20 categories.
            </p>
            <ul className="space-y-2.5 sm:space-y-3">
              {features.map((feature, index) => (
                <li key={index} className="flex items-start gap-2.5 sm:gap-3">
                  <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5 text-green-600 shrink-0 mt-0.5" />
                  <span className="text-sm sm:text-base text-muted-foreground">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="relative hidden sm:block">
            <div className="aspect-square rounded-2xl bg-muted/50 border border-border p-6 sm:p-8 flex items-center justify-center">
              <div className="grid grid-cols-3 gap-3 sm:gap-4">
                {[...Array(9)].map((_, i) => (
                  <div
                    key={i}
                    className="h-12 w-12 sm:h-16 sm:w-16 rounded-lg bg-card border border-border flex items-center justify-center text-xl sm:text-2xl font-mono text-muted-foreground"
                  >
                    {i + 1}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
