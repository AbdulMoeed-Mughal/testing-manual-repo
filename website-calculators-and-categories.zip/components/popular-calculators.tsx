import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { categories } from "@/lib/categories"

const popularCalculators = [
  {
    category: "health-fitness",
    calculator: "bmi",
    name: "BMI Calculator",
    description: "Calculate your Body Mass Index",
  },
  { category: "finance-money", calculator: "loan", name: "Loan Calculator", description: "Calculate loan payments" },
  {
    category: "math-geometry",
    calculator: "percentage",
    name: "Percentage Calculator",
    description: "Percentage calculations",
  },
  { category: "finance-money", calculator: "tip", name: "Tip Calculator", description: "Split bills and tips" },
  { category: "lifestyle-daily", calculator: "age", name: "Age Calculator", description: "Calculate exact age" },
  { category: "health-fitness", calculator: "calorie", name: "Calorie Calculator", description: "Daily caloric needs" },
]

export function PopularCalculators() {
  return (
    <section id="popular" className="py-10 sm:py-16 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-3 sm:mb-4">Popular Calculators</h2>
          <p className="text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto px-2 sm:px-0">
            Our most used calculators, trusted by millions of users worldwide
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {popularCalculators.map((calc) => {
            const category = categories.find((c) => c.slug === calc.category)
            const Icon = category?.icon

            return (
              <Link
                key={`${calc.category}-${calc.calculator}`}
                href={`/category/${calc.category}/${calc.calculator}`}
                className="group"
              >
                <div className="flex items-center gap-3 sm:gap-4 p-3 sm:p-4 rounded-xl border border-border bg-card hover:border-primary/20 hover:shadow-md transition-all duration-200 active:scale-[0.98]">
                  {Icon && (
                    <div
                      className={`flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-lg ${category?.color} shrink-0`}
                    >
                      <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm sm:text-base group-hover:text-primary transition-colors truncate">
                      {calc.name}
                    </h4>
                    <p className="text-xs sm:text-sm text-muted-foreground truncate">{calc.description}</p>
                  </div>
                  <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all shrink-0" />
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}
