import Link from "next/link"
import { ArrowRight } from "lucide-react"
import type { Category } from "@/lib/categories"

interface CategoryCardProps {
  category: Category
}

export function CategoryCard({ category }: CategoryCardProps) {
  const Icon = category.icon

  return (
    <Link href={`/category/${category.slug}`} className="group">
      <div className="h-full rounded-xl border border-border bg-card p-4 sm:p-6 transition-all duration-200 hover:border-primary/20 hover:shadow-md active:scale-[0.98]">
        <div
          className={`inline-flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-lg ${category.color} mb-3 sm:mb-4`}
        >
          <Icon className="h-5 w-5 sm:h-6 sm:w-6" />
        </div>
        <h3 className="font-semibold text-base sm:text-lg mb-1.5 sm:mb-2 group-hover:text-primary transition-colors">
          {category.name}
        </h3>
        <p className="text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4 leading-relaxed line-clamp-2">
          {category.description}
        </p>
        <div className="flex items-center text-xs sm:text-sm font-medium text-muted-foreground group-hover:text-primary transition-colors">
          <span>{category.calculators.length} calculators</span>
          <ArrowRight className="ml-2 h-3.5 w-3.5 sm:h-4 sm:w-4 transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  )
}
