import { Calculator, Users, Zap, Shield } from "lucide-react"

const stats = [
  {
    icon: Calculator,
    value: "160+",
    label: "Free Calculators",
  },
  {
    icon: Users,
    value: "1M+",
    label: "Monthly Users",
  },
  {
    icon: Zap,
    value: "100%",
    label: "Free Forever",
  },
  {
    icon: Shield,
    value: "Privacy",
    label: "No Data Stored",
  },
]

export function StatsSection() {
  return (
    <section className="py-10 sm:py-16 border-y border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-full bg-muted mb-3 sm:mb-4">
                <stat.icon className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold tracking-tight">{stat.value}</div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
