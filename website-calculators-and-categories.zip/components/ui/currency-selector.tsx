"use client"

import { type Currency, currencyOptions } from "@/lib/currency"

interface CurrencySelectorProps {
  value: Currency
  onChange: (currency: Currency) => void
  className?: string
}

export function CurrencySelector({ value, onChange, className = "" }: CurrencySelectorProps) {
  return (
    <div className={`flex items-center justify-between ${className}`}>
      <span className="text-sm font-medium">Currency</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as Currency)}
        className="h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
      >
        {currencyOptions.map((option) => (
          <option key={option.value} value={option.value}>
            {option.value} ({option.symbol})
          </option>
        ))}
      </select>
    </div>
  )
}
