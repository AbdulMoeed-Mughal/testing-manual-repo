import Link from "next/link"
import { ArrowRight, Calculator, Zap, Shield, Globe } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CategoryCard } from "@/components/category-card"
import { PopularCalculators } from "@/components/popular-calculators"
import { StatsSection } from "@/components/stats-section"
import { AboutSection } from "@/components/about-section"
import { HeroSearch } from "@/components/hero-search"
import { Button } from "@/components/ui/button"
import { categories } from "@/lib/categories"

export default function HomePage() {
  const totalCalculators = categories.reduce((sum, category) => sum + category.calculators.length, 0)

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <section className="relative py-8 sm:py-12 lg:py-16 overflow-hidden">
          {/* Background decoration - hidden on mobile for performance */}
          <div className="absolute inset-0 -z-10 hidden sm:block">
            <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
          </div>

          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <div className="inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-full bg-primary/10 text-primary mb-4 sm:mb-6">
                <Calculator className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                <span className="text-xs sm:text-sm font-medium">{totalCalculators}+ Free Calculators</span>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-balance mb-4 sm:mb-6">
                Calculate Anything,
                <span className="block text-primary">Anytime, Anywhere</span>
              </h1>

              <p className="text-base sm:text-lg lg:text-xl text-muted-foreground mb-6 sm:mb-10 text-pretty leading-relaxed max-w-2xl mx-auto px-2 sm:px-0">
                Your all-in-one calculator hub. From health metrics to financial planning — find the perfect calculator
                for every need.
              </p>

              {/* Hero Search Bar */}
              <HeroSearch />

              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mt-6 sm:mt-10 px-2 sm:px-0">
                <Button size="lg" asChild className="h-11 sm:h-12 px-6 sm:px-8 w-full sm:w-auto">
                  <Link href="#categories">
                    Browse Categories
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  asChild
                  className="h-11 sm:h-12 px-6 sm:px-8 bg-transparent w-full sm:w-auto"
                >
                  <Link href="#popular">Popular Calculators</Link>
                </Button>
              </div>

              <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center justify-center gap-3 sm:gap-6 mt-8 sm:mt-12 pt-6 sm:pt-8 border-t border-border">
                <div className="flex items-center justify-center sm:justify-start gap-2 text-xs sm:text-sm text-muted-foreground">
                  <Zap className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-primary" />
                  <span>Instant Results</span>
                </div>
                <div className="flex items-center justify-center sm:justify-start gap-2 text-xs sm:text-sm text-muted-foreground">
                  <Shield className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-primary" />
                  <span>100% Free</span>
                </div>
                <div className="flex items-center justify-center sm:justify-start gap-2 text-xs sm:text-sm text-muted-foreground">
                  <Globe className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-primary" />
                  <span>No Sign-up</span>
                </div>
                <div className="flex items-center justify-center sm:justify-start gap-2 text-xs sm:text-sm text-muted-foreground">
                  <Calculator className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-primary" />
                  <span>20 Categories</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <StatsSection />

        <section id="categories" className="py-10 sm:py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8 sm:mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-3 sm:mb-4">Calculator Categories</h2>
              <p className="text-sm sm:text-base text-muted-foreground max-w-2xl mx-auto px-2 sm:px-0">
                Explore our comprehensive collection of calculators organized by category
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {categories.map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          </div>
        </section>

        <PopularCalculators />
        <AboutSection />
      </main>

      <Footer />
    </div>
  )
}
