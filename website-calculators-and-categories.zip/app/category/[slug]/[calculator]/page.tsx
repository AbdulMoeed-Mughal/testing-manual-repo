import { notFound } from "next/navigation"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { categories, getCategoryBySlug } from "@/lib/categories"
import type { Metadata } from "next"

interface CalculatorPageProps {
  params: Promise<{ slug: string; calculator: string }>
}

export async function generateStaticParams() {
  const params: { slug: string; calculator: string }[] = []

  categories.forEach((category) => {
    category.calculators.forEach((calc) => {
      params.push({
        slug: category.slug,
        calculator: calc.slug,
      })
    })
  })

  return params
}

export async function generateMetadata({ params }: CalculatorPageProps): Promise<Metadata> {
  const { slug, calculator: calcSlug } = await params
  const category = getCategoryBySlug(slug)

  if (!category) {
    return { title: "Calculator Not Found" }
  }

  const calculator = category.calculators.find((c) => c.slug === calcSlug)

  if (!calculator) {
    return { title: "Calculator Not Found" }
  }

  return {
    title: `${calculator.name} | CalcHub`,
    description: `${calculator.description}. Free online ${calculator.name.toLowerCase()} - fast, accurate, and easy to use.`,
  }
}

export default async function CalculatorPage({ params }: CalculatorPageProps) {
  const { slug, calculator: calcSlug } = await params
  const category = getCategoryBySlug(slug)

  if (!category) {
    notFound()
  }

  const calculator = category.calculators.find((c) => c.slug === calcSlug)

  if (!calculator) {
    notFound()
  }

  const Icon = category.icon

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Calculator Header */}
        <section className="py-8 border-b border-border bg-muted/30">
          <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
            <Button variant="ghost" size="sm" asChild className="mb-4">
              <Link href={`/category/${category.slug}`}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                {category.name}
              </Link>
            </Button>

            <div className="flex items-center gap-4">
              <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${category.color} shrink-0`}>
                <Icon className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight">{calculator.name}</h1>
                <p className="text-muted-foreground">{calculator.description}</p>
              </div>
            </div>
          </div>
        </section>

        {/* Calculator Placeholder */}
        <section className="py-12">
          <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-xl border border-border bg-card p-8">
              <div className="text-center py-16">
                <div
                  className={`inline-flex h-20 w-20 items-center justify-center rounded-full ${category.color} mb-6`}
                >
                  <Icon className="h-10 w-10" />
                </div>
                <h2 className="text-xl font-semibold mb-2">{calculator.name}</h2>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  This calculator will help you {calculator.description.toLowerCase()}. Enter your values below to get
                  started.
                </p>
                <div className="max-w-sm mx-auto space-y-4">
                  <div className="h-12 rounded-lg bg-muted animate-pulse" />
                  <div className="h-12 rounded-lg bg-muted animate-pulse" />
                  <div className="h-12 rounded-lg bg-primary/10" />
                </div>
                <p className="text-sm text-muted-foreground mt-8">Calculator functionality coming soon</p>
              </div>
            </div>

            {/* Other Calculators in Category */}
            <div className="mt-12">
              <h3 className="text-lg font-semibold mb-4">More {category.name} Calculators</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {category.calculators
                  .filter((c) => c.slug !== calculator.slug)
                  .slice(0, 4)
                  .map((relatedCalc) => (
                    <Link
                      key={relatedCalc.slug}
                      href={`/category/${category.slug}/${relatedCalc.slug}`}
                      className="group"
                    >
                      <div className="p-4 rounded-lg border border-border bg-card hover:border-primary/20 hover:shadow-sm transition-all duration-200">
                        <h4 className="font-medium group-hover:text-primary transition-colors">{relatedCalc.name}</h4>
                        <p className="text-sm text-muted-foreground mt-1">{relatedCalc.description}</p>
                      </div>
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
