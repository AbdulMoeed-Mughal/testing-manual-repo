import { notFound } from "next/navigation"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CalculatorListItem } from "@/components/calculator-list-item"
import { Button } from "@/components/ui/button"
import { categories, getCategoryBySlug } from "@/lib/categories"
import type { Metadata } from "next"

interface CategoryPageProps {
  params: Promise<{ slug: string }>
}

export async function generateStaticParams() {
  return categories.map((category) => ({
    slug: category.slug,
  }))
}

export async function generateMetadata({ params }: CategoryPageProps): Promise<Metadata> {
  const { slug } = await params
  const category = getCategoryBySlug(slug)

  if (!category) {
    return { title: "Category Not Found" }
  }

  return {
    title: `${category.name} Calculators | CalcHub`,
    description: category.longDescription,
  }
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = await params
  const category = getCategoryBySlug(slug)

  if (!category) {
    notFound()
  }

  const Icon = category.icon

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <section className="py-8 sm:py-12 border-b border-border bg-muted/30">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <Button variant="ghost" size="sm" asChild className="mb-4 sm:mb-6 -ml-2 sm:ml-0">
              <Link href="/#categories">
                <ArrowLeft className="mr-2 h-4 w-4" />
                All Categories
              </Link>
            </Button>

            <div className="flex flex-col sm:flex-row items-start gap-4 sm:gap-6">
              <div
                className={`flex h-12 w-12 sm:h-16 sm:w-16 items-center justify-center rounded-xl ${category.color} shrink-0`}
              >
                <Icon className="h-6 w-6 sm:h-8 sm:w-8" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight mb-2">{category.name}</h1>
                <p className="text-sm sm:text-base text-muted-foreground max-w-2xl leading-relaxed">
                  {category.longDescription}
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-8 sm:py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="mb-6 sm:mb-8">
              <h2 className="text-lg sm:text-xl font-semibold mb-1 sm:mb-2">Available Calculators</h2>
              <p className="text-xs sm:text-sm text-muted-foreground">
                {category.calculators.length} calculators in this category
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
              {category.calculators.map((calculator) => (
                <CalculatorListItem key={calculator.slug} calculator={calculator} categorySlug={category.slug} />
              ))}
            </div>
          </div>
        </section>

        <section className="py-8 sm:py-12 border-t border-border bg-muted/30">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="text-lg sm:text-xl font-semibold mb-4 sm:mb-6">Related Categories</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
              {categories
                .filter((c) => c.id !== category.id)
                .slice(0, 4)
                .map((relatedCategory) => {
                  const RelatedIcon = relatedCategory.icon
                  return (
                    <Link key={relatedCategory.id} href={`/category/${relatedCategory.slug}`} className="group">
                      <div className="flex flex-col sm:flex-row items-center sm:items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-lg border border-border bg-card hover:border-primary/20 hover:shadow-sm transition-all duration-200 active:scale-[0.98]">
                        <div
                          className={`flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-lg ${relatedCategory.color} shrink-0`}
                        >
                          <RelatedIcon className="h-4 w-4 sm:h-5 sm:w-5" />
                        </div>
                        <span className="font-medium text-xs sm:text-sm group-hover:text-primary transition-colors text-center sm:text-left line-clamp-2">
                          {relatedCategory.name}
                        </span>
                      </div>
                    </Link>
                  )
                })}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
