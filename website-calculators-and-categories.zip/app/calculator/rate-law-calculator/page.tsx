import { RateLawCalculator } from "@/components/calculators/rate-law-calculator"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Rate Law Calculator - CalcHub",
  description:
    "Determine reaction rate using the rate law equation and analyze reaction order and kinetics behavior. Calculate rates for chemical reactions using experimentally determined rate constants.",
}

export default function RateLawCalculatorPage() {
  return <RateLawCalculator />
}
