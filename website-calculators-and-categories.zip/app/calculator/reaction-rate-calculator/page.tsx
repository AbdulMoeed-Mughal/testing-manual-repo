import type { Metadata } from "next"
import { ReactionRateCalculator } from "@/components/calculators/reaction-rate-calculator"

export const metadata: Metadata = {
  title: "Reaction Rate Calculator | CalcHub",
  description:
    "Calculate the rate of chemical reactions to analyze reaction kinetics. Determine reaction rates from concentration changes and time intervals with stoichiometric coefficients for chemistry and chemical engineering.",
}

export default function ReactionRateCalculatorPage() {
  return <ReactionRateCalculator />
}
